import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateCartTotals,
  getTierMultiplier,
  calculateLoyaltyPoints,
  getTierFromLifetimePoints,
  validateLuhn,
  detectCardBrand,
  validateCardForm,
  canAddToCart,
  generateEmailHtml,
} from './storeLogic.ts';
import type { CartItem, Product, Order } from '../types/store.ts';

const mockProduct: Product = {
  id: 'prod-1',
  sku: 'PRD-001',
  name: 'Organic Honeycrisp Apples',
  category: 'Produce',
  description: 'Crisp, sweet, and locally sourced',
  price: 3.49,
  unit: 'per lb',
  stock: 15,
  lowStockThreshold: 5,
  image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400',
  rating: 4.8,
  reviewCount: 42,
  aisle: 'Aisle 1 - Produce',
  shelf: 'A-3',
  barcode: '8901234567890',
  tags: ['Organic', 'Fresh'],
  nutrition: { calories: 95, organic: true, vegan: true, glutenFree: true },
};

const mockItems: CartItem[] = [
  { product: mockProduct, quantity: 2 }, // $6.98
];

test('calculateCartTotals computes subtotal, tax, and delivery fee correctly', () => {
  const result = calculateCartTotals({
    items: mockItems,
    deliveryType: 'standard',
    tipPercentage: 0,
  });

  assert.equal(result.subtotal, 6.98);
  assert.equal(result.itemCount, 2);
  assert.equal(result.isFreeDelivery, false);
  assert.equal(result.deliveryFee, 4.99);
  // Tax is 7.5% of 6.98 = 0.52
  assert.equal(result.tax, 0.52);
  assert.equal(result.total, Number((6.98 + 0.52 + 4.99).toFixed(2)));
});

test('calculateCartTotals grants free delivery when subtotal meets threshold ($45)', () => {
  const bulkItems: CartItem[] = [
    { product: { ...mockProduct, price: 25.0 }, quantity: 2 }, // $50
  ];
  const result = calculateCartTotals({
    items: bulkItems,
    deliveryType: 'standard',
    tipPercentage: 10,
  });

  assert.equal(result.subtotal, 50.0);
  assert.equal(result.isFreeDelivery, true);
  assert.equal(result.deliveryFee, 0);
  assert.equal(result.tip, 5.0);
});

test('calculateCartTotals applies promo code SAVE10 correctly', () => {
  const items: CartItem[] = [
    { product: { ...mockProduct, price: 40.0 }, quantity: 1 },
  ];
  const result = calculateCartTotals({
    items,
    promoCode: 'SAVE10',
    deliveryType: 'pickup',
  });

  assert.equal(result.subtotal, 40.0);
  assert.equal(result.promoDiscount, 4.0);
  assert.equal(result.taxableAmount, 36.0);
  assert.equal(result.deliveryFee, 0);
});

test('calculateLoyaltyPoints respects user tier multiplier', () => {
  assert.equal(getTierMultiplier('Bronze'), 10);
  assert.equal(getTierMultiplier('Silver'), 12);
  assert.equal(getTierMultiplier('Gold'), 15);
  assert.equal(getTierMultiplier('Platinum'), 20);

  // $10 spent as Gold member (15x) -> 150 points
  assert.equal(calculateLoyaltyPoints(10.0, 'Gold'), 150);
});

test('getTierFromLifetimePoints assigns tiers appropriately', () => {
  assert.equal(getTierFromLifetimePoints(200), 'Bronze');
  assert.equal(getTierFromLifetimePoints(650), 'Silver');
  assert.equal(getTierFromLifetimePoints(1800), 'Gold');
  assert.equal(getTierFromLifetimePoints(3500), 'Platinum');
});

test('validateLuhn algorithm correctly validates test card numbers', () => {
  // Valid standard 16-digit card number (4532015112830366)
  assert.equal(validateLuhn('4532015112830366'), true);
  // Invalid number (altered last digit)
  assert.equal(validateLuhn('4532015112830367'), false);
});

test('detectCardBrand identifies card networks', () => {
  assert.equal(detectCardBrand('4111111111111111'), 'Visa');
  assert.equal(detectCardBrand('5500000000000004'), 'Mastercard');
  assert.equal(detectCardBrand('378282246310005'), 'American Express');
  assert.equal(detectCardBrand('6011111111111117'), 'Discover');
});

test('validateCardForm checks required fields and formats', () => {
  const invalid = validateCardForm('123', '99/99', '12', '');
  assert.equal(invalid.isValid, false);
  assert.ok(invalid.errors.cardNumber);
  assert.ok(invalid.errors.expiry);
  assert.ok(invalid.errors.cvc);
  assert.ok(invalid.errors.name);
});

test('canAddToCart prevents adding more than current stock', () => {
  const stockOk = canAddToCart(5, 2, 1);
  assert.equal(stockOk.allowed, true);

  const stockExceeded = canAddToCart(5, 4, 3);
  assert.equal(stockExceeded.allowed, false);

  const outOfStock = canAddToCart(0, 1, 0);
  assert.equal(outOfStock.allowed, false);
});

test('generateEmailHtml creates valid multi-stage email templates', () => {
  const testOrder: Order = {
    id: 'ord-test-1',
    orderNumber: 'CP-10293',
    createdAt: new Date().toISOString(),
    status: 'order_confirmed',
    customerName: 'Urush Faatima',
    customerEmail: 'urush.faatima@gmail.com',
    customerPhone: '+1 (555) 349-2910',
    items: mockItems,
    subtotal: 6.98,
    tax: 0.52,
    deliveryFee: 4.99,
    discount: 0,
    tip: 2.0,
    total: 14.49,
    pointsEarned: 104,
    pointsRedeemed: 0,
    deliveryType: 'standard',
    deliveryAddress: {
      street: '742 Evergreen Terrace',
      apt: 'Apt 4B',
      city: 'Springfield',
      zip: '97477',
      notes: 'Leave at front porch table',
    },
    paymentMethod: {
      type: 'credit_card',
      brand: 'Visa',
      last4: '4242',
      transactionId: 'TXN-984102',
    },
    timeline: [],
    driver: {
      name: 'Alex Rivera',
      phone: '+1 555-0192',
      vehicle: 'Eco Hybrid Van #4',
      rating: 4.9,
      etaMinutes: 15,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
      currentLocation: 'Pine & 4th Ave',
    },
  };

  const email = generateEmailHtml(testOrder, 'order_confirmed');
  assert.ok(email.subject.includes('CP-10293'));
  assert.ok(email.html.includes('Cornerstone Provisions'));
  assert.ok(email.html.includes('Organic Honeycrisp Apples'));
  assert.ok(email.html.includes('$14.49'));

  const deliveryEmail = generateEmailHtml(testOrder, 'out_for_delivery');
  assert.ok(deliveryEmail.html.includes('Alex Rivera'));
  assert.ok(deliveryEmail.html.includes('Eco Hybrid Van #4'));
});
