import type { TaskItem, HabitItem, PriorityQuadrant, DayOfWeek } from '../types/planner.ts';

/**
 * Calculates progress statistics across tasks and weekly habits
 */
export function calculatePlannerStats(tasks: TaskItem[], habits: HabitItem[]) {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const openLoops = tasks.filter(t => !t.completed).length;

  // Top 3 priority status
  const top3Tasks = tasks.filter(t => t.category === 'top3');
  const completedTop3 = top3Tasks.filter(t => t.completed).length;

  // Quick 2-min triage tasks
  const under2MinTasks = tasks.filter(t => t.category === 'under-2-min');
  const completed2Min = under2MinTasks.filter(t => t.completed).length;

  // Waiting for tasks
  const waitingForTasks = tasks.filter(t => t.category === 'waiting-for' && !t.completed);

  // Parking lot thoughts
  const parkingLotCount = tasks.filter(t => t.category === 'parking-lot' && !t.completed).length;

  const taskCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Habit consistency
  const activeHabitsCount = habits.length;
  const currentTotalStreak = habits.reduce((acc, h) => acc + (h.currentStreak || 0), 0);

  return {
    totalTasks,
    completedTasks,
    openLoops,
    taskCompletionRate,
    top3Total: top3Tasks.length,
    completedTop3,
    under2MinTotal: under2MinTasks.length,
    completed2Min,
    waitingForCount: waitingForTasks.length,
    parkingLotCount,
    activeHabitsCount,
    currentTotalStreak,
  };
}

/**
 * Filters tasks into the Eisenhower 4 Quadrants
 */
export function groupTasksByEisenhower(tasks: TaskItem[]): Record<PriorityQuadrant, TaskItem[]> {
  const groups: Record<PriorityQuadrant, TaskItem[]> = {
    'urgent-important': [],
    'important-not-urgent': [],
    'urgent-not-important': [],
    'not-urgent-not-important': [],
  };

  for (const task of tasks) {
    if (groups[task.priority]) {
      groups[task.priority].push(task);
    } else {
      groups['important-not-urgent'].push(task);
    }
  }

  return groups;
}

/**
 * Helper to turn a vague task input into a next physical action suggestion
 */
export function suggestNextPhysicalAction(rawInput: string): string {
  const trimmed = rawInput.trim();
  if (!trimmed) return '';

  const lower = trimmed.toLowerCase();

  if (lower.startsWith('call') || lower.startsWith('email') || lower.startsWith('write') || lower.startsWith('open') || lower.startsWith('draft')) {
    return trimmed; // Already an action verb!
  }

  if (lower.includes('tax') || lower.includes('receipt') || lower.includes('invoice')) {
    return `Open spreadsheet and log receipts for: ${trimmed}`;
  }
  if (lower.includes('grocer') || lower.includes('shop') || lower.includes('store') || lower.includes('buy')) {
    return `Check pantry and write shopping list for: ${trimmed}`;
  }
  if (lower.includes('clean') || lower.includes('tidy') || lower.includes('declutter')) {
    return `Set 15-min timer and clear physical surfaces for: ${trimmed}`;
  }
  if (lower.includes('workout') || lower.includes('gym') || lower.includes('run')) {
    return `Put on shoes and start 5-min stretch for: ${trimmed}`;
  }
  if (lower.includes('project') || lower.includes('presentation') || lower.includes('report')) {
    return `Create blank outline document and draft 3 bullet points for: ${trimmed}`;
  }

  return `Take first 2-minute physical step to begin: ${trimmed}`;
}

/**
 * Validates and formats an implementation intention
 * "If it's [time/condition], then I will [action]"
 */
export function formatIfThenIntention(condition: string, action: string): string {
  const c = condition.trim();
  const a = action.trim();
  if (!c || !a) return '';

  const cleanCond = c.replace(/^(if\s+)/i, '').replace(/,\s*then.*$/i, '');
  const cleanAct = a.replace(/^(then\s+(i\s+will\s+|i\s+)?|i\s+will\s+|i\s+)/i, '');

  return `If ${cleanCond}, then I will ${cleanAct}`;
}

/**
 * Calculates current consecutive streak for a habit given completed dates map
 */
export function calculateStreak(completedDates: Record<string, boolean>, todayDateStr: string): number {
  if (!completedDates) return 0;

  const today = new Date(todayDateStr);
  let streak = 0;
  let checkDate = new Date(today);

  // Check if today is completed
  const todayKey = checkDate.toISOString().split('T')[0];
  if (!completedDates[todayKey]) {
    // If not completed today yet, check yesterday to see if streak is still active
    checkDate.setDate(checkDate.getDate() - 1);
  }

  while (true) {
    const key = checkDate.toISOString().split('T')[0];
    if (completedDates[key]) {
      streak += 1;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }

  return streak;
}

/**
 * Formats seconds into mm:ss for the focus timer
 */
export function formatFocusTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Returns tasks organized by days of the week
 */
export function groupTasksByDay(tasks: TaskItem[]): Record<DayOfWeek, TaskItem[]> {
  const days: Record<DayOfWeek, TaskItem[]> = {
    mon: [],
    tue: [],
    wed: [],
    thu: [],
    fri: [],
    sat: [],
    sun: [],
  };

  for (const task of tasks) {
    if (task.dayOfWeek && days[task.dayOfWeek]) {
      days[task.dayOfWeek].push(task);
    }
  }

  return days;
}

/**
 * Calculates time scheduled vs remaining buffer
 * Guideline rule: "Plan only about 60 to 70 percent of your time, because plans fail when they're packed."
 */
export function calculateScheduleLoad(tasksForDay: TaskItem[], availableHours: number = 8) {
  const totalMinutes = tasksForDay.reduce((sum, t) => sum + (t.estimatedMinutes || 45), 0);
  const totalHours = totalMinutes / 60;
  const loadPercentage = Math.round((totalHours / availableHours) * 100);

  let status: 'optimal' | 'warning' | 'overloaded' = 'optimal';
  let message = 'Perfect breathing room (60-70% buffer preserved)';

  if (loadPercentage > 85) {
    status = 'overloaded';
    message = 'Overbooked! Leave 30-40% margin for interruptions and flexibility.';
  } else if (loadPercentage > 70) {
    status = 'warning';
    message = 'Approaching capacity. Consider moving non-essential tasks.';
  }

  return {
    totalMinutes,
    totalHours: Number(totalHours.toFixed(1)),
    loadPercentage,
    status,
    message,
    availableHours,
  };
}
