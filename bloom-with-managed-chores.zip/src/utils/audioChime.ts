/**
 * Soothing gentle botanical chime using the browser Web Audio API
 */
export function playGentleChime(type: 'success' | 'focus-end' | 'sparkle' | 'alarm-gentle' | 'break-end' = 'success') {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    if (type === 'alarm-gentle' || type === 'focus-end') {
      // Gentle meditation bell & cascading harmonious singing chime
      // Warm chord sequence: C5 (523.25), E5 (659.25), G5 (783.99), B5 (987.77), C6 (1046.5)
      const notes = [
        { freq: 523.25, time: 0.0, dur: 2.2 },
        { freq: 659.25, time: 0.15, dur: 2.4 },
        { freq: 783.99, time: 0.32, dur: 2.6 },
        { freq: 1046.50, time: 0.50, dur: 3.0 },
        // Secondary soft echo chime 1.4s later
        { freq: 659.25, time: 1.40, dur: 2.2 },
        { freq: 783.99, time: 1.55, dur: 2.4 },
        { freq: 1046.50, time: 1.70, dur: 2.8 },
      ];

      notes.forEach(({ freq, time, dur }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + time);

        gain.gain.setValueAtTime(0.0001, now + time);
        gain.gain.exponentialRampToValueAtTime(0.18, now + time + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + time + dur);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + time);
        osc.stop(now + time + dur + 0.05);
      });
    } else if (type === 'break-end') {
      // Gentle reminder tone to resume focus
      const notes = [
        { freq: 440, time: 0, dur: 1.2 },
        { freq: 554.37, time: 0.18, dur: 1.4 },
        { freq: 659.25, time: 0.36, dur: 1.8 }
      ];
      notes.forEach(({ freq, time, dur }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + time);
        gain.gain.setValueAtTime(0.0001, now + time);
        gain.gain.exponentialRampToValueAtTime(0.12, now + time + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + time + dur);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + time);
        osc.stop(now + time + dur + 0.05);
      });
    } else if (type === 'success') {
      // Warm chord: E5, G#5, B5
      const freqs = [659.25, 830.61, 987.77];
      freqs.forEach((freq, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + index * 0.08);

        gain.gain.setValueAtTime(0.001, now + index * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.15, now + index * 0.08 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + index * 0.08 + 0.9);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + index * 0.08);
        osc.stop(now + index * 0.08 + 0.95);
      });
    } else {
      // Gentle sparkle
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.06);

        gain.gain.setValueAtTime(0.001, now + i * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.1, now + i * 0.06 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.06 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + i * 0.06);
        osc.stop(now + i * 0.06 + 0.55);
      });
    }
  } catch {
    // Audio context may be restricted before user gesture
  }
}
