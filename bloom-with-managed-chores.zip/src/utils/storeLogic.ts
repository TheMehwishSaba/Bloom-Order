import type { CartItem, LoyaltyTier, Order, OrderStatus } from '../types/store.ts';

export interface CartCalculationInput {
  items: CartItem[];
  promoCode?: string;
  pointsToRedeem?: number; // 100 points = $1.00
  deliveryType?: 'standard' | 'express' | 'pickup';
  tipPercentage?: number; // 0, 10, 15, 20, or custom amount
  customTipAmount?: number;
}

export interface CartCalculationResult {
  itemCount: number;
  subtotal: number;
  promoDiscount: number;
  pointsDiscount: number;
  totalDiscount: number;
  taxableAmount: number;
  tax: number;
  deliveryFee: number;
  tip: number;
  total: number;
  freeDeliveryThreshold: number;
  amountNeededForFreeDelivery: number;
  isFreeDelivery: boolean;
}

export const FREE_DELIVERY_THRESHOLD = 45.0;
export const STANDARD_DELIVERY_FEE = 4.99;
export const EXPRESS_SURCHARGE = 3.99;
export const TAX_RATE = 0.075; // 7.5% state/local grocery & retail tax

export function calculateCartTotals(input: CartCalculationInput): CartCalculationResult {
  const {
    items,
    promoCode = '',
    pointsToRedeem = 0,
    deliveryType = 'standard',
    tipPercentage = 15,
    customTipAmount = 0,
  } = input;

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = Number(
    items.reduce((sum, item) => sum + item.product.price * item.quantity, 0).toFixed(2)
  );

  // Promo code calculation
  let promoDiscount = 0;
  const cleanCode = promoCode.trim().toUpperCase();
  if (cleanCode === 'SAVE10' && subtotal >= 30) {
    promoDiscount = Number((subtotal * 0.1).toFixed(2));
  } else if (cleanCode === 'CORNER20' && subtotal >= 50) {
    promoDiscount = 20.0;
  } else if (cleanCode === 'WELCOME5') {
    promoDiscount = 5.0;
  }

  // Cap promo discount to subtotal
  promoDiscount = Math.min(promoDiscount, subtotal);

  // Loyalty points discount ($1 per 100 points)
  const maxRedeemableDollars = Math.max(0, subtotal - promoDiscount);
  const rawPointsDiscount = Number((pointsToRedeem / 100).toFixed(2));
  const pointsDiscount = Math.min(rawPointsDiscount, maxRedeemableDollars);

  const totalDiscount = Number((promoDiscount + pointsDiscount).toFixed(2));
  const discountedSubtotal = Math.max(0, Number((subtotal - totalDiscount).toFixed(2)));

  // Delivery fee logic
  let deliveryFee = 0;
  let isFreeDelivery = false;
  if (deliveryType === 'pickup') {
    deliveryFee = 0;
    isFreeDelivery = true;
  } else {
    const qualifiesForFreeDelivery = subtotal >= FREE_DELIVERY_THRESHOLD || cleanCode === 'FREESHIP';
    if (qualifiesForFreeDelivery) {
      isFreeDelivery = true;
      deliveryFee = deliveryType === 'express' ? EXPRESS_SURCHARGE : 0;
    } else {
      isFreeDelivery = false;
      deliveryFee = deliveryType === 'express' 
        ? Number((STANDARD_DELIVERY_FEE + EXPRESS_SURCHARGE).toFixed(2)) 
        : STANDARD_DELIVERY_FEE;
    }
  }

  // Tax calculation on discounted items
  const tax = Number((discountedSubtotal * TAX_RATE).toFixed(2));

  // Tip calculation
  let tip = 0;
  if (customTipAmount > 0) {
    tip = Number(customTipAmount.toFixed(2));
  } else if (tipPercentage > 0 && deliveryType !== 'pickup') {
    tip = Number(((subtotal * tipPercentage) / 100).toFixed(2));
  }

  const total = Number((discountedSubtotal + tax + deliveryFee + tip).toFixed(2));
  const amountNeededForFreeDelivery = Math.max(
    0,
    Number((FREE_DELIVERY_THRESHOLD - subtotal).toFixed(2))
  );

  return {
    itemCount,
    subtotal,
    promoDiscount,
    pointsDiscount,
    totalDiscount,
    taxableAmount: discountedSubtotal,
    tax,
    deliveryFee,
    tip,
    total,
    freeDeliveryThreshold: FREE_DELIVERY_THRESHOLD,
    amountNeededForFreeDelivery,
    isFreeDelivery,
  };
}

/**
 * Multiplier for loyalty points earned per $1 spent based on user tier
 */
export function getTierMultiplier(tier: LoyaltyTier): number {
  switch (tier) {
    case 'Platinum':
      return 20; // 20 pts per $1
    case 'Gold':
      return 15; // 15 pts per $1
    case 'Silver':
      return 12; // 12 pts per $1
    case 'Bronze':
    default:
      return 10; // 10 pts per $1
  }
}

export function calculateLoyaltyPoints(subtotalAfterDiscounts: number, tier: LoyaltyTier): number {
  const multiplier = getTierMultiplier(tier);
  return Math.floor(Math.max(0, subtotalAfterDiscounts) * multiplier);
}

export function getTierFromLifetimePoints(lifetimePoints: number): LoyaltyTier {
  if (lifetimePoints >= 3000) return 'Platinum';
  if (lifetimePoints >= 1500) return 'Gold';
  if (lifetimePoints >= 500) return 'Silver';
  return 'Bronze';
}

/**
 * Standard Luhn Algorithm for validating credit cards
 */
export function validateLuhn(cardNumber: string): boolean {
  const sanitized = cardNumber.replace(/\D/g, '');
  if (sanitized.length < 13 || sanitized.length > 19) return false;

  let sum = 0;
  let alternate = false;
  for (let i = sanitized.length - 1; i >= 0; i--) {
    let digit = parseInt(sanitized.charAt(i), 10);
    if (alternate) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    alternate = !alternate;
  }
  return sum % 10 === 0;
}

export function detectCardBrand(cardNumber: string): string {
  const clean = cardNumber.replace(/\D/g, '');
  if (/^4/.test(clean)) return 'Visa';
  if (/^(5[1-5]|2[2-7])/.test(clean)) return 'Mastercard';
  if (/^3[47]/.test(clean)) return 'American Express';
  if (/^6(011|5)/.test(clean)) return 'Discover';
  return 'Card';
}

export function validateCardForm(
  cardNumber: string,
  expiry: string,
  cvc: string,
  name: string
): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  const cleanNum = cardNumber.replace(/\D/g, '');
  if (!cleanNum) {
    errors.cardNumber = 'Card number is required';
  } else if (!validateLuhn(cleanNum)) {
    errors.cardNumber = 'Invalid card number (checksum failed)';
  }

  // Expiry check MM/YY
  const expiryMatch = expiry.trim().match(/^(0[1-9]|1[0-2])\/?([0-9]{2})$/);
  if (!expiryMatch) {
    errors.expiry = 'Use MM/YY format';
  } else {
    const month = parseInt(expiryMatch[1], 10);
    const year = 2000 + parseInt(expiryMatch[2], 10);
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1;
    if (year < currentYear || (year === currentYear && month < currentMonth)) {
      errors.expiry = 'Card is expired';
    }
  }

  // CVC check
  const cleanCvc = cvc.replace(/\D/g, '');
  if (cleanCvc.length < 3 || cleanCvc.length > 4) {
    errors.cvc = 'CVC must be 3 or 4 digits';
  }

  if (!name.trim()) {
    errors.name = 'Cardholder name is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

export function canAddToCart(
  currentStock: number,
  quantityToAdd: number,
  inCartQuantity = 0
): { allowed: boolean; maxAvailable: number; message?: string } {
  const totalRequested = inCartQuantity + quantityToAdd;
  if (currentStock <= 0) {
    return { allowed: false, maxAvailable: 0, message: 'Item is currently out of stock' };
  }
  if (totalRequested > currentStock) {
    const remaining = Math.max(0, currentStock - inCartQuantity);
    return {
      allowed: false,
      maxAvailable: remaining,
      message: `Only ${currentStock} available in store (${remaining} more can be added)`,
    };
  }
  return { allowed: true, maxAvailable: currentStock - inCartQuantity };
}

export function generateOrderNumber(): string {
  const randomPart = Math.floor(10000 + Math.random() * 90000);
  return `CP-${randomPart}`;
}

/**
 * Generate responsive HTML email for order stages
 */
export function generateEmailHtml(order: Order, stage: OrderStatus): { subject: string; previewText: string; html: string } {
  const itemsListHtml = order.items
    .map(
      (item) => `
      <tr style="border-bottom: 1px solid #f1f5f9;">
        <td style="padding: 12px 0; font-size: 14px; color: #1e293b;">
          <strong>${item.quantity}x</strong> ${item.product.name}
          <div style="font-size: 12px; color: #64748b;">${item.product.unit} · SKU: ${item.product.sku}</div>
        </td>
        <td style="padding: 12px 0; text-align: right; font-size: 14px; font-weight: 600; color: #0f172a;">
          $${(item.product.price * item.quantity).toFixed(2)}
        </td>
      </tr>
    `
    )
    .join('');

  let subject = '';
  let previewText = '';
  let heroIcon = '🛒';
  let heroTitle = '';
  let heroDesc = '';
  let statusBadgeColor = '#10b981';

  switch (stage) {
    case 'order_confirmed':
      subject = `Order Confirmed: #${order.orderNumber} - Cornerstone Provisions`;
      previewText = `We have received your grocery order #${order.orderNumber} for $${order.total.toFixed(2)}.`;
      heroIcon = '✨';
      heroTitle = 'Order Confirmed & Payment Verified';
      heroDesc = 'Thank you for shopping with Cornerstone Provisions & Market. Our store team is preparing your basket with the freshest hand-selected goods.';
      statusBadgeColor = '#0284c7';
      break;
    case 'picked_packed':
      subject = `Picked & Freshly Packed: #${order.orderNumber}`;
      previewText = `Your items have been hand-picked and insulated for peak freshness.`;
      heroIcon = '📦';
      heroTitle = 'Your Basket is Packed & Sealed';
      heroDesc = 'Every produce item and dairy product has passed temperature and quality checks. Your bag is sealed and staged in our climate-controlled dispatch station.';
      statusBadgeColor = '#8b5cf6';
      break;
    case 'out_for_delivery':
      subject = `Out for Delivery: Driver Arriving in ~${order.driver?.etaMinutes || 20} mins!`;
      previewText = `${order.driver?.name || 'Your driver'} is en route to ${order.deliveryAddress.street}.`;
      heroIcon = '🚚';
      heroTitle = 'Your Groceries are On the Way!';
      heroDesc = `${order.driver?.name || 'Driver Alex M.'} (${order.driver?.vehicle || 'Hybrid Van #12'}) is currently on the delivery route. Estimated arrival in ${order.driver?.etaMinutes || 18} minutes.`;
      statusBadgeColor = '#f59e0b';
      break;
    case 'delivered':
      subject = `Delivered! Your Cornerstone Provisions order #${order.orderNumber}`;
      previewText = `Your delivery has arrived at your door. Enjoy your fresh groceries!`;
      heroIcon = '🎉';
      heroTitle = 'Package Delivered Safely';
      heroDesc = `Your order #${order.orderNumber} was delivered to ${order.deliveryAddress.street} (${order.deliveryAddress.apt ? order.deliveryAddress.apt + ', ' : ''}${order.deliveryAddress.city}). You earned ${order.pointsEarned} loyalty points!`;
      statusBadgeColor = '#10b981';
      break;
    case 'cancelled':
      subject = `Order Cancelled & Refunded: #${order.orderNumber}`;
      previewText = `Your order #${order.orderNumber} has been cancelled and refunded.`;
      heroIcon = '⚠️';
      heroTitle = 'Order Cancelled';
      heroDesc = 'Your order has been cancelled and full payment has been refunded to your original payment method.';
      statusBadgeColor = '#ef4444';
      break;
  }

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 24px 12px; color: #1e293b;">
  <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.06); border: 1px solid #e2e8f0;">
    <!-- Header -->
    <tr>
      <td style="background: linear-gradient(135deg, #064e3b 0%, #047857 100%); padding: 28px 24px; text-align: center; color: #ffffff;">
        <div style="font-size: 11px; letter-spacing: 2px; text-transform: uppercase; font-weight: 700; color: #a7f3d0; margin-bottom: 6px;">
          CORNERSTONE PROVISIONS &amp; MARKET
        </div>
        <div style="font-size: 32px; margin-bottom: 8px;">${heroIcon}</div>
        <h1 style="margin: 0; font-size: 22px; font-weight: 700; color: #ffffff;">${heroTitle}</h1>
        <p style="margin: 8px 0 0; font-size: 14px; color: #d1fae5; line-height: 1.5;">${heroDesc}</p>
      </td>
    </tr>

    <!-- Status pill & Order info -->
    <tr>
      <td style="padding: 20px 24px; background-color: #f1f5f9; border-bottom: 1px solid #e2e8f0;">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td>
              <span style="display: inline-block; padding: 4px 12px; font-size: 12px; font-weight: 700; text-transform: uppercase; border-radius: 9999px; background-color: ${statusBadgeColor}; color: #ffffff;">
                ${stage.replace(/_/g, ' ')}
              </span>
            </td>
            <td style="text-align: right; font-size: 13px; color: #475569;">
              Order <strong>#${order.orderNumber}</strong>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- Driver Card if out for delivery -->
    ${
      stage === 'out_for_delivery' && order.driver
        ? `
    <tr>
      <td style="padding: 16px 24px; background-color: #fffbeb; border-bottom: 1px solid #fef3c7;">
        <div style="font-size: 13px; font-weight: 700; color: #92400e; margin-bottom: 4px;">Assigned Delivery Courier</div>
        <div style="font-size: 14px; color: #78350f;">
          <strong>${order.driver.name}</strong> · ${order.driver.vehicle}
          <br/>
          <span style="color: #b45309; font-size: 12px;">ETA: ~${order.driver.etaMinutes} mins • Current location: ${order.driver.currentLocation}</span>
        </div>
      </td>
    </tr>
    `
        : ''
    }

    <!-- Delivery Address -->
    <tr>
      <td style="padding: 20px 24px 10px;">
        <div style="font-size: 12px; text-transform: uppercase; font-weight: 700; color: #64748b; letter-spacing: 1px; margin-bottom: 4px;">
          Delivery Destination
        </div>
        <div style="font-size: 14px; font-weight: 600; color: #0f172a;">
          ${order.customerName}
        </div>
        <div style="font-size: 14px; color: #475569; line-height: 1.4;">
          ${order.deliveryAddress.street} ${order.deliveryAddress.apt ? '(' + order.deliveryAddress.apt + ')' : ''}<br>
          ${order.deliveryAddress.city}, ${order.deliveryAddress.zip}
        </div>
        ${order.deliveryAddress.notes ? `<div style="margin-top: 6px; font-size: 12px; color: #64748b; font-style: italic;">Instructions: "${order.deliveryAddress.notes}"</div>` : ''}
      </td>
    </tr>

    <!-- Order Items -->
    <tr>
      <td style="padding: 10px 24px 20px;">
        <div style="font-size: 12px; text-transform: uppercase; font-weight: 700; color: #64748b; letter-spacing: 1px; margin-bottom: 8px;">
          Itemized Summary (${order.items.length} items)
        </div>
        <table width="100%" cellpadding="0" cellspacing="0">
          ${itemsListHtml}
        </table>
      </td>
    </tr>

    <!-- Totals Table -->
    <tr>
      <td style="padding: 16px 24px; background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
        <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 14px; color: #475569;">
          <tr>
            <td style="padding: 4px 0;">Subtotal</td>
            <td style="padding: 4px 0; text-align: right; color: #0f172a;">$${order.subtotal.toFixed(2)}</td>
          </tr>
          ${
            order.discount > 0
              ? `
          <tr>
            <td style="padding: 4px 0; color: #16a34a;">Savings & Discounts</td>
            <td style="padding: 4px 0; text-align: right; color: #16a34a;">-$${order.discount.toFixed(2)}</td>
          </tr>
          `
              : ''
          }
          <tr>
            <td style="padding: 4px 0;">Delivery Fee (${order.deliveryType})</td>
            <td style="padding: 4px 0; text-align: right; color: #0f172a;">${order.deliveryFee === 0 ? '<span style="color:#16a34a; font-weight:600;">FREE</span>' : '$' + order.deliveryFee.toFixed(2)}</td>
          </tr>
          <tr>
            <td style="padding: 4px 0;">Estimated Sales Tax</td>
            <td style="padding: 4px 0; text-align: right; color: #0f172a;">$${order.tax.toFixed(2)}</td>
          </tr>
          ${
            order.tip > 0
              ? `
          <tr>
            <td style="padding: 4px 0;">Driver Tip</td>
            <td style="padding: 4px 0; text-align: right; color: #0f172a;">$${order.tip.toFixed(2)}</td>
          </tr>
          `
              : ''
          }
          <tr style="border-top: 1px solid #cbd5e1; font-size: 16px; font-weight: 700; color: #0f172a;">
            <td style="padding: 12px 0 4px;">Total Paid</td>
            <td style="padding: 12px 0 4px; text-align: right; color: #064e3b; font-size: 18px;">$${order.total.toFixed(2)}</td>
          </tr>
          <tr>
            <td colspan="2" style="padding-top: 8px; font-size: 12px; color: #059669; font-weight: 600;">
              ⭐ +${order.pointsEarned} Cornerstone Loyalty Points Earned
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- Footer -->
    <tr>
      <td style="padding: 24px; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0; line-height: 1.5;">
        <div style="font-weight: 600; color: #475569; margin-bottom: 4px;">Cornerstone Provisions &amp; Market</div>
        742 Evergreen Terrace, Suite 100 · Fresh Groceries &amp; Daily Staples<br>
        Questions? Contact customer care at support@cornerstoneprovisions.com<br>
        <span style="font-size: 11px; color: #cbd5e1; display: inline-block; margin-top: 8px;">Order Reference: ${order.id} · Transaction ${order.paymentMethod.transactionId}</span>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();

  return { subject, previewText, html };
}
