import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculatePlannerStats,
  groupTasksByEisenhower,
  suggestNextPhysicalAction,
  formatIfThenIntention,
  calculateStreak,
  formatFocusTime,
  calculateScheduleLoad,
} from './plannerLogic.ts';
import type { TaskItem, HabitItem } from '../types/planner.ts';

test('calculatePlannerStats calculates accurate totals, top 3, and completion rate', () => {
  const mockTasks: TaskItem[] = [
    {
      id: '1',
      title: 'Top task 1',
      category: 'top3',
      completed: true,
      priority: 'urgent-important',
      dateAdded: '2026-10-20',
    },
    {
      id: '2',
      title: 'Top task 2',
      category: 'top3',
      completed: false,
      priority: 'important-not-urgent',
      dateAdded: '2026-10-20',
    },
    {
      id: '3',
      title: 'Quick win',
      category: 'under-2-min',
      completed: true,
      priority: 'urgent-important',
      dateAdded: '2026-10-20',
    },
    {
      id: '4',
      title: 'Waiting for invoice from Ali',
      category: 'waiting-for',
      completed: false,
      priority: 'important-not-urgent',
      dateAdded: '2026-10-20',
    },
    {
      id: '5',
      title: 'Random thought during focus',
      category: 'parking-lot',
      completed: false,
      priority: 'not-urgent-not-important',
      dateAdded: '2026-10-20',
    },
  ];

  const mockHabits: HabitItem[] = [
    {
      id: 'h1',
      name: 'Evening shutdown',
      description: '10 min review',
      category: 'daily',
      currentStreak: 5,
      bestStreak: 12,
      completedDates: {},
    },
    {
      id: 'h2',
      name: '15-min space reset',
      description: 'Tidy desk',
      category: 'weekly',
      currentStreak: 3,
      bestStreak: 4,
      completedDates: {},
    },
  ];

  const stats = calculatePlannerStats(mockTasks, mockHabits);

  assert.equal(stats.totalTasks, 5);
  assert.equal(stats.completedTasks, 2);
  assert.equal(stats.openLoops, 3);
  assert.equal(stats.taskCompletionRate, 40);
  assert.equal(stats.top3Total, 2);
  assert.equal(stats.completedTop3, 1);
  assert.equal(stats.waitingForCount, 1);
  assert.equal(stats.parkingLotCount, 1);
  assert.equal(stats.currentTotalStreak, 8);
});

test('groupTasksByEisenhower categorizes tasks across all 4 quadrants', () => {
  const tasks: TaskItem[] = [
    { id: '1', title: 'Fire drill', category: 'inbox', completed: false, priority: 'urgent-important', dateAdded: '2026-10-20' },
    { id: '2', title: 'Deep strategy', category: 'inbox', completed: false, priority: 'important-not-urgent', dateAdded: '2026-10-20' },
    { id: '3', title: 'Phone call interruption', category: 'inbox', completed: false, priority: 'urgent-not-important', dateAdded: '2026-10-20' },
    { id: '4', title: 'Social media rabbit hole', category: 'not-to-do', completed: false, priority: 'not-urgent-not-important', dateAdded: '2026-10-20' },
  ];

  const groups = groupTasksByEisenhower(tasks);

  assert.equal(groups['urgent-important'].length, 1);
  assert.equal(groups['important-not-urgent'].length, 1);
  assert.equal(groups['urgent-not-important'].length, 1);
  assert.equal(groups['not-urgent-not-important'].length, 1);
});

test('suggestNextPhysicalAction produces actionable next step recommendations', () => {
  assert.match(suggestNextPhysicalAction('taxes 2026'), /Open spreadsheet and log receipts/i);
  assert.match(suggestNextPhysicalAction('grocery shopping'), /Check pantry and write shopping list/i);
  assert.match(suggestNextPhysicalAction('clean garage'), /Set 15-min timer and clear physical surfaces/i);
  assert.equal(suggestNextPhysicalAction('Email Ali the invoice'), 'Email Ali the invoice');
});

test('formatIfThenIntention formats clean implementation triggers', () => {
  const formatted = formatIfThenIntention('it is 9:00 AM', 'I open my top 3 list and start focus block 1');
  assert.equal(formatted, 'If it is 9:00 AM, then I will open my top 3 list and start focus block 1');
});

test('calculateScheduleLoad enforces the 60-70% planning rule to avoid overpacking', () => {
  const lightTasks: TaskItem[] = [
    { id: '1', title: 'Deep Work A', category: 'top3', completed: false, priority: 'important-not-urgent', estimatedMinutes: 90, dateAdded: '2026-10-20' },
    { id: '2', title: 'Deep Work B', category: 'top3', completed: false, priority: 'important-not-urgent', estimatedMinutes: 90, dateAdded: '2026-10-20' },
    { id: '3', title: 'Batch Admin', category: 'top3', completed: false, priority: 'important-not-urgent', estimatedMinutes: 60, dateAdded: '2026-10-20' },
  ]; // Total 240 mins = 4 hours out of 8 = 50% load

  const lightLoad = calculateScheduleLoad(lightTasks, 8);
  assert.equal(lightLoad.status, 'optimal');
  assert.equal(lightLoad.loadPercentage, 50);

  const heavyTasks: TaskItem[] = Array.from({ length: 8 }, (_, i) => ({
    id: `heavy-${i}`,
    title: `Task ${i}`,
    category: 'inbox',
    completed: false,
    priority: 'urgent-important',
    estimatedMinutes: 60,
    dateAdded: '2026-10-20',
  })); // Total 8 hours = 100% load

  const heavyLoad = calculateScheduleLoad(heavyTasks, 8);
  assert.equal(heavyLoad.status, 'overloaded');
  assert.equal(heavyLoad.loadPercentage, 100);
});

test('formatFocusTime formats mm:ss correctly', () => {
  assert.equal(formatFocusTime(1500), '25:00');
  assert.equal(formatFocusTime(300), '05:00');
  assert.equal(formatFocusTime(63), '01:03');
});
