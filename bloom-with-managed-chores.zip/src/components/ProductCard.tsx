import React from 'react';
import { Plus, Minus, AlertCircle, CheckCircle2, Eye, Sparkles } from 'lucide-react';
import { Product } from '../types/store';

interface ProductCardProps {
  product: Product;
  quantityInCart: number;
  onAddToCart: (product: Product) => void;
  onUpdateQuantity: (productId: string, newQty: number) => void;
  onQuickView: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  quantityInCart,
  onAddToCart,
  onUpdateQuantity,
  onQuickView,
}) => {
  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= product.lowStockThreshold;

  return (
    <div className="group relative bg-white rounded-2xl border border-slate-200/80 hover:border-emerald-300 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-200 flex flex-col overflow-hidden">
      
      {/* Top Badges & Quick View */}
      <div className="relative aspect-[4/3] bg-slate-100 overflow-hidden cursor-pointer" onClick={() => onQuickView(product)}>
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

        {/* Category & Tags Pill */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {product.nutrition?.organic && (
            <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-600 text-white shadow-sm">
              <Sparkles className="w-2.5 h-2.5" /> Organic
            </span>
          )}
          {product.originalPrice && product.originalPrice > product.price && (
            <span className="inline-flex text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-rose-600 text-white shadow-sm">
              Sale -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
            </span>
          )}
        </div>

        {/* Quick View Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onQuickView(product);
          }}
          className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-white/90 text-slate-700 hover:text-emerald-700 hover:bg-white shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
          title="Quick inspect product details & nutrition"
          aria-label={`View details for ${product.name}`}
        >
          <Eye className="w-4 h-4" />
        </button>

        {/* Real-time Inventory Badge */}
        <div className="absolute bottom-2 left-2 right-2">
          {isOutOfStock ? (
            <div className="flex items-center justify-center gap-1 py-1 px-2.5 rounded-lg bg-rose-950/85 text-rose-200 backdrop-blur-md text-[11px] font-bold">
              <AlertCircle className="w-3.5 h-3.5 text-rose-400" /> Out of Stock
            </div>
          ) : isLowStock ? (
            <div className="flex items-center justify-between py-1 px-2.5 rounded-lg bg-amber-950/85 text-amber-200 backdrop-blur-md text-[11px] font-bold">
              <span className="flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                Only {product.stock} left in store
              </span>
              <span className="text-[10px] text-amber-300 font-mono">Restocking</span>
            </div>
          ) : (
            <div className="flex items-center justify-between py-0.5 px-2 rounded-lg bg-emerald-950/70 text-emerald-200 backdrop-blur-md text-[10px] font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" /> In Stock ({product.stock})
              </span>
              <span className="text-[10px] text-emerald-300">{product.aisle.split('-')[0].trim()}</span>
            </div>
          )}
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Aisle location */}
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>{product.category}</span>
            <span className="text-slate-400">{product.unit}</span>
          </div>

          {/* Product Name */}
          <h3 
            onClick={() => onQuickView(product)}
            className="font-bold text-slate-900 text-sm leading-snug hover:text-emerald-700 cursor-pointer line-clamp-2 mb-1.5 transition-colors"
          >
            {product.name}
          </h3>

          <p className="text-xs text-slate-500 line-clamp-2 mb-3 leading-relaxed">
            {product.description}
          </p>
        </div>

        <div>
          {/* Price & Action Section */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-lg font-extrabold text-slate-900">
                  ${product.price.toFixed(2)}
                </span>
                {product.originalPrice && product.originalPrice > product.price && (
                  <span className="text-xs text-slate-400 line-through">
                    ${product.originalPrice.toFixed(2)}
                  </span>
                )}
              </div>
              <div className="text-[10px] text-slate-400 font-medium">
                {product.unit}
              </div>
            </div>

            {/* Cart Controller */}
            {isOutOfStock ? (
              <button
                disabled
                className="px-3 py-2 bg-slate-100 text-slate-400 text-xs font-semibold rounded-xl cursor-not-allowed border border-slate-200"
              >
                Sold Out
              </button>
            ) : quantityInCart > 0 ? (
              <div className="flex items-center bg-emerald-50 border border-emerald-300 rounded-xl p-0.5">
                <button
                  onClick={() => onUpdateQuantity(product.id, quantityInCart - 1)}
                  className="w-7 h-7 flex items-center justify-center text-emerald-800 hover:bg-emerald-200 rounded-lg transition"
                  aria-label={`Decrease ${product.name} quantity`}
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-7 text-center font-bold text-xs text-emerald-950">
                  {quantityInCart}
                </span>
                <button
                  onClick={() => {
                    if (quantityInCart < product.stock) {
                      onUpdateQuantity(product.id, quantityInCart + 1);
                    }
                  }}
                  disabled={quantityInCart >= product.stock}
                  className={`w-7 h-7 flex items-center justify-center rounded-lg transition ${
                    quantityInCart >= product.stock
                      ? 'text-slate-300 cursor-not-allowed'
                      : 'text-emerald-800 hover:bg-emerald-200'
                  }`}
                  aria-label={`Increase ${product.name} quantity`}
                  title={quantityInCart >= product.stock ? 'Maximum stock reached' : undefined}
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => onAddToCart(product)}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-sm shadow-emerald-700/20 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
