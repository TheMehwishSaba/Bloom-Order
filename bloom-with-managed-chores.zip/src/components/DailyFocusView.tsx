import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  CheckCircle2, 
  Circle, 
  Clock, 
  Sparkles, 
  Zap, 
  Volume2, 
  ShieldCheck, 
  Coffee, 
  Check, 
  Plus,
  Flame,
  ArrowRight,
  Bell,
  Sliders,
  Award
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { TaskItem } from '../types/planner';
import { formatFocusTime } from '../utils/plannerLogic';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';

interface DailyFocusViewProps {
  tasks: TaskItem[];
  onToggleTask: (taskId: string) => void;
  onAddTask: (task: Partial<TaskItem>) => void;
}

export function DailyFocusView({
  tasks,
  onToggleTask,
  onAddTask,
}: DailyFocusViewProps) {
  // Timer settings
  const [selectedFocusMinutes, setSelectedFocusMinutes] = useState<number>(25); // 25 to 50 minutes
  const [isBreak, setIsBreak] = useState(false);
  const [selectedBreakMinutes, setSelectedBreakMinutes] = useState<number>(5);
  const [timeRemaining, setTimeRemaining] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);

  // Pomodoro cycle tracking (1 to 4 sessions, then long break)
  const [completedSessionsToday, setCompletedSessionsToday] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('bloom_pomodoros_completed_today');
      return saved ? parseInt(saved, 10) : 2;
    } catch {
      return 2;
    }
  });

  // Alarm notification banner state
  const [alarmBanner, setAlarmBanner] = useState<{
    show: boolean;
    type: 'focus' | 'break';
    message: string;
  }>({
    show: false,
    type: 'focus',
    message: '',
  });

  // Selected task in focus
  const [activeTaskId, setActiveTaskId] = useState<string>(
    tasks.find(t => t.category === 'top3' && !t.completed)?.id || tasks[0]?.id || ''
  );

  // Start Ritual Checklist (Directly from user prompt rules)
  const [ritualState, setRitualState] = useState({
    waterReady: true,
    deskClear: true,
    phoneOutOfSight: false,
    oneTabOpen: false,
    timerEngaged: false,
  });

  // Parking lot quick entry
  const [parkingLotInput, setParkingLotInput] = useState('');

  // Handle timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    } else if (timeRemaining === 0 && isRunning) {
      setIsRunning(false);

      if (!isBreak) {
        // Focus session ended! Trigger gentle alarm
        playGentleChime('alarm-gentle');
        const newCount = completedSessionsToday + 1;
        setCompletedSessionsToday(newCount);
        try {
          localStorage.setItem('bloom_pomodoros_completed_today', String(newCount));
        } catch {
          // ignore
        }

        confetti({
          particleCount: 65,
          spread: 70,
          origin: { y: 0.65 },
          colors: ['#8C3246', '#DDA5A5', '#616D48', '#FAF6F0'],
        });

        // Trigger browser notification if supported
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification('Focus Block Completed 🌸', {
            body: `Gentle chime: Wonderful work! Your ${selectedFocusMinutes}m session is complete. Time for a peaceful break.`,
            icon: '/assets/botanical_still_life.jpg',
          });
        }

        setAlarmBanner({
          show: true,
          type: 'focus',
          message: `Focus block complete! Your gentle botanical chime just sounded. Step away, stretch, and nourish your calm before the next block.`,
        });
      } else {
        // Break ended!
        playGentleChime('break-end');
        setAlarmBanner({
          show: true,
          type: 'break',
          message: `Break period completed. Ready to anchor your next 25-50 minute focus block?`,
        });
      }
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeRemaining, isBreak, completedSessionsToday, selectedFocusMinutes]);

  const requestNotificationPermission = () => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      Notification.requestPermission();
    }
  };

  const handleSetFocusMinutes = (minutes: number) => {
    setIsBreak(false);
    setSelectedFocusMinutes(minutes);
    setTimeRemaining(minutes * 60);
    setIsRunning(false);
    setAlarmBanner(prev => ({ ...prev, show: false }));
  };

  const handleSetBreak = (minutes: number) => {
    setIsBreak(true);
    setSelectedBreakMinutes(minutes);
    setTimeRemaining(minutes * 60);
    setIsRunning(false);
    setAlarmBanner(prev => ({ ...prev, show: false }));
  };

  const toggleTimer = () => {
    if (!isRunning) {
      setRitualState(prev => ({ ...prev, timerEngaged: true }));
      playGentleChime('sparkle');
      requestNotificationPermission();
    }
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    if (!isBreak) {
      setTimeRemaining(selectedFocusMinutes * 60);
    } else {
      setTimeRemaining(selectedBreakMinutes * 60);
    }
  };

  const handleAddParkingLot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!parkingLotInput.trim()) return;

    onAddTask({
      title: parkingLotInput.trim(),
      category: 'parking-lot',
      priority: 'not-urgent-not-important',
      completed: false,
      dateAdded: new Date().toISOString().split('T')[0],
    });

    setParkingLotInput('');
    playGentleChime('sparkle');
  };

  const activeTask = tasks.find(t => t.id === activeTaskId);
  const doneTasks = tasks.filter(t => t.completed);

  return (
    <div className="space-y-6">
      
      {/* Gentle Alarm Alert Banner (When session completes) */}
      {alarmBanner.show && (
        <div className="relative rounded-2xl bg-gradient-to-r from-[#8C3246] to-[#A33E53] text-[#FAF6F0] p-4 sm:p-5 shadow-md border-2 border-[#DDA5A5] flex flex-col sm:flex-row items-center justify-between gap-4 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center shrink-0">
              <Bell className="w-5 h-5 text-[#FAF6F0] animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-serif-cormorant text-lg font-bold">
                  {alarmBanner.type === 'focus' ? 'Gentle Focus Chime Sounded 🌸' : 'Break Finished 🌿'}
                </h4>
                <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/20 text-[#FAF6F0]">
                  Gentle Alarm Notification
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#F9EFF1] mt-0.5">
                {alarmBanner.message}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            <button
              onClick={() => playGentleChime('alarm-gentle')}
              className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-[#FAF6F0] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Play gentle chime sound again"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Replay Chime</span>
            </button>

            {alarmBanner.type === 'focus' ? (
              <button
                onClick={() => {
                  handleSetBreak(5);
                  setIsRunning(true);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-[#FAF6F0] text-[#8C3246] hover:bg-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Start 5m Break
              </button>
            ) : (
              <button
                onClick={() => {
                  handleSetFocusMinutes(25);
                  setIsRunning(true);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-[#FAF6F0] text-[#8C3246] hover:bg-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Start Next Block
              </button>
            )}

            <button
              onClick={() => setAlarmBanner(prev => ({ ...prev, show: false }))}
              className="px-2.5 py-1.5 rounded-xl text-white/70 hover:text-white text-xs transition-colors cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Top Focus & Flow Principle Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-[#FAF0F2] via-[#FAF6F0] to-[#EDF2E8] border border-[#EADBCE] p-5 sm:p-6 shadow-xs overflow-hidden">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-24 h-24 text-[#8C3246]/20" />
        <div className="max-w-2xl">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#8C3246] flex items-center gap-1.5">
            <PeonyIcon className="w-4 h-4" />
            Hour-by-Hour Focus Discipline
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif-cormorant font-bold text-[#2D2326] mt-1">
            25–50 Minute Pomodoro Focus Blocks
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-[#5C4F51]">
            "Work in blocks of 25 to 50 minutes with a 5 to 10 minute break. Put your most important task in your first block, when your energy is best." A gentle singing chime notifies you when the block ends.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: The Pomodoro Focus Timer & Active Task */}
        <div className="lg:col-span-2 space-y-5">
          
          {/* Main Focus Timer Card */}
          <div className="bg-white rounded-3xl border-2 border-[#EADBCE] p-6 sm:p-8 text-center shadow-xs relative overflow-hidden">
            
            {/* Mode & Duration Preset Selectors */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#786C6E] mr-1 hidden sm:inline">
                  Focus:
                </span>
                {[
                  { mins: 25, label: '25m Classic Pomodoro' },
                  { mins: 35, label: '35m Mid Block' },
                  { mins: 45, label: '45m Deep Block' },
                  { mins: 50, label: '50m Ultradian Deep Work' },
                ].map(item => (
                  <button
                    key={item.mins}
                    onClick={() => handleSetFocusMinutes(item.mins)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-150 cursor-pointer ${
                      !isBreak && selectedFocusMinutes === item.mins
                        ? 'bg-[#8C3246] text-white shadow-xs font-semibold scale-102'
                        : 'bg-[#FAF6F0] text-[#5C4F51] hover:bg-[#F3E1E4]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Rest Intervals */}
              <div className="flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap pt-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#786C6E] mr-1 hidden sm:inline">
                  Rest:
                </span>
                {[
                  { mins: 5, label: '5m Short Break' },
                  { mins: 10, label: '10m Tea & Rest' },
                  { mins: 15, label: '15m Reset Walk' },
                ].map(item => (
                  <button
                    key={item.mins}
                    onClick={() => handleSetBreak(item.mins)}
                    className={`px-3 py-1 rounded-xl text-xs font-medium transition-all duration-150 cursor-pointer ${
                      isBreak && selectedBreakMinutes === item.mins
                        ? 'bg-[#616D48] text-white shadow-xs font-semibold'
                        : 'bg-[#EDF2E8] text-[#4B5634] hover:bg-[#DEE7D7]'
                    }`}
                  >
                    <Coffee className="w-3.5 h-3.5 inline mr-1" />
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Slider for fine adjustment between 25 and 50 minutes */}
              {!isBreak && (
                <div className="max-w-xs mx-auto pt-2 flex items-center justify-center gap-3">
                  <span className="text-[11px] text-[#786C6E] font-medium">Adjust: 25m</span>
                  <input
                    type="range"
                    min="25"
                    max="50"
                    step="5"
                    value={selectedFocusMinutes}
                    onChange={(e) => handleSetFocusMinutes(parseInt(e.target.value, 10))}
                    className="w-36 accent-[#8C3246] cursor-pointer"
                  />
                  <span className="text-[11px] text-[#786C6E] font-medium">50m ({selectedFocusMinutes}m)</span>
                </div>
              )}
            </div>

            {/* Giant Clock Face */}
            <div className="my-5">
              <div className="font-serif-cormorant text-7xl sm:text-8xl font-bold tracking-tight text-[#2D2326]">
                {formatFocusTime(timeRemaining)}
              </div>
              <p className="text-xs uppercase tracking-widest text-[#786C6E] mt-2 font-medium">
                {isRunning ? (
                  !isBreak 
                    ? `Deep Focus Session • ${selectedFocusMinutes}m Block in Progress` 
                    : `Restorative Break • ${selectedBreakMinutes}m Relaxing`
                ) : (
                  `Timer Paused • Ready to Begin ${isBreak ? 'Break' : `${selectedFocusMinutes}m Block`}`
                )}
              </p>
            </div>

            {/* Pomodoro Cycles Completed Today */}
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="text-xs text-[#786C6E] font-medium">Today's Cycles:</span>
              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5, 6].map(num => (
                  <div
                    key={num}
                    title={`Pomodoro Session ${num}`}
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs transition-all ${
                      num <= completedSessionsToday
                        ? 'bg-[#8C3246] text-white shadow-xs'
                        : 'bg-[#FAF6F0] border border-[#EADBCE] text-[#786C6E]'
                    }`}
                  >
                    {num <= completedSessionsToday ? '🌸' : num}
                  </div>
                ))}
              </div>
              <span className="text-xs font-semibold text-[#8C3246] ml-1">
                {completedSessionsToday} completed
              </span>
            </div>

            {/* Controls: Play, Pause, Reset, Test Gentle Chime */}
            <div className="flex items-center justify-center gap-3 mt-5 flex-wrap">
              <button
                onClick={toggleTimer}
                className={`px-8 py-3.5 rounded-2xl text-white font-medium text-sm sm:text-base flex items-center gap-2 shadow-sm transition-all duration-150 active:scale-95 cursor-pointer ${
                  isRunning ? 'bg-[#535E3B] hover:bg-[#444E2F]' : 'bg-[#8C3246] hover:bg-[#732738]'
                }`}
              >
                {isRunning ? (
                  <>
                    <Pause className="w-5 h-5" />
                    <span>Pause Block</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>Start {isBreak ? 'Break' : 'Focus Block'}</span>
                  </>
                )}
              </button>

              <button
                onClick={resetTimer}
                className="p-3.5 rounded-2xl bg-[#FAF6F0] hover:bg-[#EADBCE] text-[#5C4F51] transition-colors cursor-pointer"
                title="Reset timer to start of block"
              >
                <RotateCcw className="w-5 h-5" />
              </button>

              <button
                onClick={() => {
                  playGentleChime('alarm-gentle');
                  confetti({ particleCount: 20, spread: 40 });
                }}
                className="px-3.5 py-3 rounded-2xl bg-[#FAF6F0] hover:bg-[#F3E1E4] border border-[#DDA5A5] text-[#8C3246] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Preview the soothing gentle singing chime alarm"
              >
                <Volume2 className="w-4 h-4" />
                <span>Test Alarm Chime</span>
              </button>
            </div>

            {/* Currently Active Task Anchor */}
            <div className="mt-8 pt-6 border-t border-[#EADBCE]/80 text-left bg-[#FAF6F0] rounded-2xl p-4 sm:p-5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#8C3246]">
                  Active Focus Target
                </span>
                
                {/* Task picker dropdown */}
                <select
                  value={activeTaskId}
                  onChange={(e) => setActiveTaskId(e.target.value)}
                  className="text-xs bg-white border border-[#EADBCE] rounded-lg px-2.5 py-1 text-[#2D2326] cursor-pointer"
                >
                  <option value="">-- Choose Task To Anchor --</option>
                  {tasks.filter(t => !t.completed).map(t => (
                    <option key={t.id} value={t.id}>
                      {t.category === 'top3' ? '★ ' : ''}{t.title}
                    </option>
                  ))}
                </select>

                {activeTask && (
                  <button
                    onClick={() => {
                      onToggleTask(activeTask.id);
                      playGentleChime('success');
                      confetti({ particleCount: 35, spread: 55 });
                    }}
                    className="text-xs text-[#616D48] hover:text-[#4B5634] font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Mark Finished
                  </button>
                )}
              </div>

              {activeTask ? (
                <div className="mt-2.5">
                  <h3 className="font-serif-cormorant text-xl font-bold text-[#2D2326]">
                    {activeTask.title}
                  </h3>
                  {activeTask.nextPhysicalAction && (
                    <div className="mt-1.5 flex items-center gap-2 text-xs text-[#535E3B] bg-white px-3 py-1.5 rounded-lg border border-[#EADBCE]">
                      <Zap className="w-4 h-4 text-[#8C3246] shrink-0" />
                      <span>Next physical action:</span>
                      <strong className="text-[#2D2326]">{activeTask.nextPhysicalAction}</strong>
                    </div>
                  )}
                  {activeTask.definitionOfDone && (
                    <div className="mt-1 text-xs text-[#786C6E] pl-1">
                      <em>Definition of Done:</em> {activeTask.definitionOfDone}
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-xs text-[#786C6E] mt-1">
                  No active task selected. Anchor a top priority above so you commit to one thing at a time.
                </p>
              )}
            </div>
          </div>

          {/* Quick Parking Lot Note (Capture distractions immediately without leaving focus) */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-4 sm:p-5 shadow-xs">
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#C28255]" />
                <h4 className="font-serif-cormorant text-base font-bold text-[#2D2326]">
                  Mid-Focus "Parking Lot" Box
                </h4>
              </div>
              <span className="text-[11px] text-[#786C6E] italic">
                Rule: Write down distracting thoughts immediately &amp; return to work
              </span>
            </div>

            <form onSubmit={handleAddParkingLot} className="flex gap-2">
              <input
                type="text"
                placeholder="Stray thought, urge, or task (e.g. check Amazon, text friend, look up recipe)..."
                value={parkingLotInput}
                onChange={(e) => setParkingLotInput(e.target.value)}
                className="flex-1 px-3.5 py-2 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-[#C28255] hover:bg-[#A96D44] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Park Thought
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Start Ritual Checklist & Today's Done List */}
        <div className="space-y-5">
          
          {/* Defend Against Distractions: Start Ritual Checklist */}
          <div className="bg-[#FAF6F0] rounded-2xl border-2 border-[#DDA5A5] p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-5 h-5 text-[#8C3246]" />
              <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                Pre-Block Start Ritual
              </h4>
            </div>
            <p className="text-xs text-[#786C6E] mb-3">
              Defend against distractions before you sit down. Protect your sleep and focus.
            </p>

            <div className="space-y-2.5 text-xs">
              {[
                { key: 'waterReady', label: 'Fresh glass of water or hot tea poured' },
                { key: 'deskClear', label: 'Physical desk cleared of clutter & loose papers' },
                { key: 'phoneOutOfSight', label: 'Phone silenced and placed in another room' },
                { key: 'oneTabOpen', label: 'Single browser tab open for this exact task' },
                { key: 'timerEngaged', label: '25–50m Pomodoro timer engaged' },
              ].map(item => {
                const checked = ritualState[item.key as keyof typeof ritualState];
                return (
                  <div
                    key={item.key}
                    onClick={() => {
                      setRitualState(prev => ({ ...prev, [item.key]: !checked }));
                      if (!checked) playGentleChime('sparkle');
                    }}
                    className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      checked
                        ? 'bg-[#EDF2E8] border-[#616D48]/40 text-[#4B5634]'
                        : 'bg-white border-[#EADBCE] text-[#5C4F51] hover:border-[#DDA5A5]'
                    }`}
                  >
                    <span className="font-medium">{item.label}</span>
                    {checked ? (
                      <CheckCircle2 className="w-4 h-4 text-[#616D48] shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-[#DDA5A5] shrink-0" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Today's Done List (Visual Progress to Defeat Anxiety) */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#8C3246]" />
                <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                  Today's "Done List"
                </h4>
              </div>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-[#EDF2E8] text-[#4B5634]">
                {doneTasks.length} Done
              </span>
            </div>

            <p className="text-xs text-[#786C6E] mb-3">
              Keep a "done list" to celebrate progress and quiet mental loops.
            </p>

            {doneTasks.length === 0 ? (
              <p className="text-xs text-[#9B8F91] italic py-3 text-center">
                No completed tasks yet. Finish your first block to start your done list!
              </p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {doneTasks.map(task => (
                  <div key={task.id} className="p-2 rounded-lg bg-[#FAF6F0] flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#616D48] shrink-0" />
                      <span className="truncate text-[#5C4F51] line-through font-medium">
                        {task.title}
                      </span>
                    </div>
                    <span className="text-[10px] text-[#8C3246] font-semibold shrink-0">
                      Finished
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
