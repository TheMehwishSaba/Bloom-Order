import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Truck, 
  Zap, 
  Store, 
  Award, 
  Tag, 
  ArrowRight,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { CartItem, LoyaltyProfile } from '../types/store';
import { 
  calculateCartTotals, 
  FREE_DELIVERY_THRESHOLD 
} from '../utils/storeLogic';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  loyaltyProfile: LoyaltyProfile;
  promoCode: string;
  onApplyPromoCode: (code: string) => void;
  pointsToRedeem: number;
  onSetPointsToRedeem: (pts: number) => void;
  deliveryType: 'standard' | 'express' | 'pickup';
  onSetDeliveryType: (type: 'standard' | 'express' | 'pickup') => void;
  tipPercentage: number;
  onSetTipPercentage: (tip: number) => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  loyaltyProfile,
  promoCode,
  onApplyPromoCode,
  pointsToRedeem,
  onSetPointsToRedeem,
  deliveryType,
  onSetDeliveryType,
  tipPercentage,
  onSetTipPercentage,
  onProceedToCheckout,
}) => {
  const [promoInput, setPromoInput] = useState(promoCode);
  const [promoMessage, setPromoMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen) return null;

  const totals = calculateCartTotals({
    items,
    promoCode,
    pointsToRedeem,
    deliveryType,
    tipPercentage,
  });

  const handleApplyCode = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promoInput.trim().toUpperCase();
    if (!clean) return;

    if (clean === 'SAVE10') {
      if (totals.subtotal < 30) {
        setPromoMessage({ type: 'error', text: 'SAVE10 requires minimum $30 subtotal' });
      } else {
        onApplyPromoCode(clean);
        setPromoMessage({ type: 'success', text: '10% discount applied!' });
      }
    } else if (clean === 'CORNER20') {
      if (totals.subtotal < 50) {
        setPromoMessage({ type: 'error', text: 'CORNER20 requires minimum $50 subtotal' });
      } else {
        onApplyPromoCode(clean);
        setPromoMessage({ type: 'success', text: '$20.00 store discount applied!' });
      }
    } else if (clean === 'FREESHIP') {
      onApplyPromoCode(clean);
      setPromoMessage({ type: 'success', text: 'Free delivery applied!' });
    } else if (clean === 'PERK5OFF') {
      onApplyPromoCode(clean);
      setPromoMessage({ type: 'success', text: '$5.00 Loyalty Perk applied!' });
    } else {
      setPromoMessage({ type: 'error', text: 'Invalid promo or expired code' });
    }
  };

  const progressPercent = Math.min(100, (totals.subtotal / FREE_DELIVERY_THRESHOLD) * 100);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between overflow-hidden">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-extrabold text-slate-900">Your Fresh Basket</h2>
                <p className="text-xs text-slate-500 font-medium">
                  {totals.itemCount} items · Real-time inventory reserved
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Delivery Meter */}
          <div className="px-5 py-3 bg-emerald-50/70 border-b border-emerald-100 text-xs">
            {totals.isFreeDelivery ? (
              <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>You unlocked FREE Standard Delivery!</span>
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-1 text-slate-700">
                  <span>Add <strong>${totals.amountNeededForFreeDelivery.toFixed(2)}</strong> for FREE delivery</span>
                  <span className="font-bold text-emerald-700">{Math.round(progressPercent)}%</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className="bg-emerald-600 h-1.5 rounded-full transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
            {items.length === 0 ? (
              <div className="text-center py-16 px-4">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4 text-slate-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-slate-800 mb-1">Your basket is empty</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto mb-6">
                  Explore fresh farm produce, artisan bread, pantry essentials, and household goods.
                </p>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              items.map((item) => {
                const isMaxStockReached = item.quantity >= item.product.stock;

                return (
                  <div
                    key={item.product.id}
                    className="flex items-center gap-3 p-3 bg-slate-50/70 hover:bg-slate-50 rounded-2xl border border-slate-200/70 transition"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 rounded-xl object-cover bg-white border border-slate-100 shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-slate-900 text-xs truncate">
                        {item.product.name}
                      </h4>
                      <div className="text-[11px] text-slate-500 mb-1">
                        ${item.product.price.toFixed(2)} / {item.product.unit}
                      </div>

                      {/* Stock limit warning if user has max in cart */}
                      {isMaxStockReached && (
                        <div className="text-[10px] text-amber-700 font-semibold flex items-center gap-1 mb-1">
                          <ShieldAlert className="w-3 h-3 text-amber-600" /> Max store stock ({item.product.stock})
                        </div>
                      )}

                      {/* Quantity Stepper */}
                      <div className="flex items-center gap-2">
                        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xl">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            className="w-6 h-6 flex items-center justify-center text-slate-600 hover:bg-slate-100 rounded"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-xs font-bold text-slate-900">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => {
                              if (!isMaxStockReached) {
                                onUpdateQuantity(item.product.id, item.quantity + 1);
                              }
                            }}
                            disabled={isMaxStockReached}
                            className={`w-6 h-6 flex items-center justify-center rounded ${
                              isMaxStockReached
                                ? 'text-slate-300 cursor-not-allowed'
                                : 'text-slate-600 hover:bg-slate-100'
                            }`}
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.product.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                          title="Remove from basket"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-xs font-extrabold text-slate-900">
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  </div>
                );
              })
            )}

            {items.length > 0 && (
              <div className="pt-2 space-y-4">
                
                {/* Delivery Option Toggle */}
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Fulfillment Method
                  </div>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => onSetDeliveryType('standard')}
                      className={`p-2 rounded-xl text-left border text-xs transition flex flex-col justify-between ${
                        deliveryType === 'standard'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-1 mb-1">
                        <Truck className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-[11px]">Standard</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-normal">
                        {totals.isFreeDelivery ? 'FREE' : '$4.99'} · 45m
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onSetDeliveryType('express')}
                      className={`p-2 rounded-xl text-left border text-xs transition flex flex-col justify-between ${
                        deliveryType === 'express'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-1 mb-1">
                        <Zap className="w-3.5 h-3.5 text-amber-500" />
                        <span className="text-[11px]">Express</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-normal">
                        +$3.99 · 20m
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onSetDeliveryType('pickup')}
                      className={`p-2 rounded-xl text-left border text-xs transition flex flex-col justify-between ${
                        deliveryType === 'pickup'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-1 mb-1">
                        <Store className="w-3.5 h-3.5 text-teal-600" />
                        <span className="text-[11px]">Pickup</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-normal">
                        FREE · 15m
                      </div>
                    </button>
                  </div>
                </div>

                {/* Loyalty Points Redemption Box */}
                {loyaltyProfile.points > 0 && (
                  <div className="bg-amber-50/70 p-3 rounded-2xl border border-amber-200 text-xs">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-amber-950">
                        <Award className="w-4 h-4 text-amber-600" />
                        <span>Cornerstone Rewards</span>
                      </div>
                      <span className="text-[11px] font-semibold text-amber-800">
                        {loyaltyProfile.points} pts available (${(loyaltyProfile.points / 100).toFixed(2)})
                      </span>
                    </div>
                    <p className="text-[11px] text-amber-900/80 mb-2">
                      Redeem 100 points for $1.00 instant cart discount.
                    </p>

                    <div className="flex gap-1.5">
                      <button
                        type="button"
                        onClick={() => onSetPointsToRedeem(0)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                          pointsToRedeem === 0
                            ? 'bg-white border-amber-500 text-amber-950 font-bold shadow-sm'
                            : 'bg-white/60 text-slate-600 border-amber-200'
                        }`}
                      >
                        None
                      </button>
                      {loyaltyProfile.points >= 500 && (
                        <button
                          type="button"
                          onClick={() => onSetPointsToRedeem(500)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                            pointsToRedeem === 500
                              ? 'bg-amber-500 text-white border-amber-600 font-bold shadow-sm'
                              : 'bg-white text-amber-900 border-amber-200 hover:bg-amber-100'
                          }`}
                        >
                          500 pts (-$5)
                        </button>
                      )}
                      {loyaltyProfile.points >= 1000 && (
                        <button
                          type="button"
                          onClick={() => onSetPointsToRedeem(1000)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                            pointsToRedeem === 1000
                              ? 'bg-amber-500 text-white border-amber-600 font-bold shadow-sm'
                              : 'bg-white text-amber-900 border-amber-200 hover:bg-amber-100'
                          }`}
                        >
                          1,000 pts (-$10)
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onSetPointsToRedeem(Math.min(loyaltyProfile.points, Math.floor(totals.subtotal * 100)))}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                          pointsToRedeem > 0 && pointsToRedeem !== 500 && pointsToRedeem !== 1000
                            ? 'bg-amber-500 text-white border-amber-600 font-bold shadow-sm'
                            : 'bg-white text-amber-900 border-amber-200 hover:bg-amber-100'
                        }`}
                      >
                        Max
                      </button>
                    </div>
                  </div>
                )}

                {/* Promo Code Input */}
                <form onSubmit={handleApplyCode} className="space-y-1">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Promo code (SAVE10, FREESHIP)"
                        value={promoInput}
                        onChange={(e) => setPromoInput(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs uppercase focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition"
                    >
                      Apply
                    </button>
                  </div>
                  {promoMessage && (
                    <div className={`text-[11px] font-medium ${promoMessage.type === 'success' ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {promoMessage.text}
                    </div>
                  )}
                </form>

                {/* Driver Tip Selection */}
                {deliveryType !== 'pickup' && (
                  <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="font-bold text-slate-700">Driver Courier Tip</span>
                      <span className="text-slate-500">${totals.tip.toFixed(2)}</span>
                    </div>
                    <div className="flex gap-1.5">
                      {[0, 10, 15, 20].map((pct) => (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => onSetTipPercentage(pct)}
                          className={`flex-1 py-1 rounded-lg text-xs font-semibold border ${
                            tipPercentage === pct
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {pct === 0 ? 'None' : `${pct}%`}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            )}
          </div>

          {/* Checkout Footer Breakdown */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50/80 space-y-3">
              <div className="space-y-1.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-slate-900">${totals.subtotal.toFixed(2)}</span>
                </div>
                {totals.promoDiscount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Promo Discount</span>
                    <span>-${totals.promoDiscount.toFixed(2)}</span>
                  </div>
                )}
                {totals.pointsDiscount > 0 && (
                  <div className="flex justify-between text-amber-700 font-medium">
                    <span>Rewards Discount ({pointsToRedeem} pts)</span>
                    <span>-${totals.pointsDiscount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Delivery ({deliveryType})</span>
                  <span>{totals.deliveryFee === 0 ? <strong className="text-emerald-700 font-bold">FREE</strong> : `$${totals.deliveryFee.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Tax (7.5%)</span>
                  <span>${totals.tax.toFixed(2)}</span>
                </div>
                {totals.tip > 0 && (
                  <div className="flex justify-between">
                    <span>Courier Tip</span>
                    <span>${totals.tip.toFixed(2)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
                  <span className="text-sm font-extrabold text-slate-900">Total</span>
                  <span className="text-xl font-black text-emerald-950">${totals.total.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={onProceedToCheckout}
                className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-emerald-700/25 flex items-center justify-center gap-2 transition"
              >
                <span>Proceed to Secure Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
