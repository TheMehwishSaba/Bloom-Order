import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  CreditCard, 
  CheckCircle2, 
  ArrowRight, 
  MapPin, 
  Truck, 
  Phone, 
  Mail, 
  Sparkles,
  Smartphone,
  Eye,
  FileText
} from 'lucide-react';
import { CartItem, LoyaltyProfile, Order, OrderStatus } from '../types/store';
import { 
  calculateCartTotals, 
  validateCardForm, 
  detectCardBrand,
  calculateLoyaltyPoints,
  generateOrderNumber
} from '../utils/storeLogic';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  loyaltyProfile: LoyaltyProfile;
  promoCode: string;
  pointsToRedeem: number;
  deliveryType: 'standard' | 'express' | 'pickup';
  tipPercentage: number;
  onOrderComplete: (order: Order) => void;
  onViewOrder: (orderId: string) => void;
  onViewEmail: (orderId: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  loyaltyProfile,
  promoCode,
  pointsToRedeem,
  deliveryType,
  tipPercentage,
  onOrderComplete,
  onViewOrder,
  onViewEmail,
}) => {
  const [step, setStep] = useState<'details' | 'payment' | 'verifying' | 'success'>('details');

  // Customer & Address Form
  const [name, setName] = useState(loyaltyProfile.name || 'Urush Faatima');
  const [email, setEmail] = useState(loyaltyProfile.email || 'urush.faatima@gmail.com');
  const [phone, setPhone] = useState('+1 (555) 349-2910');
  const [street, setStreet] = useState('742 Evergreen Terrace');
  const [apt, setApt] = useState('Apt 4B');
  const [city, setCity] = useState('Springfield');
  const [zip, setZip] = useState('97477');
  const [notes, setNotes] = useState('Leave on doorstep bench. Please do not knock loud.');
  const [isContactless, setIsContactless] = useState(true);

  // Payment Form
  const [paymentMethod, setPaymentMethod] = useState<'credit_card' | 'apple_pay' | 'google_pay' | 'cash_on_delivery'>('credit_card');
  const [cardNumber, setCardNumber] = useState('4532 0151 1283 0366');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvc, setCardCvc] = useState('412');
  const [cardHolder, setCardHolder] = useState('Urush Faatima');
  const [cardErrors, setCardErrors] = useState<Record<string, string>>({});

  // Completed Order Storage
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const totals = calculateCartTotals({
    items,
    promoCode,
    pointsToRedeem,
    deliveryType,
    tipPercentage,
  });

  const pointsEarned = calculateLoyaltyPoints(totals.taxableAmount, loyaltyProfile.tier);
  const cardBrand = detectCardBrand(cardNumber);

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !street) return;
    setStep('payment');
  };

  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();

    if (paymentMethod === 'credit_card') {
      const validation = validateCardForm(cardNumber, cardExpiry, cardCvc, cardHolder);
      if (!validation.isValid) {
        setCardErrors(validation.errors);
        return;
      }
    }

    setCardErrors({});
    setStep('verifying');

    // Simulate real 3D-Secure biometric bank verification handshake
    setTimeout(() => {
      const orderNum = generateOrderNumber();
      const transactionId = `TXN-${Math.floor(1000000 + Math.random() * 9000000)}`;

      const newOrder: Order = {
        id: `ord-${Date.now()}`,
        orderNumber: orderNum,
        createdAt: new Date().toISOString(),
        status: 'order_confirmed',
        customerName: name,
        customerEmail: email,
        customerPhone: phone,
        items: [...items],
        subtotal: totals.subtotal,
        tax: totals.tax,
        deliveryFee: totals.deliveryFee,
        discount: totals.totalDiscount,
        tip: totals.tip,
        total: totals.total,
        pointsEarned,
        pointsRedeemed: pointsToRedeem,
        deliveryType,
        deliveryAddress: {
          street,
          apt,
          city,
          zip,
          notes: isContactless ? `[Contactless Drop] ${notes}` : notes,
        },
        paymentMethod: {
          type: paymentMethod,
          brand: paymentMethod === 'credit_card' ? cardBrand : paymentMethod.replace('_', ' ').toUpperCase(),
          last4: paymentMethod === 'credit_card' ? cardNumber.replace(/\D/g, '').slice(-4) : '9012',
          transactionId,
        },
        timeline: [
          {
            status: 'order_confirmed',
            title: 'Order Confirmed & Payment Verified',
            description: `Authorized via ${paymentMethod === 'credit_card' ? cardBrand : 'Digital Wallet'}. Staged at Downtown Supermarket Hub.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            completed: true,
          },
          {
            status: 'picked_packed',
            title: 'Associate Picking & Packing',
            description: 'Groceries hand-selected, inspected, and packed in cold insulated tote bags.',
            timestamp: 'Pending',
            completed: false,
          },
          {
            status: 'out_for_delivery',
            title: 'Out for Delivery with Driver',
            description: 'Courier assigned for immediate neighborhood dispatch.',
            timestamp: 'Pending',
            completed: false,
          },
          {
            status: 'delivered',
            title: 'Delivered to Destination',
            description: 'Contactless drop with photo proof confirmation.',
            timestamp: 'Pending',
            completed: false,
          },
        ],
        driver: {
          name: 'Alex Rivera',
          phone: '+1 (555) 891-2304',
          vehicle: 'Toyota Prius Eco Van #12',
          rating: 4.95,
          etaMinutes: deliveryType === 'express' ? 18 : 35,
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
          currentLocation: 'Preparing dispatch from Central Market Hub',
        },
      };

      setCreatedOrder(newOrder);
      onOrderComplete(newOrder);
      setStep('success');
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-100 flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex justify-between items-center bg-slate-50/80">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">Secure Checkout</h3>
              <p className="text-[11px] text-slate-500 font-medium">
                End-to-end 256-Bit SSL Encrypted &amp; PCI-DSS Level 1 Certified
              </p>
            </div>
          </div>
          {step !== 'verifying' && (
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Step Indicator */}
        {step !== 'success' && step !== 'verifying' && (
          <div className="px-6 py-2.5 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between text-xs">
            <button
              onClick={() => setStep('details')}
              className={`font-semibold flex items-center gap-1.5 ${step === 'details' ? 'text-emerald-700' : 'text-slate-500'}`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${step === 'details' ? 'bg-emerald-600 text-white' : 'bg-slate-300 text-slate-700'}`}>1</span>
              <span>Delivery Details</span>
            </button>
            <span className="text-slate-300">———</span>
            <button
              onClick={() => {
                if (name && email && street) setStep('payment');
              }}
              className={`font-semibold flex items-center gap-1.5 ${step === 'payment' ? 'text-emerald-700' : 'text-slate-500'}`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${step === 'payment' ? 'bg-emerald-600 text-white' : 'bg-slate-300 text-slate-700'}`}>2</span>
              <span>Payment &amp; Review</span>
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 flex-1">
          {/* STEP 1: DELIVERY DETAILS */}
          {step === 'details' && (
            <form onSubmit={handleDetailsSubmit} className="space-y-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                <span>Contact &amp; Delivery Destination</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number (for SMS &amp; courier)</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email Address (Order status updates sent here)
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Street Address</label>
                  <input
                    type="text"
                    required
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Apt / Suite</label>
                  <input
                    type="text"
                    value={apt}
                    onChange={(e) => setApt(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ZIP / Postal Code</label>
                  <input
                    type="text"
                    required
                    value={zip}
                    onChange={(e) => setZip(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Courier Delivery Instructions</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Ring bell, gate code #4012, leave on table"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="contactless"
                  checked={isContactless}
                  onChange={(e) => setIsContactless(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <label htmlFor="contactless" className="text-xs text-slate-700 cursor-pointer select-none">
                  <strong>Contactless Delivery:</strong> Driver will drop groceries at doorstep and take photo proof.
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="w-full py-3 px-5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-700/20 flex items-center justify-center gap-2 transition"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: PAYMENT METHOD & REVIEW */}
          {step === 'payment' && (
            <form onSubmit={handleProcessPayment} className="space-y-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                Select Payment Method
              </div>

              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('credit_card')}
                  className={`p-3 rounded-2xl border text-xs text-center transition flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'credit_card'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-emerald-600" />
                  <span>Credit Card</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('apple_pay')}
                  className={`p-3 rounded-2xl border text-xs text-center transition flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'apple_pay'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Smartphone className="w-5 h-5 text-slate-900" />
                  <span>Apple Pay</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash_on_delivery')}
                  className={`p-3 rounded-2xl border text-xs text-center transition flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'cash_on_delivery'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <ShieldCheck className="w-5 h-5 text-teal-600" />
                  <span>Pay on Drop</span>
                </button>
              </div>

              {/* Credit Card Inputs */}
              {paymentMethod === 'credit_card' && (
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs font-bold text-slate-800">Card Information</span>
                    <span className="text-[11px] font-mono font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded">
                      {cardBrand}
                    </span>
                  </div>

                  <div>
                    <input
                      type="text"
                      placeholder="Card Number (4532 0151 1283 0366)"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className={`w-full px-3.5 py-2.5 bg-white border ${cardErrors.cardNumber ? 'border-rose-500' : 'border-slate-200'} rounded-xl text-xs font-mono outline-none`}
                    />
                    {cardErrors.cardNumber && (
                      <p className="text-[11px] text-rose-500 mt-1">{cardErrors.cardNumber}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        className={`w-full px-3.5 py-2.5 bg-white border ${cardErrors.expiry ? 'border-rose-500' : 'border-slate-200'} rounded-xl text-xs font-mono outline-none`}
                      />
                      {cardErrors.expiry && (
                        <p className="text-[11px] text-rose-500 mt-1">{cardErrors.expiry}</p>
                      )}
                    </div>
                    <div>
                      <input
                        type="password"
                        maxLength={4}
                        placeholder="CVC"
                        value={cardCvc}
                        onChange={(e) => setCardCvc(e.target.value)}
                        className={`w-full px-3.5 py-2.5 bg-white border ${cardErrors.cvc ? 'border-rose-500' : 'border-slate-200'} rounded-xl text-xs font-mono outline-none`}
                      />
                      {cardErrors.cvc && (
                        <p className="text-[11px] text-rose-500 mt-1">{cardErrors.cvc}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <input
                      type="text"
                      placeholder="Name on Card"
                      value={cardHolder}
                      onChange={(e) => setCardHolder(e.target.value)}
                      className={`w-full px-3.5 py-2.5 bg-white border ${cardErrors.name ? 'border-rose-500' : 'border-slate-200'} rounded-xl text-xs outline-none`}
                    />
                    {cardErrors.name && (
                      <p className="text-[11px] text-rose-500 mt-1">{cardErrors.name}</p>
                    )}
                  </div>
                </div>
              )}

              {/* Order Summary Recap */}
              <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-700">
                  <span>Delivering to</span>
                  <span className="font-semibold text-slate-900">{street}, {apt}</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span>Fulfillment ETA</span>
                  <span className="font-bold text-emerald-800">
                    {deliveryType === 'express' ? '~20 mins (Priority)' : '~40 mins (Standard)'}
                  </span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span>Cornerstone Points to Earn</span>
                  <span className="font-bold text-amber-700 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> +{pointsEarned} pts
                  </span>
                </div>
                <div className="pt-2 border-t border-emerald-200/70 flex justify-between items-baseline font-bold">
                  <span className="text-slate-900 text-sm">Total Authorized</span>
                  <span className="text-xl font-black text-emerald-950">${totals.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStep('details')}
                  className="px-4 py-3 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 transition"
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 px-5 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-700/25 flex items-center justify-center gap-2 transition"
                >
                  <Lock className="w-4 h-4" />
                  <span>Authorize &amp; Pay ${totals.total.toFixed(2)}</span>
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: 3D-SECURE SIMULATION */}
          {step === 'verifying' && (
            <div className="py-12 px-4 text-center space-y-4">
              <div className="w-16 h-16 rounded-full border-4 border-emerald-200 border-t-emerald-600 animate-spin mx-auto" />
              <h4 className="font-extrabold text-base text-slate-900">
                Verifying with Card Issuer...
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Communicating with 3D-Secure 2.0 gateway to verify tokenized funds and reserve live supermarket inventory.
              </p>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-[11px] font-mono">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Token: SHA256-TXN-{Date.now().toString().slice(-6)}</span>
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS & MULTI-STAGE DELIVERY NOTIFICATION NOTICE */}
          {step === 'success' && createdOrder && (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 font-bold">
                  Order #{createdOrder.orderNumber} Placed
                </span>
                <h4 className="text-xl font-black text-slate-900 mt-2">
                  Thank You for Your Order!
                </h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                  Payment of <strong>${createdOrder.total.toFixed(2)}</strong> was successful. Real-time inventory has been reserved at our Downtown Supermarket Hub.
                </p>
              </div>

              {/* Automatic Email Notification Card */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                  <Mail className="w-4 h-4 text-emerald-600" />
                  <span>Confirmation Email Dispatched</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  A receipt &amp; order tracking link was sent to <strong>{createdOrder.customerEmail}</strong>. You will receive automated emails at every stage of packing &amp; delivery!
                </p>
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => {
                      onClose();
                      onViewEmail(createdOrder.id);
                    }}
                    className="flex-1 py-2 px-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 flex items-center justify-center gap-1.5 transition shadow-sm"
                  >
                    <Eye className="w-3.5 h-3.5 text-emerald-600" />
                    <span>View Sent Email</span>
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onViewOrder(createdOrder.id);
                    }}
                    className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow-sm"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>Track Delivery</span>
                  </button>
                </div>
              </div>

              {/* Points Earned Banner */}
              <div className="bg-amber-50 border border-amber-200 p-3 rounded-2xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 font-bold text-amber-950">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>Cornerstone Loyalty Club</span>
                </div>
                <span className="font-extrabold text-amber-800">
                  +{createdOrder.pointsEarned} Points Added!
                </span>
              </div>

              <div className="pt-2">
                <button
                  onClick={onClose}
                  className="w-full py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
