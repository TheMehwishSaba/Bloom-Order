import React, { useState, useEffect } from 'react';
import { 
  Home, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  Circle, 
  Plus, 
  Trash2, 
  RotateCcw, 
  Play, 
  Pause, 
  Calendar,
  Layers,
  Utensils,
  BookOpen,
  Sofa,
  Bed,
  Bath,
  Sparkle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { HomeChore } from '../types/planner';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';

interface HomeChoresViewProps {
  chores: HomeChore[];
  onToggleChore: (choreId: string) => void;
  onAddChore: (chore: Omit<HomeChore, 'id'>) => void;
  onDeleteChore: (choreId: string) => void;
  onResetDailyChores: () => void;
}

export function HomeChoresView({
  chores,
  onToggleChore,
  onAddChore,
  onDeleteChore,
  onResetDailyChores,
}: HomeChoresViewProps) {
  const [selectedZone, setSelectedZone] = useState<string>('all');
  const [selectedFrequency, setSelectedFrequency] = useState<string>('all');
  const [isAddingNew, setIsAddingNew] = useState(false);

  // 15-Minute Speed Tidy Sprint Timer state
  const [speedTidySeconds, setSpeedTidySeconds] = useState<number>(15 * 60);
  const [isTidyRunning, setIsTidyRunning] = useState<boolean>(false);

  // Form State
  const [newTitle, setNewTitle] = useState('');
  const [newZone, setNewZone] = useState<HomeChore['roomZone']>('general');
  const [newFreq, setNewFreq] = useState<HomeChore['frequency']>('daily');
  const [newMinutes, setNewMinutes] = useState<number>(15);
  const [newNotes, setNewNotes] = useState('');

  // Timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTidyRunning && speedTidySeconds > 0) {
      interval = setInterval(() => {
        setSpeedTidySeconds(prev => prev - 1);
      }, 1000);
    } else if (speedTidySeconds === 0 && isTidyRunning) {
      setIsTidyRunning(false);
      playGentleChime('alarm-gentle');
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#8C3246', '#DDA5A5', '#616D48', '#FAF6F0'],
      });
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTidyRunning, speedTidySeconds]);

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddChore({
      title: newTitle.trim(),
      roomZone: newZone,
      frequency: newFreq,
      estimatedMinutes: newMinutes,
      completed: false,
      notes: newNotes.trim() || undefined,
    });

    setNewTitle('');
    setNewNotes('');
    setIsAddingNew(false);
    playGentleChime('sparkle');
  };

  const filteredChores = chores.filter(chore => {
    if (selectedZone !== 'all' && chore.roomZone !== selectedZone) return false;
    if (selectedFrequency !== 'all' && chore.frequency !== selectedFrequency) return false;
    return true;
  });

  const completedCount = filteredChores.filter(c => c.completed).length;
  const progressPercent = filteredChores.length > 0 ? Math.round((completedCount / filteredChores.length) * 100) : 0;

  const zoneIcons: Record<HomeChore['roomZone'], React.ReactNode> = {
    kitchen: <Utensils className="w-3.5 h-3.5" />,
    'study-office': <BookOpen className="w-3.5 h-3.5" />,
    living: <Sofa className="w-3.5 h-3.5" />,
    bedroom: <Bed className="w-3.5 h-3.5" />,
    bathroom: <Bath className="w-3.5 h-3.5" />,
    entryway: <Home className="w-3.5 h-3.5" />,
    general: <Sparkles className="w-3.5 h-3.5" />,
  };

  return (
    <div className="space-y-6">
      
      {/* Botanical Header Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-[#FAF0F2] via-[#FAF6F0] to-[#EDF2E8] border border-[#EADBCE] p-5 sm:p-6 shadow-xs overflow-hidden">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-24 h-24 text-[#8C3246]/20" />
        <div className="max-w-2xl">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#8C3246] flex items-center gap-1.5">
            <PeonyIcon className="w-4 h-4" />
            Order In Your Sanctuary
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif-cormorant font-bold text-[#2D2326] mt-1">
            Home Chores &amp; Space Reset
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-[#5C4F51]">
            "Order in your space is the base for everything else. Keep your space orderly so distractions have less to grab. Reset your space for 15 minutes, clear your desk, and declutter one area regularly."
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 Cols): Chore Lists & Filters */}
        <div className="lg:col-span-2 space-y-5">
          
          {/* Filter Bar & Progress Bar */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-4 sm:p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-serif-cormorant text-xl font-bold text-[#2D2326]">
                  Chore Sanctuary Matrix
                </h3>
                <p className="text-xs text-[#786C6E]">
                  {completedCount} of {filteredChores.length} tasks completed ({progressPercent}%)
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAddingNew(!isAddingNew)}
                  className="px-3 py-1.5 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs font-medium flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAddingNew ? 'Cancel' : 'Add Chore'}</span>
                </button>

                <button
                  onClick={onResetDailyChores}
                  className="px-3 py-1.5 rounded-xl bg-[#FAF6F0] hover:bg-[#EADBCE] text-[#5C4F51] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Uncheck completed daily chores for a new day"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Daily Reset</span>
                </button>
              </div>
            </div>

            {/* Progress track */}
            <div className="w-full h-2 bg-[#FAF6F0] rounded-full overflow-hidden border border-[#EADBCE]">
              <div 
                className="h-full bg-gradient-to-r from-[#DDA5A5] to-[#616D48] transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Zone & Frequency Pills */}
            <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#EADBCE]/60">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#786C6E] mr-1">
                Zone:
              </span>
              {[
                { id: 'all', label: 'All Zones' },
                { id: 'general', label: 'General / Tidy' },
                { id: 'study-office', label: 'Study & Desk' },
                { id: 'kitchen', label: 'Kitchen' },
                { id: 'living', label: 'Living Room' },
                { id: 'bedroom', label: 'Bedroom' },
                { id: 'bathroom', label: 'Bath' },
              ].map(zone => (
                <button
                  key={zone.id}
                  onClick={() => setSelectedZone(zone.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    selectedZone === zone.id
                      ? 'bg-[#8C3246] text-white font-semibold'
                      : 'bg-[#FAF6F0] text-[#5C4F51] hover:bg-[#F3E1E4]'
                  }`}
                >
                  {zone.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#786C6E] mr-1">
                Cadence:
              </span>
              {[
                { id: 'all', label: 'All Frequencies' },
                { id: 'daily', label: 'Daily (Every Evening)' },
                { id: 'weekly', label: 'Weekly Rhythm' },
                { id: 'monthly', label: 'Monthly Declutter' },
              ].map(freq => (
                <button
                  key={freq.id}
                  onClick={() => setSelectedFrequency(freq.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    selectedFrequency === freq.id
                      ? 'bg-[#616D48] text-white font-semibold'
                      : 'bg-[#EDF2E8] text-[#4B5634] hover:bg-[#DEE7D7]'
                  }`}
                >
                  {freq.label}
                </button>
              ))}
            </div>
          </div>

          {/* Add Chore Drawer / Form */}
          {isAddingNew && (
            <form onSubmit={handleAddSubmit} className="bg-[#FAF6F0] rounded-2xl border-2 border-[#DDA5A5] p-5 shadow-xs space-y-4 animate-fade-in">
              <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                Add New Chore or Reset Routine
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Chore Action Title
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Wipe stove top, clear dining table, vacuum hallway"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Room Zone
                  </label>
                  <select
                    value={newZone}
                    onChange={(e) => setNewZone(e.target.value as HomeChore['roomZone'])}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  >
                    <option value="general">General / Space</option>
                    <option value="study-office">Study & Desk</option>
                    <option value="kitchen">Kitchen</option>
                    <option value="living">Living Room</option>
                    <option value="bedroom">Bedroom</option>
                    <option value="bathroom">Bathroom</option>
                    <option value="entryway">Entryway</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Frequency
                  </label>
                  <select
                    value={newFreq}
                    onChange={(e) => setNewFreq(e.target.value as HomeChore['frequency'])}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  >
                    <option value="daily">Daily Habit (Evening)</option>
                    <option value="weekly">Weekly Deep Clean</option>
                    <option value="monthly">Monthly Declutter Area</option>
                    <option value="speed-tidy">15-Min Quick Tidy</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Estimated Minutes
                  </label>
                  <input
                    type="number"
                    min="2"
                    max="120"
                    value={newMinutes}
                    onChange={(e) => setNewMinutes(parseInt(e.target.value, 10) || 15)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                  Notes / Definition of Order (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Only 3 items left on surface; wipe dust with microfiber cloth"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingNew(false)}
                  className="px-4 py-2 rounded-xl bg-white border border-[#EADBCE] text-[#5C4F51] text-xs font-medium hover:bg-[#EADBCE]/50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs font-semibold shadow-xs cursor-pointer"
                >
                  Save Chore
                </button>
              </div>
            </form>
          )}

          {/* Chore Item List */}
          <div className="space-y-3">
            {filteredChores.length === 0 ? (
              <div className="bg-white rounded-2xl border border-[#EADBCE] p-8 text-center">
                <p className="text-sm text-[#786C6E]">No chores match the selected filters.</p>
              </div>
            ) : (
              filteredChores.map(chore => (
                <div
                  key={chore.id}
                  className={`rounded-2xl border p-4 transition-all duration-150 flex items-start justify-between gap-3 ${
                    chore.completed
                      ? 'bg-[#FAF6F0]/60 border-[#EADBCE] opacity-75'
                      : 'bg-white border-[#EADBCE] hover:border-[#DDA5A5] shadow-xs'
                  }`}
                >
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <button
                      onClick={() => {
                        onToggleChore(chore.id);
                        if (!chore.completed) {
                          playGentleChime('success');
                          confetti({ particleCount: 25, spread: 45 });
                        }
                      }}
                      className="mt-0.5 text-[#8C3246] hover:text-[#732738] transition-colors cursor-pointer shrink-0"
                    >
                      {chore.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-[#616D48]" />
                      ) : (
                        <Circle className="w-5 h-5 text-[#DDA5A5]" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-sm sm:text-base font-medium ${
                          chore.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'
                        }`}>
                          {chore.title}
                        </span>

                        <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-[#FAF0F2] text-[#8C3246] font-medium border border-[#DDA5A5]/40">
                          {zoneIcons[chore.roomZone]}
                          <span className="capitalize">{chore.roomZone.replace('-', ' ')}</span>
                        </span>

                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EDF2E8] text-[#4B5634] font-medium capitalize">
                          {chore.frequency}
                        </span>

                        <span className="text-[10px] text-[#786C6E] flex items-center gap-1">
                          <Clock className="w-3 h-3 text-[#C28255]" />
                          {chore.estimatedMinutes}m
                        </span>
                      </div>

                      {chore.notes && (
                        <p className="mt-1 text-xs text-[#5C4F51] pl-0.5">
                          {chore.notes}
                        </p>
                      )}

                      {chore.lastCompletedDate && (
                        <p className="mt-1 text-[10px] text-[#786C6E]">
                          Last done: {chore.lastCompletedDate}
                        </p>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteChore(chore.id)}
                    className="text-[#DDA5A5] hover:text-[#8C3246] p-1 rounded-lg transition-colors cursor-pointer shrink-0"
                    title="Remove chore"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: 15-Minute Speed Tidy Sprint Timer & Space Rules */}
        <div className="space-y-5">
          
          {/* 15-Minute Space Reset Sprint Box */}
          <div className="bg-white rounded-3xl border-2 border-[#DDA5A5] p-5 sm:p-6 shadow-xs text-center relative overflow-hidden">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#8C3246] flex items-center justify-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              15-Minute Speed Tidy Sprint
            </span>

            <h4 className="font-serif-cormorant text-2xl font-bold text-[#2D2326] mt-1">
              Reset Your Space
            </h4>

            <p className="text-xs text-[#5C4F51] mt-1">
              "Reset your space for 15 minutes. Finish with a short shutdown: clear your desk and move what isn't done."
            </p>

            {/* Giant 15m Countdown */}
            <div className="font-serif-cormorant text-5xl font-bold tracking-tight text-[#2D2326] my-4">
              {formatTimer(speedTidySeconds)}
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-2">
              <button
                onClick={() => {
                  if (!isTidyRunning) playGentleChime('sparkle');
                  setIsTidyRunning(!isTidyRunning);
                }}
                className={`px-5 py-2.5 rounded-xl text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer ${
                  isTidyRunning ? 'bg-[#535E3B] hover:bg-[#444E2F]' : 'bg-[#8C3246] hover:bg-[#732738]'
                }`}
              >
                {isTidyRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                <span>{isTidyRunning ? 'Pause Sprint' : 'Start 15m Sprint'}</span>
              </button>

              <button
                onClick={() => {
                  setIsTidyRunning(false);
                  setSpeedTidySeconds(15 * 60);
                }}
                className="p-2.5 rounded-xl bg-[#FAF6F0] hover:bg-[#EADBCE] text-[#5C4F51] transition-colors cursor-pointer"
                title="Reset timer to 15 minutes"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Core Space Order Principles */}
          <div className="bg-[#FAF6F0] rounded-2xl border border-[#EADBCE] p-5 shadow-xs space-y-3">
            <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
              Orderly Space Guidelines
            </h4>
            <div className="space-y-2.5 text-xs text-[#5C4F51]">
              <div className="p-2.5 rounded-xl bg-white border border-[#EADBCE] flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-[#8C3246] mt-1 shrink-0" />
                <div>
                  <strong className="text-[#2D2326]">Desk Zero:</strong> Clear your desk at evening shutdown so tomorrow starts without cognitive drag.
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-[#EADBCE] flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-[#616D48] mt-1 shrink-0" />
                <div>
                  <strong className="text-[#2D2326]">Monthly Declutter:</strong> Pick one drawer or folder each month. Cut anything that no longer serves your core goals.
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-[#EADBCE] flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-[#C28255] mt-1 shrink-0" />
                <div>
                  <strong className="text-[#2D2326]">Phone Out of Sight:</strong> Keep mobile devices in another room during focus blocks to protect attention.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
