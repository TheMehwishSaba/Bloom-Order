import React from 'react';

/**
 * Elegant SVG floral corner ornament inspired by vintage stationery
 */
export function FloralCorner({ className = "w-16 h-16 text-[#8C3246]", position = "top-left" }: { className?: string; position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' }) {
  const transform = {
    'top-left': '',
    'top-right': 'scale(-1, 1)',
    'bottom-left': 'scale(1, -1)',
    'bottom-right': 'scale(-1, -1)',
  }[position];

  return (
    <svg 
      className={`${className} pointer-events-none select-none`} 
      viewBox="0 0 100 100" 
      fill="currentColor"
      style={{ transform }}
    >
      <path d="M10,10 C35,12 60,25 75,50 C60,40 40,35 25,40 C20,30 15,20 10,10 Z" opacity="0.85" />
      <path d="M12,12 C25,25 35,45 35,70 C28,55 22,42 12,35 Z" opacity="0.7" />
      {/* Rosebud motif */}
      <circle cx="28" cy="28" r="7" fill="currentColor" opacity="0.9" />
      <path d="M25,24 C28,20 34,22 35,26 C36,30 31,34 26,33 C22,32 23,26 25,24 Z" fill="#F3E1E4" opacity="0.6" />
      {/* Laurel leaves */}
      <path d="M42,22 C52,20 60,25 62,32 C54,32 46,28 42,22 Z" fill="#616D48" />
      <path d="M22,42 C20,52 25,60 32,62 C32,54 28,46 22,42 Z" fill="#616D48" />
      <path d="M50,45 C60,48 66,58 65,66 C58,62 54,54 50,45 Z" fill="#616D48" opacity="0.8" />
    </svg>
  );
}

/**
 * Botanical olive branch divider ribbon
 */
export function FloralDivider({ className = "my-4 text-[#8C3246]" }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-3 ${className}`}>
      <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent via-[#DDA5A5] to-[#8C3246]/40" />
      <svg className="w-8 h-8 text-[#8C3246]" viewBox="0 0 40 40" fill="currentColor">
        {/* Central blossoming peony */}
        <circle cx="20" cy="20" r="6" fill="#8C3246" />
        <circle cx="20" cy="20" r="3.5" fill="#FAF0F2" opacity="0.8" />
        {/* Left leaf */}
        <path d="M15,20 C10,18 7,14 6,10 C10,11 14,15 15,20 Z" fill="#616D48" />
        <path d="M16,22 C12,24 8,28 6,32 C10,31 14,27 16,22 Z" fill="#616D48" />
        {/* Right leaf */}
        <path d="M25,20 C30,18 33,14 34,10 C30,11 26,15 25,20 Z" fill="#616D48" />
        <path d="M24,22 C28,24 32,28 34,32 C30,31 26,27 24,22 Z" fill="#616D48" />
      </svg>
      <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent via-[#DDA5A5] to-[#8C3246]/40" />
    </div>
  );
}

/**
 * Flowery badge icon with blooming peony
 */
export function PeonyIcon({ className = "w-5 h-5 text-[#8C3246]" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2C9.5 2 7.5 3.8 7.5 6C6 6.5 5 8 5 9.8C5 12 7 13.5 9 14C8 15.5 8 17.5 9.5 19C11 20.5 13 20.5 14.5 19C16 20.5 18 19.5 18.5 17.5C20.5 17 22 15 22 12.8C22 11 21 9.5 19.5 9C19.5 6.8 17.5 5 15 5C14.5 3.2 13.5 2 12 2Z" fill="currentColor" opacity="0.9" />
      <circle cx="12" cy="11" r="3" fill="#FFF5F6" opacity="0.75" />
    </svg>
  );
}

/**
 * Botanical laurel wreath badge
 */
export function LaurelWreath({ className = "w-6 h-6 text-[#616D48]" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 18c0-3 2-6 5-8" />
      <path d="M18 18c0-3-2-6-5-8" />
      <path d="M3 13c1.5-1 3-1.5 4.5-.5" />
      <path d="M21 13c-1.5-1-3-1.5-4.5-.5" />
      <path d="M4 8c2-.5 3.5 0 4.5 1.5" />
      <path d="M20 8c-2-.5-3.5 0-4.5 1.5" />
      <path d="M8 4c2 .5 3 2 3 3.5" />
      <path d="M16 4c-2 .5-3 2-3 3.5" />
      <circle cx="12" cy="19" r="1.5" fill="currentColor" />
    </svg>
  );
}
