import React, { useState } from 'react';
import { 
  Moon, 
  X, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  RotateCcw, 
  Calendar, 
  Check, 
  Award 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { TaskItem, DayOfWeek } from '../types/planner';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';

interface EveningShutdownModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: TaskItem[];
  onToggleTask: (taskId: string) => void;
  onRolloverTask: (taskId: string, targetDay: DayOfWeek) => void;
  onSelectTomorrowTop3: (taskIds: string[]) => void;
  onCompleteShutdown: () => void;
}

export function EveningShutdownModal({
  isOpen,
  onClose,
  tasks,
  onToggleTask,
  onRolloverTask,
  onSelectTomorrowTop3,
  onCompleteShutdown,
}: EveningShutdownModalProps) {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedTomorrowIds, setSelectedTomorrowIds] = useState<string[]>([]);
  const [deskCleanChecked, setDeskCleanChecked] = useState(false);
  const [inboxClosedChecked, setInboxClosedChecked] = useState(false);

  if (!isOpen) return null;

  const doneTasks = tasks.filter(t => t.completed);
  const openTasks = tasks.filter(t => !t.completed);

  const toggleTomorrowSelection = (id: string) => {
    if (selectedTomorrowIds.includes(id)) {
      setSelectedTomorrowIds(selectedTomorrowIds.filter(i => i !== id));
    } else {
      if (selectedTomorrowIds.length < 3) {
        setSelectedTomorrowIds([...selectedTomorrowIds, id]);
      }
    }
  };

  const handleFinish = () => {
    onSelectTomorrowTop3(selectedTomorrowIds);
    onCompleteShutdown();
    playGentleChime('success');
    confetti({
      particleCount: 80,
      spread: 80,
      origin: { y: 0.6 },
      colors: ['#8C3246', '#DDA5A5', '#616D48', '#FAF6F0'],
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 no-print">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-[#EADBCE] relative overflow-hidden">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-20 h-20 text-[#8C3246]/15" />
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#EADBCE]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#FAF0F2] text-[#8C3246] flex items-center justify-center">
              <Moon className="w-5 h-5 text-[#8C3246]" />
            </div>
            <div>
              <h3 className="font-serif-cormorant text-xl font-bold text-[#2D2326]">
                10-Minute Evening Shutdown Ritual
              </h3>
              <p className="text-[11px] text-[#786C6E]">
                Step {step} of 4: Close open loops and prepare restful sleep
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#786C6E] hover:bg-[#FAF0F2]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Celebrate Done List */}
        {step === 1 && (
          <div className="py-4 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#616D48]">
              <Sparkles className="w-4 h-4 text-[#8C3246]" />
              <span>Step 1: Celebrate Real Progress</span>
            </div>
            <p className="text-xs text-[#5C4F51]">
              Review what got finished today. Acknowledging completed tasks prevents anxiety from unfinished loops.
            </p>

            <div className="bg-[#FAF6F0] p-4 rounded-2xl border border-[#EADBCE] max-h-52 overflow-y-auto space-y-2">
              {doneTasks.length === 0 ? (
                <p className="text-xs text-[#786C6E] italic text-center py-4">
                  No tasks marked done yet today. Celebrate making it through the day and plan intentionally for tomorrow.
                </p>
              ) : (
                doneTasks.map(task => (
                  <div key={task.id} className="flex items-center gap-2 text-xs text-[#2D2326]">
                    <CheckCircle2 className="w-4 h-4 text-[#616D48] shrink-0" />
                    <span className="line-through">{task.title}</span>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setStep(2)}
                className="px-5 py-2.5 rounded-xl bg-[#8C3246] text-white text-xs sm:text-sm font-semibold hover:bg-[#732738] flex items-center gap-2 cursor-pointer"
              >
                <span>Continue to Step 2</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Handle Open Loops & Rollovers */}
        {step === 2 && (
          <div className="py-4 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#8C3246]">
              <RotateCcw className="w-4 h-4" />
              <span>Step 2: Close or Move Open Loops</span>
            </div>
            <p className="text-xs text-[#5C4F51]">
              Every open loop takes subconscious mental RAM. Either check it off, delete it, or roll it over to tomorrow.
            </p>

            <div className="bg-[#FAF6F0] p-4 rounded-2xl border border-[#EADBCE] max-h-52 overflow-y-auto space-y-2.5">
              {openTasks.slice(0, 5).map(task => (
                <div key={task.id} className="p-2 rounded-xl bg-white border border-[#EADBCE] flex items-center justify-between gap-2 text-xs">
                  <span className="truncate font-medium">{task.title}</span>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => onToggleTask(task.id)}
                      className="px-2 py-1 rounded bg-[#EDF2E8] text-[#4B5634] font-bold text-[10px] cursor-pointer"
                    >
                      Done
                    </button>
                    <button
                      onClick={() => onRolloverTask(task.id, 'tue')}
                      className="px-2 py-1 rounded bg-[#FAF0F2] text-[#8C3246] font-bold text-[10px] cursor-pointer"
                    >
                      Roll Over
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs text-[#786C6E] hover:text-[#2D2326]"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                className="px-5 py-2.5 rounded-xl bg-[#8C3246] text-white text-xs sm:text-sm font-semibold hover:bg-[#732738] flex items-center gap-2 cursor-pointer"
              >
                <span>Step 3: Pick Tomorrow's Top 3</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Pick Tomorrow's Top 3 */}
        {step === 3 && (
          <div className="py-4 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#8C3246]">
                <PeonyIcon className="w-4 h-4" />
                <span>Step 3: Select Tomorrow's Top 3 Priorities</span>
              </div>
              <span className="text-xs font-bold text-[#8C3246]">
                {selectedTomorrowIds.length} / 3 Chosen
              </span>
            </div>
            <p className="text-xs text-[#5C4F51]">
              Spend 10 minutes the night before choosing your top 3 tasks. Sort by urgent versus important so your morning starts on autopilot.
            </p>

            <div className="bg-[#FAF6F0] p-4 rounded-2xl border border-[#EADBCE] max-h-52 overflow-y-auto space-y-2">
              {openTasks.map(task => {
                const isSelected = selectedTomorrowIds.includes(task.id);
                return (
                  <div
                    key={task.id}
                    onClick={() => toggleTomorrowSelection(task.id)}
                    className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#FAF0F2] border-[#8C3246] text-[#8C3246] font-bold'
                        : 'bg-white border-[#EADBCE] text-[#5C4F51]'
                    }`}
                  >
                    <span className="truncate">{task.title}</span>
                    <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] ${
                      isSelected ? 'bg-[#8C3246] text-white border-[#8C3246]' : 'border-[#DDA5A5]'
                    }`}>
                      {isSelected ? '✓' : ''}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setStep(2)}
                className="px-4 py-2 text-xs text-[#786C6E] hover:text-[#2D2326]"
              >
                Back
              </button>
              <button
                onClick={() => setStep(4)}
                className="px-5 py-2.5 rounded-xl bg-[#8C3246] text-white text-xs sm:text-sm font-semibold hover:bg-[#732738] flex items-center gap-2 cursor-pointer"
              >
                <span>Final Step: Space Reset</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 4: 15-Minute Space Reset & Verbal Closure */}
        {step === 4 && (
          <div className="py-4 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#616D48]">
              <Sparkles className="w-4 h-4 text-[#8C3246]" />
              <span>Step 4: Physical Space Reset &amp; Closure</span>
            </div>
            <p className="text-xs text-[#5C4F51]">
              "Keep your space orderly, so distractions have less to grab." A 5-minute tidy now gives you calm clarity tomorrow morning.
            </p>

            <div className="space-y-2 text-xs">
              <div
                onClick={() => setDeskCleanChecked(!deskCleanChecked)}
                className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer ${
                  deskCleanChecked ? 'bg-[#EDF2E8] border-[#616D48]' : 'bg-[#FAF6F0] border-[#EADBCE]'
                }`}
              >
                <span>Desk cleared: stationery put away, loose papers filed, cup returned</span>
                <span className={`w-4 h-4 rounded-sm border flex items-center justify-center ${deskCleanChecked ? 'bg-[#616D48] text-white' : 'border-stone-400'}`}>
                  {deskCleanChecked ? '✓' : ''}
                </span>
              </div>

              <div
                onClick={() => setInboxClosedChecked(!inboxClosedChecked)}
                className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer ${
                  inboxClosedChecked ? 'bg-[#EDF2E8] border-[#616D48]' : 'bg-[#FAF6F0] border-[#EADBCE]'
                }`}
              >
                <span>Computer shutdown: browser tabs closed, notes synced</span>
                <span className={`w-4 h-4 rounded-sm border flex items-center justify-center ${inboxClosedChecked ? 'bg-[#616D48] text-white' : 'border-stone-400'}`}>
                  {inboxClosedChecked ? '✓' : ''}
                </span>
              </div>
            </div>

            {/* Verbal Closure Affirmation */}
            <div className="p-3.5 rounded-2xl bg-[#FAF0F2] border border-[#DDA5A5] text-center text-xs">
              <span className="font-serif-cormorant text-sm font-bold text-[#8C3246] block mb-1">
                Say The Shutdown Mantra:
              </span>
              <p className="italic text-[#5C4F51]">
                “Day complete. Tomorrow is planned. My mind is clear for rest.”
              </p>
            </div>

            <div className="flex justify-between pt-3">
              <button
                onClick={() => setStep(3)}
                className="px-4 py-2 text-xs text-[#786C6E] hover:text-[#2D2326]"
              >
                Back
              </button>
              <button
                onClick={handleFinish}
                className="px-6 py-2.5 rounded-xl bg-[#616D48] text-white text-xs sm:text-sm font-bold hover:bg-[#4E5839] flex items-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Complete Shutdown &amp; Rest</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
