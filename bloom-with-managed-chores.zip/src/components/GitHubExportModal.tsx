import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Copy, 
  Check, 
  FileText, 
  Code, 
  GitBranch, 
  Terminal, 
  FolderTree, 
  ExternalLink,
  ShieldCheck,
  Sparkles
} from 'lucide-react';

interface GitHubExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function GitHubExportModal({ isOpen, onClose }: GitHubExportModalProps) {
  const [activeTab, setActiveTab] = useState<'readme' | 'html' | 'git' | 'tree'>('readme');
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2500);
  };

  const handleDownload = (filename: string, content: string, mimeType: string = 'text/plain') => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const readmeContent = `# 🌸 Bloom & Order

> **A Mindful Weekly Planner, 25–50m Pomodoro Focus Timer, Home Chores Sanctuary & Printable Stationery System**

[![CI](https://github.com/bloom-and-order/planner/actions/workflows/ci.yml/badge.svg)](https://github.com/bloom-and-order/planner/actions/workflows/ci.yml)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-19-61dafb.svg)](https://react.dev/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-v4-38bdf8.svg)](https://tailwindcss.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 🌿 Philosophy & Core Architecture

*Bloom & Order* translates proven principles of cognitive order, habit architecture, and space discipline into a serene, tactile web application and printable stationery generator.

\`\`\`
"Order in your space, time, priorities, and decisions is the base for everything else blooming."
\`\`\`

### The 5 Core Principles
1. **Capture Everything in One Place:** If a task lives only in your head, you will forget it.
2. **Decide Priority Before You Start:** Plan first, then act.
3. **Close Open Loops:** Every unfinished task keeps taking cognitive bandwidth.
4. **Make Fewer Decisions:** Fixed routines and checklists save mental energy.
5. **Keep Your Space Orderly:** Reduce clutter so distractions have less to grab.

---

## ✨ Features

### ⏱️ 25–50 Minute Pomodoro Focus Timer
- **Flexible Ultradian Rhythm Blocks:** Toggle instantly between 25m Classic Pomodoro, 35m Balanced Block, 45m Deep Block, 50m Ultradian Focus, or fine-tune with the slider.
- **Harmonic Singing Chime Alarm:** Custom 5-note harmonic chord (C5 523.25Hz, E5 659.25Hz, G5 783.99Hz, B5 987.77Hz, C6 1046.50Hz) synthesized using the browser's native Web Audio API (\`audioChime.ts\`) with organic exponential decay and zero external audio asset dependencies.
- **Cycle Counter:** Visual blossom tracker (🌸 1 of 4 cycles) encouraging sustained work blocks paired with restorative 5–15m pauses.
- **Mid-Focus "Parking Lot":** One-click capture field so unexpected thoughts can be parked instantly without breaking cognitive momentum.
- **Pre-Block Ritual Checklist:** Mindful pre-flight checks (clear desk, pour fresh tea, phone in another room, single active window).

### 🧹 Home Chores & Space Reset Matrix
- **15-Minute Speed Tidy Sprint Timer:** Built-in sprint timer with gentle auditory bells for quick, energetic room resets.
- **Sanctuary Zones:** Dedicated organizing cards for Kitchen, Study & Desk, Living Sanctuary, Bedroom, Bath & Linen, and General House.
- **Cadence Rhythm Filters:** Filter by Daily evening resets (wipe surfaces, empty sink), Weekly deep rhythm (linens, floorboards, botanical care), and Monthly declutter (one drawer/shelf per month).

### 🎓 Academic Study Schedules & Active Recall
- **Weekly Subject Timetable:** Schedule sessions across the week with assigned duration blocks (25m, 50m, 90m) and room location tags.
- **Botanical Retention Curve (Spaced Repetition):** Step through memory reinforcement stages: \`First Learning\` → \`Day 1 Review\` → \`Day 3 Recall\` → \`Day 7 Practice\` → \`Day 30 Mastery\`.
- **Active Recall Targets:** Tag key concepts and enforce self-testing from memory before looking at answer keys.

### 📅 Weekly 7-Day Planning & 60–70% Capacity Buffer
- **Margin Rule:** Visual indicator warns when scheduled load exceeds 60–70% capacity, leaving room for life's inevitable surprises.
- **Top 3 Priorities:** Dedicated slots for high-impact tasks each morning.
- **Rollover & Daily Reallocation:** Advance incomplete tasks to subsequent days with a single click.

### 🌙 10-Minute Evening Shutdown Wizard
- Step-by-step guided evening wind-down: review today's accomplishments, roll over open loops, choose tomorrow's Top 3, and physically clear your workspace for tomorrow morning.

### 💾 Local & Offline-First Storage
- Full automatic state persistence via browser \`localStorage\` (\`bloom_order_planner_v1\`, \`bloom_order_chores_v1\`, \`bloom_order_study_v1\`). All changes persist safely across browser refreshes and offline sessions.

### 🖨️ High-Resolution Print Studio
- **Printable Templates:**
  - 7-Day Botanical Spread
  - Daily Focus & Hourly Blocks
  - Home Chores & Space Order Matrix
  - Academic Study Timetable & Spaced Recall
  - Master Repeat Checklists (Weekly Shop, Sunday Reset, Travel Packing)
  - Eisenhower Urgent vs. Important Matrix
  - 10-Minute Evening Shutdown Card
- **Customizable Styling:** US Letter or A4 formats, Botanical Rose & Sage, Monochrome Ink-Saver (B&W), or Vintage Wheat themes.
- **Clean Print Engine:** Customized \`@media print\` CSS isolating the printable sheet for crisp paper outputs.

---

## 🎨 Color Palette & Design Tokens

Crafted to reflect traditional French botanical stationery, pressed flowers, and linen paper:

| Token | Hex | Role |
|---|---|---|
| **Berry Burgundy** | \`#8C3246\` | Primary accents, buttons, key headings |
| **Dusty Rose** | \`#DDA5A5\` | Borders, subtle highlights, badge borders |
| **Sage / Olive Green** | \`#616D48\` | Habits, success states, botanical foliage |
| **Linen Ivory** | \`#FAF6F0\` | Main canvas background |
| **Charcoal Ink** | \`#2D2326\` | Body typography |
| **Warm Wheat** | \`#C28255\` | Time estimates, tea & resting accents |

---

## 🚀 Quick Start

### Prerequisites
- Node.js 20+ installed
- npm 10+

### Installation

\`\`\`bash
# Clone the repository
git clone https://github.com/your-username/bloom-and-order.git

# Navigate into project directory
cd bloom-and-order

# Install dependencies
npm install

# Start development server
npm run dev
\`\`\`

Visit \`http://localhost:3000\` in your browser.

### Scripts

| Command | Action |
|---|---|
| \`npm run dev\` | Starts Vite dev server on port 3000 |
| \`npm run build\` | Compiles TypeScript and builds optimized production bundle in \`dist/\` |
| \`npm run lint\` | Runs TypeScript type checking (\`tsc --noEmit\`) |
| \`npm test\` | Runs unit tests via Node native test runner and tsx |
| \`npm run preview\` | Previews production build locally |

---

## 📁 Project Structure

\`\`\`
├── .github/
│   └── workflows/
│       └── ci.yml               # GitHub Actions CI pipeline
├── public/
│   └── assets/
│       └── botanical_still_life.jpg # Still-life artwork (no people)
├── src/
│   ├── components/
│   │   ├── CaptureInboxView.tsx     # Master capture inbox & GTD triage
│   │   ├── DailyFocusView.tsx       # 25-50m Pomodoro timer & alarm
│   │   ├── EveningShutdownModal.tsx # 10-minute nightly shutdown wizard
│   │   ├── FloralAccents.tsx        # Botanical SVG flourishes & wreaths
│   │   ├── GoalMatrixView.tsx       # Eisenhower matrix & 90-day targets
│   │   ├── HeaderNav.tsx            # Navigation header & quick action tabs
│   │   ├── HomeChoresView.tsx       # Space resets & 15m speed-tidy timer
│   │   ├── PrintStudioModal.tsx     # Letter / A4 printable template studio
│   │   ├── QuickCaptureModal.tsx    # Cmd+K global quick capture dialog
│   │   ├── RepeatChecklistsView.tsx # Recurring repeat checklists
│   │   ├── StudySchedulesView.tsx   # Study timetable & spaced repetition
│   │   └── WeeklyPlannerView.tsx    # 7-day spread & habit tracker
│   ├── data/
│   │   └── plannerData.ts           # Initial templates, chores & quotes
│   ├── types/
│   │   └── planner.ts               # Strict TypeScript domain interfaces
│   ├── utils/
│   │   ├── audioChime.ts            # Gentle Web Audio API synthesizer
│   │   ├── plannerLogic.ts          # Capacity & Eisenhower calculations
│   │   └── plannerLogic.test.ts     # Unit tests
│   ├── App.tsx                      # Root application & persistence
│   ├── index.css                    # Tailwind v4 theme & print CSS
│   └── main.tsx                     # React 19 entry point
├── LICENSE                          # MIT License
├── package.json
├── tsconfig.json
└── vite.config.ts
\`\`\`

---

## ⌨️ Keyboard Shortcuts

- \`⌘K\` or \`Ctrl+K\`: Open Quick Task Capture Modal from any screen
- \`Escape\`: Close any active modal or return to planner view

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).
`;

  const htmlContent = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Bloom &amp; Order | Printable Weekly Planner &amp; Mindful Checklist</title>
    <meta name="description" content="Artisan floral weekly planner, focus block scheduler, and habit checklists styled with botanical rose, sage olive, and vintage paper aesthetics." />
    <meta property="og:title" content="Bloom &amp; Order | Printable Weekly Planner" />
    <meta property="og:description" content="Turn intentional productivity rules into a gorgeous printable weekly planner, habit rituals, and focus checklists." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,400;1,600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`;

  const gitCommands = `# 1. Initialize Git in the project root
git init

# 2. Stage all app files, README.md, and configuration
git add .

# 3. Create initial commit
git commit -m "feat: initial commit of Bloom & Order mindful planner app"

# 4. Set default main branch
git branch -M main

# 5. Connect to your GitHub repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/bloom-and-order.git

# 6. Push your application to GitHub
git push -u origin main`;

  const projectTree = `bloom-and-order/
├── README.md               <-- [Root] Complete GitHub Documentation
├── index.html              <-- [Root] HTML Entrypoint with Typography & Meta
├── LICENSE                 <-- [Root] MIT Open Source License
├── package.json            <-- [Root] Dependencies & scripts
├── tsconfig.json           <-- [Root] TypeScript configuration
├── vite.config.ts          <-- [Root] Vite & Tailwind bundler config
├── .gitignore              <-- [Root] Standard Git ignore rules
├── .github/
│   └── workflows/
│       └── ci.yml          <-- GitHub Actions automated build & test CI
├── public/
│   └── assets/
│       └── botanical_still_life.jpg <-- Peonies, eucalyptus & tea still-life
├── src/
│   ├── components/         <-- Pomodoro, Chores, Study, Print Studio views
│   ├── data/               <-- Initial sample templates & checklists
│   ├── types/              <-- TypeScript interfaces
│   ├── utils/              <-- Web Audio chime synth & planner math
│   ├── App.tsx             <-- Root component & local persistence
│   ├── index.css           <-- Tailwind v4 botanical tokens & print CSS
│   └── main.tsx            <-- Application entry
└── dist/
    └── index.html          <-- [Compiled] Production ready bundle HTML`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-fade-in no-print">
      <div 
        className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-[#FAF6F0] rounded-2xl sm:rounded-3xl shadow-2xl border border-[#DDA5A5] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="bg-[#8C3246] text-white px-5 sm:px-8 py-4 sm:py-5 flex items-center justify-between border-b border-[#732738]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <GitBranch className="w-5 h-5 text-[#FAF0F2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-serif-cormorant font-bold tracking-tight">
                  GitHub &amp; Project Repository Files
                </h2>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#616D48] text-white">
                  Ready to Publish
                </span>
              </div>
              <p className="text-xs text-[#FAF0F2]/80">
                Direct access to <code className="bg-black/20 px-1 py-0.5 rounded">README.md</code>, <code className="bg-black/20 px-1 py-0.5 rounded">index.html</code>, and Git push instructions
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 text-white/90 hover:text-white transition-colors cursor-pointer"
            title="Close modal (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="bg-[#FAF0F2] border-b border-[#EADBCE] px-5 sm:px-8 flex items-center gap-2 overflow-x-auto py-2.5">
          <button
            onClick={() => setActiveTab('readme')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
              activeTab === 'readme'
                ? 'bg-[#8C3246] text-white shadow-xs font-semibold'
                : 'text-[#5C4F51] hover:bg-[#EADBCE]/50'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>README.md</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/10">Root</span>
          </button>

          <button
            onClick={() => setActiveTab('html')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
              activeTab === 'html'
                ? 'bg-[#8C3246] text-white shadow-xs font-semibold'
                : 'text-[#5C4F51] hover:bg-[#EADBCE]/50'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>index.html</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/10">Root &amp; Dist</span>
          </button>

          <button
            onClick={() => setActiveTab('git')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
              activeTab === 'git'
                ? 'bg-[#8C3246] text-white shadow-xs font-semibold'
                : 'text-[#5C4F51] hover:bg-[#EADBCE]/50'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Git Commands</span>
          </button>

          <button
            onClick={() => setActiveTab('tree')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
              activeTab === 'tree'
                ? 'bg-[#8C3246] text-white shadow-xs font-semibold'
                : 'text-[#5C4F51] hover:bg-[#EADBCE]/50'
            }`}
          >
            <FolderTree className="w-4 h-4" />
            <span>Project File Tree</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6">
          
          {/* Quick Download Banner */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#EADBCE] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#EBF0E4] text-[#616D48] flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#2D2326]">
                  Download Files Directly to Your Computer
                </h3>
                <p className="text-xs text-[#786C6E]">
                  Save these files into your local project folder to commit and push straight to GitHub.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => handleDownload('README.md', readmeContent, 'text/markdown')}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs font-medium shadow-xs transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save README.md</span>
              </button>

              <button
                onClick={() => handleDownload('index.html', htmlContent, 'text/html')}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#616D48] hover:bg-[#4E5839] text-white text-xs font-medium shadow-xs transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save index.html</span>
              </button>
            </div>
          </div>

          {/* TAB 1: README.md */}
          {activeTab === 'readme' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-[#2D2326] flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#8C3246]" />
                    <span>File Location: <code className="bg-[#FAF0F2] text-[#8C3246] px-1.5 py-0.5 rounded border border-[#DDA5A5]/40 font-mono text-xs">/README.md</code></span>
                  </h4>
                  <p className="text-xs text-[#786C6E]">
                    Comprehensive GitHub documentation complete with badges, architecture, color tokens, and installation steps.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(readmeContent, 'readme')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#DDA5A5] bg-white text-[#8C3246] text-xs font-medium hover:bg-[#FAF0F2] transition-colors cursor-pointer"
                  >
                    {copiedType === 'readme' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Markdown</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => handleDownload('README.md', readmeContent, 'text/markdown')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#8C3246] text-white text-xs font-medium hover:bg-[#732738] transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>

              <div className="relative bg-[#2D2326] text-[#FAF6F0] rounded-2xl p-4 sm:p-5 font-mono text-xs max-h-96 overflow-y-auto leading-relaxed border border-[#44383B]">
                <pre className="whitespace-pre-wrap">{readmeContent}</pre>
              </div>
            </div>
          )}

          {/* TAB 2: index.html */}
          {activeTab === 'html' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-[#2D2326] flex items-center gap-2">
                    <Code className="w-4 h-4 text-[#616D48]" />
                    <span>File Location: <code className="bg-[#FAF0F2] text-[#8C3246] px-1.5 py-0.5 rounded border border-[#DDA5A5]/40 font-mono text-xs">/index.html</code></span>
                  </h4>
                  <p className="text-xs text-[#786C6E]">
                    HTML entry point with serif Google Fonts (Cormorant Garamond, Playfair Display), responsive viewport, and SEO tags.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(htmlContent, 'html')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#DDA5A5] bg-white text-[#8C3246] text-xs font-medium hover:bg-[#FAF0F2] transition-colors cursor-pointer"
                  >
                    {copiedType === 'html' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy HTML</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => handleDownload('index.html', htmlContent, 'text/html')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#616D48] text-white text-xs font-medium hover:bg-[#4E5839] transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>

              <div className="relative bg-[#2D2326] text-[#FAF6F0] rounded-2xl p-4 sm:p-5 font-mono text-xs max-h-96 overflow-y-auto leading-relaxed border border-[#44383B]">
                <pre className="whitespace-pre-wrap">{htmlContent}</pre>
              </div>
            </div>
          )}

          {/* TAB 3: Git Commands */}
          {activeTab === 'git' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-[#2D2326] flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-[#8C3246]" />
                    <span>How to publish this project to GitHub</span>
                  </h4>
                  <p className="text-xs text-[#786C6E]">
                    Run these commands in your local terminal inside the project directory.
                  </p>
                </div>
                <button
                  onClick={() => handleCopy(gitCommands, 'git')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#8C3246] text-white text-xs font-medium hover:bg-[#732738] transition-colors cursor-pointer"
                >
                  {copiedType === 'git' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Copied Commands!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Commands</span>
                    </>
                  )}
                </button>
              </div>

              <div className="relative bg-[#2D2326] text-[#FAF6F0] rounded-2xl p-4 sm:p-5 font-mono text-xs leading-relaxed border border-[#44383B]">
                <pre className="whitespace-pre-wrap text-emerald-300">{gitCommands}</pre>
              </div>

              <div className="bg-[#FAF0F2] rounded-2xl p-4 border border-[#DDA5A5] text-xs text-[#5C4F51] space-y-2">
                <p className="font-semibold text-[#8C3246] flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  GitHub Repository Checklist:
                </p>
                <ul className="list-disc list-inside space-y-1 text-[#4B3E40]">
                  <li>Create a new repository on <a href="https://github.com/new" target="_blank" rel="noopener noreferrer" className="text-[#8C3246] underline font-medium">github.com/new</a> named <strong>bloom-and-order</strong>.</li>
                  <li>Do not check "Initialize this repository with a README" since we already provide a complete, custom <code>README.md</code>.</li>
                  <li>After running the commands above, GitHub will automatically render your formatted <code>README.md</code> on the repository homepage.</li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 4: Project Tree */}
          {activeTab === 'tree' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-[#2D2326] flex items-center gap-2">
                  <FolderTree className="w-4 h-4 text-[#616D48]" />
                  <span>Exact Repository Directory Structure</span>
                </h4>
                <p className="text-xs text-[#786C6E]">
                  All files are neatly structured at the root and inside <code className="text-[#8C3246]">src/</code>.
                </p>
              </div>

              <div className="relative bg-[#2D2326] text-[#FAF6F0] rounded-2xl p-4 sm:p-5 font-mono text-xs max-h-96 overflow-y-auto leading-relaxed border border-[#44383B]">
                <pre className="whitespace-pre-wrap text-amber-200/90">{projectTree}</pre>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-[#FAF0F2] px-5 sm:px-8 py-3.5 border-t border-[#EADBCE] flex items-center justify-between">
          <span className="text-xs text-[#786C6E]">
            All files are pre-configured with MIT license and GitHub Actions CI.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
