import React, { useState } from 'react';
import { X, Plus, Minus, ShoppingBag, ShieldCheck, MapPin, Barcode, Check, Sparkles } from 'lucide-react';
import { Product } from '../types/store';

interface ProductDetailModalProps {
  product: Product | null;
  quantityInCart: number;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  quantityInCart,
  onClose,
  onAddToCart,
}) => {
  if (!product) return null;

  const [qty, setQty] = useState(1);
  const isOutOfStock = product.stock <= 0;
  const maxCanAdd = Math.max(0, product.stock - quantityInCart);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-100 flex flex-col md:flex-row overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/90 hover:bg-slate-100 text-slate-500 hover:text-slate-800 shadow-md transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Side: Product Image & Badges */}
        <div className="md:w-1/2 bg-slate-100 relative min-h-[260px] md:min-h-full">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-4 left-4 flex flex-col gap-1.5">
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-white/90 text-slate-800 backdrop-blur-md shadow-sm">
              {product.category}
            </span>
            {product.nutrition?.organic && (
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shadow-sm flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> 100% Certified Organic
              </span>
            )}
          </div>
        </div>

        {/* Right Side: Product Details & Stock */}
        <div className="p-6 md:w-1/2 flex flex-col justify-between">
          <div>
            {/* Title & Price */}
            <div className="mb-3">
              <div className="flex items-center gap-2 text-xs text-slate-400 font-mono mb-1">
                <span>SKU: {product.sku}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Barcode className="w-3.5 h-3.5" /> {product.barcode}
                </span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900 leading-tight">
                {product.name}
              </h2>
            </div>

            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-2xl font-black text-emerald-950">
                ${product.price.toFixed(2)}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-slate-400 line-through">
                  ${product.originalPrice.toFixed(2)}
                </span>
              )}
              <span className="text-xs text-slate-500 font-medium">({product.unit})</span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              {product.description}
            </p>

            {/* In-Store Location & Stock */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 mb-4 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" /> Store Location:
                </span>
                <span className="font-semibold text-slate-800">
                  {product.aisle} · {product.shelf}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Live Inventory Available:</span>
                <span className={`font-bold ${isOutOfStock ? 'text-rose-600' : product.stock <= 5 ? 'text-amber-600' : 'text-emerald-700'}`}>
                  {isOutOfStock ? 'Out of Stock' : `${product.stock} units in hub`}
                </span>
              </div>
            </div>

            {/* Nutrition Highlights */}
            {product.nutrition && (
              <div className="mb-6">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Dietary &amp; Nutrition Facts
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-100 flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Calories: <strong>{product.nutrition.calories} kcal</strong></span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-100 flex items-center gap-1.5">
                    <Check className={`w-3.5 h-3.5 ${product.nutrition.vegan ? 'text-emerald-600' : 'text-slate-300'}`} />
                    <span>Vegan: <strong>{product.nutrition.vegan ? 'Yes' : 'No'}</strong></span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-100 flex items-center gap-1.5">
                    <Check className={`w-3.5 h-3.5 ${product.nutrition.glutenFree ? 'text-emerald-600' : 'text-slate-300'}`} />
                    <span>Gluten-Free: <strong>{product.nutrition.glutenFree ? 'Yes' : 'Contains Gluten'}</strong></span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-100 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
                    <span>Freshness Check: <strong>Passed</strong></span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Footer */}
          <div className="pt-4 border-t border-slate-100">
            {isOutOfStock ? (
              <div className="text-center py-3 px-4 bg-slate-100 text-slate-500 rounded-xl text-xs font-bold">
                Currently Out of Stock at this Hub
              </div>
            ) : maxCanAdd <= 0 ? (
              <div className="text-center py-3 px-4 bg-amber-50 text-amber-800 border border-amber-200 rounded-xl text-xs font-semibold">
                You already have all {product.stock} available units in your cart!
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="flex items-center bg-slate-100 rounded-xl p-1 border border-slate-200">
                  <button
                    onClick={() => setQty(Math.max(1, qty - 1))}
                    className="w-8 h-8 flex items-center justify-center text-slate-700 hover:bg-white rounded-lg transition"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-bold text-sm text-slate-900">
                    {qty}
                  </span>
                  <button
                    onClick={() => setQty(Math.min(maxCanAdd, qty + 1))}
                    disabled={qty >= maxCanAdd}
                    className="w-8 h-8 flex items-center justify-center text-slate-700 hover:bg-white disabled:opacity-30 rounded-lg transition"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <button
                  onClick={() => {
                    onAddToCart(product, qty);
                    onClose();
                  }}
                  className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-700/20 active:scale-95 transition"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add {qty} to Basket • ${(product.price * qty).toFixed(2)}</span>
                </button>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
