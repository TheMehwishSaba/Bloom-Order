import React, { useState } from 'react';
import { 
  Mail, 
  X, 
  CheckCheck, 
  Clock, 
  ChevronRight, 
  Send, 
  Eye, 
  CheckCircle2, 
  Package, 
  Truck, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { EmailNotification, Order, OrderStatus } from '../types/store';

interface EmailNotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: EmailNotification[];
  orders: Order[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onSendTestEmail: (orderId: string, stage: OrderStatus) => void;
}

export const EmailNotificationsModal: React.FC<EmailNotificationsModalProps> = ({
  isOpen,
  onClose,
  notifications,
  orders,
  onMarkAsRead,
  onMarkAllAsRead,
  onSendTestEmail,
}) => {
  const [selectedEmail, setSelectedEmail] = useState<EmailNotification | null>(
    notifications[0] || null
  );
  const [testOrderId, setTestOrderId] = useState<string>(orders[0]?.id || '');
  const [testStage, setTestStage] = useState<OrderStatus>('out_for_delivery');

  if (!isOpen) return null;

  const currentEmail = selectedEmail || notifications[0] || null;

  const getStageIcon = (stage: OrderStatus) => {
    switch (stage) {
      case 'order_confirmed':
        return <Clock className="w-3.5 h-3.5 text-blue-600" />;
      case 'picked_packed':
        return <Package className="w-3.5 h-3.5 text-purple-600" />;
      case 'out_for_delivery':
        return <Truck className="w-3.5 h-3.5 text-amber-600" />;
      case 'delivered':
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />;
      default:
        return <Mail className="w-3.5 h-3.5 text-slate-600" />;
    }
  };

  const handleSelectEmail = (em: EmailNotification) => {
    setSelectedEmail(em);
    if (!em.read) {
      onMarkAsRead(em.id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-5xl w-full h-[90vh] shadow-2xl border border-slate-100 flex flex-col overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex justify-between items-center bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-slate-900 text-base">
                  Delivery Email Notification Center
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 uppercase tracking-wide">
                  Live Dispatch
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Automated customer emails dispatched on every stage of fulfillment &amp; doorstep arrival.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onMarkAllAsRead}
              className="text-xs text-slate-600 hover:text-slate-900 font-semibold px-3 py-1.5 rounded-xl hover:bg-slate-200/60 transition flex items-center gap-1.5"
            >
              <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Mark all as read</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick Simulator Bar */}
        <div className="px-5 py-3 bg-slate-100/80 border-b border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Simulate Stage Email:</span>
            <select
              value={testOrderId}
              onChange={(e) => setTestOrderId(e.target.value)}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold outline-none"
            >
              {orders.map((o) => (
                <option key={o.id} value={o.id}>
                  Order #{o.orderNumber} ({o.items.length} items)
                </option>
              ))}
            </select>

            <select
              value={testStage}
              onChange={(e) => setTestStage(e.target.value as OrderStatus)}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold outline-none"
            >
              <option value="order_confirmed">Stage 1: Order Confirmed</option>
              <option value="picked_packed">Stage 2: Picked &amp; Cold Packed</option>
              <option value="out_for_delivery">Stage 3: Out for Delivery</option>
              <option value="delivered">Stage 4: Delivered</option>
            </select>
          </div>

          <button
            onClick={() => {
              if (testOrderId) {
                onSendTestEmail(testOrderId, testStage);
              }
            }}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Dispatch Test Email</span>
          </button>
        </div>

        {/* Modal Split View */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Email List Sidebar */}
          <div className="w-full md:w-80 lg:w-96 border-r border-slate-200 bg-slate-50/50 flex flex-col overflow-hidden">
            <div className="p-3 border-b border-slate-200/80 text-[11px] font-bold uppercase tracking-wider text-slate-400 flex justify-between items-center">
              <span>Dispatched Emails ({notifications.length})</span>
              <span className="text-emerald-700 font-mono">urush.faatima@gmail.com</span>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  No notifications recorded yet.
                </div>
              ) : (
                notifications.map((n) => {
                  const isSelected = currentEmail?.id === n.id;

                  return (
                    <div
                      key={n.id}
                      onClick={() => handleSelectEmail(n)}
                      className={`p-3.5 cursor-pointer transition relative ${
                        isSelected 
                          ? 'bg-white border-l-4 border-emerald-600 shadow-sm' 
                          : 'hover:bg-slate-100/70'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 truncate">
                          {getStageIcon(n.stage)}
                          <span className="truncate">{n.stage.replace(/_/g, ' ').toUpperCase()}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono shrink-0">
                          {n.sentAt}
                        </span>
                      </div>

                      <h4 className="text-xs font-semibold text-slate-800 line-clamp-1 mb-1">
                        {n.subject}
                      </h4>

                      <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                        {n.previewText}
                      </p>

                      {!n.read && (
                        <span className="absolute top-3 right-3 w-2 h-2 rounded-full bg-emerald-600" />
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Email Template Preview Pane */}
          <div className="flex-1 bg-slate-100 flex flex-col overflow-hidden">
            {currentEmail ? (
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Meta details bar */}
                <div className="p-4 bg-white border-b border-slate-200 text-xs space-y-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-extrabold text-sm text-slate-900">{currentEmail.subject}</div>
                      <div className="text-slate-500 text-[11px] mt-0.5">
                        To: <strong>{currentEmail.recipientEmail}</strong> · From: <strong>Cornerstone Dispatch &lt;orders@cornerstoneprovisions.com&gt;</strong>
                      </div>
                    </div>
                    <span className="font-mono text-[11px] text-slate-400 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                      Dispatched: {currentEmail.sentAt}
                    </span>
                  </div>
                </div>

                {/* Rendered HTML Preview */}
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex justify-center">
                  <div 
                    className="w-full max-w-xl bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden"
                    dangerouslySetInnerHTML={{ __html: currentEmail.htmlContent }}
                  />
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-slate-400 text-xs">
                Select an email from the left sidebar to preview its full template layout.
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
