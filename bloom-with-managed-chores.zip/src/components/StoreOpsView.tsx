import React, { useState } from 'react';
import { 
  Layers, 
  Package, 
  Users, 
  TrendingUp, 
  Search, 
  Plus, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Truck, 
  Clock, 
  X, 
  RefreshCw, 
  Edit3, 
  Save, 
  Mail, 
  Barcode, 
  MapPin, 
  Sparkles,
  Phone
} from 'lucide-react';
import { Product, Order, Customer, OrderStatus } from '../types/store';

interface StoreOpsViewProps {
  products: Product[];
  orders: Order[];
  customers: Customer[];
  onUpdateProductStock: (productId: string, newStock: number) => void;
  onUpdateProductPrice: (productId: string, newPrice: number) => void;
  onAdvanceOrderStatus: (orderId: string, nextStatus: OrderStatus) => void;
  onViewOrderEmail: (orderId: string) => void;
  onClose: () => void;
}

export const StoreOpsView: React.FC<StoreOpsViewProps> = ({
  products,
  orders,
  customers,
  onUpdateProductStock,
  onUpdateProductPrice,
  onAdvanceOrderStatus,
  onViewOrderEmail,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'inventory' | 'customers' | 'analytics'>('orders');
  
  // Search & Filters
  const [orderFilter, setOrderFilter] = useState<'all' | OrderStatus>('all');
  const [inventorySearch, setInventorySearch] = useState('');
  const [inventoryStockFilter, setInventoryStockFilter] = useState<'all' | 'low' | 'out'>('all');
  const [customerSearch, setCustomerSearch] = useState('');

  // Editing Product State
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editStock, setEditStock] = useState<number>(0);

  // Summary Metrics
  const totalRevenue = orders.reduce((sum, o) => sum + (o.status !== 'cancelled' ? o.total : 0), 0);
  const activeDeliveriesCount = orders.filter((o) => o.status === 'out_for_delivery').length;
  const lowStockCount = products.filter((p) => p.stock > 0 && p.stock <= p.lowStockThreshold).length;
  const outOfStockCount = products.filter((p) => p.stock === 0).length;

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    if (orderFilter === 'all') return true;
    return o.status === orderFilter;
  });

  // Filtered inventory
  const filteredProducts = products.filter((p) => {
    const matchesSearch = 
      p.name.toLowerCase().includes(inventorySearch.toLowerCase()) ||
      p.sku.toLowerCase().includes(inventorySearch.toLowerCase()) ||
      p.barcode.includes(inventorySearch) ||
      p.category.toLowerCase().includes(inventorySearch.toLowerCase());

    if (!matchesSearch) return false;

    if (inventoryStockFilter === 'low') {
      return p.stock > 0 && p.stock <= p.lowStockThreshold;
    }
    if (inventoryStockFilter === 'out') {
      return p.stock === 0;
    }
    return true;
  });

  // Filtered customers
  const filteredCustomers = customers.filter((c) => {
    return (
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.email.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.loyaltyTier.toLowerCase().includes(customerSearch.toLowerCase())
    );
  });

  const handleStartEdit = (product: Product) => {
    setEditingProductId(product.id);
    setEditPrice(product.price);
    setEditStock(product.stock);
  };

  const handleSaveEdit = (productId: string) => {
    onUpdateProductStock(productId, editStock);
    onUpdateProductPrice(productId, editPrice);
    setEditingProductId(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 animate-fadeIn">
      {/* Top Bar */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 mb-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-400">
                Downtown Regional Fulfillment Hub #104 · Live
              </span>
            </div>
            <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
              Store Operations &amp; Database Center
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Real-time inventory tracking, multi-stage delivery dispatch, and customer CRM.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl border border-slate-700 transition"
            >
              Exit to Supermarket Storefront
            </button>
          </div>
        </div>

        {/* Live Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800 text-xs">
          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/60">
            <div className="text-slate-400 text-[11px] mb-1">Today&apos;s Store Revenue</div>
            <div className="text-xl font-black text-emerald-400">${totalRevenue.toFixed(2)}</div>
            <div className="text-[10px] text-slate-400 mt-0.5">{orders.length} orders billed</div>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/60">
            <div className="text-slate-400 text-[11px] mb-1">Active Couriers En Route</div>
            <div className="text-xl font-black text-amber-400">{activeDeliveriesCount} Drivers</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Average ETA: 24 mins</div>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/60">
            <div className="text-slate-400 text-[11px] mb-1">Low Inventory Alerts</div>
            <div className="text-xl font-black text-amber-300">{lowStockCount} Items</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Below reorder trigger</div>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/60">
            <div className="text-slate-400 text-[11px] mb-1">Out of Stock Stockouts</div>
            <div className="text-xl font-black text-rose-400">{outOfStockCount} SKUs</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Requires vendor delivery</div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-200 mb-6 gap-2 text-xs font-bold overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition ${
            activeTab === 'orders'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Live Orders &amp; Dispatch ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition ${
            activeTab === 'inventory'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Real-time Inventory ({products.length} SKUs)</span>
        </button>

        <button
          onClick={() => setActiveTab('customers')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition ${
            activeTab === 'customers'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Customer CRM Database ({customers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition ${
            activeTab === 'analytics'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Store Analytics</span>
        </button>
      </div>

      {/* TAB 1: LIVE ORDERS & DISPATCH PIPELINE */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {/* Sub Filters */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              <span className="text-slate-400 font-bold uppercase text-[10px] mr-1">Status:</span>
              {(['all', 'order_confirmed', 'picked_packed', 'out_for_delivery', 'delivered'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setOrderFilter(st)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition ${
                    orderFilter === st
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {st.replace(/_/g, ' ')}
                </button>
              ))}
            </div>

            <div className="text-xs text-slate-500 font-medium">
              Clicking an action button automatically triggers the multi-stage delivery email!
            </div>
          </div>

          {/* Orders Table / Cards */}
          <div className="grid grid-cols-1 gap-4">
            {filteredOrders.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:border-slate-300 transition space-y-4"
              >
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-sm font-black text-slate-900 bg-slate-100 px-3 py-1 rounded-xl">
                      #{order.orderNumber}
                    </span>
                    <div>
                      <h4 className="text-sm font-extrabold text-slate-900">{order.customerName}</h4>
                      <p className="text-[11px] text-slate-400">{order.customerEmail} · {order.customerPhone}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onViewOrderEmail(order.id)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                      title="Inspect HTML Email sent for current stage"
                    >
                      <Mail className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Stage Email</span>
                    </button>

                    <div className="text-right">
                      <div className="text-sm font-black text-emerald-950">${order.total.toFixed(2)}</div>
                      <div className="text-[10px] text-slate-400 capitalize">{order.deliveryType} Delivery</div>
                    </div>
                  </div>
                </div>

                {/* Items & Address Summary */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                  <div>
                    <div className="font-bold text-slate-700 mb-1">
                      Basket Items ({order.items.reduce((sum, i) => sum + i.quantity, 0)} units):
                    </div>
                    <div className="text-slate-600 line-clamp-2">
                      {order.items.map((i) => `${i.quantity}x ${i.product.name}`).join(', ')}
                    </div>
                  </div>

                  <div>
                    <div className="font-bold text-slate-700 mb-1 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-emerald-600" /> Destination:
                    </div>
                    <div className="text-slate-600">
                      {order.deliveryAddress.street}, {order.deliveryAddress.apt ? order.deliveryAddress.apt + ', ' : ''}
                      {order.deliveryAddress.city} {order.deliveryAddress.zip}
                    </div>
                    {order.deliveryAddress.notes && (
                      <div className="text-[11px] text-slate-400 italic mt-0.5">
                        Instructions: &ldquo;{order.deliveryAddress.notes}&rdquo;
                      </div>
                    )}
                  </div>
                </div>

                {/* Status Stage Action Toolbar */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-400 font-semibold">Current State:</span>
                    <span className="font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full text-[11px] bg-slate-100 text-slate-800">
                      {order.status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  {/* Operational Advancement Triggers */}
                  <div className="flex flex-wrap gap-2">
                    {order.status === 'order_confirmed' && (
                      <button
                        onClick={() => onAdvanceOrderStatus(order.id, 'picked_packed')}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                      >
                        <Package className="w-3.5 h-3.5" />
                        <span>Advance: Mark Picked &amp; Cold Packed</span>
                      </button>
                    )}

                    {order.status === 'picked_packed' && (
                      <button
                        onClick={() => onAdvanceOrderStatus(order.id, 'out_for_delivery')}
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>Advance: Dispatch Courier Route</span>
                      </button>
                    )}

                    {order.status === 'out_for_delivery' && (
                      <button
                        onClick={() => onAdvanceOrderStatus(order.id, 'delivered')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Advance: Confirm Doorstep Drop</span>
                      </button>
                    )}

                    {order.status === 'delivered' && (
                      <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Completed &amp; Delivery Email Sent
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: REAL-TIME INVENTORY MANAGEMENT */}
      {activeTab === 'inventory' && (
        <div className="space-y-4">
          {/* Search & Stock Filter */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-3 bg-white p-4 rounded-2xl border border-slate-200">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Filter by Name, SKU, Barcode, or Aisle..."
                value={inventorySearch}
                onChange={(e) => setInventorySearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:bg-white focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-center gap-2 text-xs w-full sm:w-auto">
              <button
                onClick={() => setInventoryStockFilter('all')}
                className={`px-3 py-1.5 rounded-xl font-semibold transition ${
                  inventoryStockFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                All SKUs ({products.length})
              </button>
              <button
                onClick={() => setInventoryStockFilter('low')}
                className={`px-3 py-1.5 rounded-xl font-semibold transition ${
                  inventoryStockFilter === 'low' ? 'bg-amber-500 text-white font-bold' : 'bg-amber-50 text-amber-900 border border-amber-200'
                }`}
              >
                Low Stock ({lowStockCount})
              </button>
              <button
                onClick={() => setInventoryStockFilter('out')}
                className={`px-3 py-1.5 rounded-xl font-semibold transition ${
                  inventoryStockFilter === 'out' ? 'bg-rose-600 text-white font-bold' : 'bg-rose-50 text-rose-900 border border-rose-200'
                }`}
              >
                Out of Stock ({outOfStockCount})
              </button>
            </div>
          </div>

          {/* Product Inventory Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4">Item &amp; Category</th>
                    <th className="py-3 px-4">SKU / Barcode</th>
                    <th className="py-3 px-4">Aisle / Shelf</th>
                    <th className="py-3 px-4">Retail Price</th>
                    <th className="py-3 px-4 text-center">Live Hub Stock</th>
                    <th className="py-3 px-4 text-right">Quick Restock &amp; Edit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map((p) => {
                    const isEditing = editingProductId === p.id;
                    const isLow = p.stock > 0 && p.stock <= p.lowStockThreshold;
                    const isOut = p.stock === 0;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/70 transition">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                            />
                            <div>
                              <div className="font-bold text-slate-900">{p.name}</div>
                              <div className="text-[10px] text-slate-400">{p.category} · {p.unit}</div>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                          <div>{p.sku}</div>
                          <div className="text-[10px] text-slate-400 flex items-center gap-1">
                            <Barcode className="w-3 h-3" /> {p.barcode}
                          </div>
                        </td>

                        <td className="py-3 px-4 text-slate-600">
                          <div>{p.aisle}</div>
                          <div className="text-[10px] text-slate-400">{p.shelf}</div>
                        </td>

                        <td className="py-3 px-4">
                          {isEditing ? (
                            <input
                              type="number"
                              step="0.1"
                              value={editPrice}
                              onChange={(e) => setEditPrice(parseFloat(e.target.value) || 0)}
                              className="w-20 px-2 py-1 bg-white border border-slate-300 rounded font-bold"
                            />
                          ) : (
                            <span className="font-extrabold text-slate-900">${p.price.toFixed(2)}</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {isEditing ? (
                            <input
                              type="number"
                              value={editStock}
                              onChange={(e) => setEditStock(parseInt(e.target.value, 10) || 0)}
                              className="w-16 px-2 py-1 text-center bg-white border border-slate-300 rounded font-bold"
                            />
                          ) : (
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold ${
                                isOut
                                  ? 'bg-rose-100 text-rose-800'
                                  : isLow
                                  ? 'bg-amber-100 text-amber-800 animate-pulse'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {p.stock} units
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-right">
                          {isEditing ? (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleSaveEdit(p.id)}
                                className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 flex items-center gap-1"
                              >
                                <Save className="w-3 h-3" /> Save
                              </button>
                              <button
                                onClick={() => setEditingProductId(null)}
                                className="px-2 py-1 bg-slate-200 text-slate-700 rounded-lg text-xs"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => onUpdateProductStock(p.id, p.stock + 10)}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition"
                                title="Quick restock +10 units"
                              >
                                +10
                              </button>
                              <button
                                onClick={() => onUpdateProductStock(p.id, p.stock + 25)}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition"
                                title="Quick restock +25 units"
                              >
                                +25
                              </button>
                              <button
                                onClick={() => handleStartEdit(p)}
                                className="p-1 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition"
                                title="Edit Price & Custom Stock"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CUSTOMER CRM DATABASE */}
      {activeTab === 'customers' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search customers by name, email, or tier..."
                value={customerSearch}
                onChange={(e) => setCustomerSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:bg-white focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="text-xs text-slate-500">
              Total Managed Accounts: <strong>{customers.length}</strong>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredCustomers.map((cust) => (
              <div
                key={cust.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm">{cust.name}</h3>
                    <p className="text-xs text-slate-400">{cust.email} · {cust.phone}</p>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold uppercase bg-amber-100 text-amber-900">
                    {cust.loyaltyTier}
                  </span>
                </div>

                <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{cust.address}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 italic">
                    Notes: &ldquo;{cust.notes}&rdquo;
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs pt-1">
                  <div className="bg-slate-50 p-2 rounded-xl">
                    <div className="text-[10px] text-slate-400">Total Orders</div>
                    <div className="font-black text-slate-900">{cust.totalOrders}</div>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-xl">
                    <div className="text-[10px] text-slate-400">Lifetime Spend</div>
                    <div className="font-black text-emerald-800">${cust.totalSpent.toFixed(2)}</div>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-xl">
                    <div className="text-[10px] text-slate-400">Loyalty Pts</div>
                    <div className="font-black text-amber-700">{cust.loyaltyPoints}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: STORE ANALYTICS */}
      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
            <h3 className="text-base font-extrabold text-slate-900 mb-4">
              Fulfillment &amp; Operational Efficiency
            </h3>
            <div className="space-y-4 text-xs">
              <div>
                <div className="flex justify-between font-semibold text-slate-700 mb-1">
                  <span>Same-Day On-Time Delivery Rate</span>
                  <span className="font-bold text-emerald-700">98.4%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-2 rounded-full w-[98.4%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-semibold text-slate-700 mb-1">
                  <span>Inventory Accuracy &amp; Quality Check</span>
                  <span className="font-bold text-emerald-700">99.2%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-2 rounded-full w-[99.2%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-semibold text-slate-700 mb-1">
                  <span>Average Basket Fulfillment Speed</span>
                  <span className="font-bold text-slate-800">12.5 minutes</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-teal-600 h-2 rounded-full w-[85%]" />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
            <h3 className="text-base font-extrabold text-slate-900 mb-4">
              Top Selling Supermarket Staples
            </h3>
            <div className="divide-y divide-slate-100 text-xs">
              {products.slice(0, 5).map((p, idx) => (
                <div key={p.id} className="py-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-[10px]">
                      {idx + 1}
                    </span>
                    <span className="font-bold text-slate-900">{p.name}</span>
                  </div>
                  <span className="font-mono text-emerald-800 font-bold">${p.price.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
