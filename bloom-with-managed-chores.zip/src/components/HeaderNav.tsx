import React from 'react';
import { 
  Calendar, 
  Clock, 
  Inbox, 
  CheckSquare, 
  Target, 
  Printer, 
  Plus, 
  Moon, 
  Sparkles,
  Flower2,
  Home,
  GraduationCap,
  GitBranch
} from 'lucide-react';
import { FloralCorner } from './FloralAccents';
import { TimetablePersona } from '../types/planner';
import { PersonaSwitcher } from './PersonaSwitcher';
import { PERSONA_CONFIGS } from '../data/personaData';

export type ActiveTab = 'weekly' | 'focus' | 'chores' | 'study' | 'inbox' | 'checklists' | 'goals' | 'print';

interface HeaderNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onOpenQuickCapture: () => void;
  onOpenShutdown: () => void;
  onOpenPrintStudio: () => void;
  onOpenGitHubExport: () => void;
  currentPersona: TimetablePersona;
  onSelectPersona: (persona: TimetablePersona) => void;
  openLoopsCount: number;
  todayDoneCount: number;
}

export function HeaderNav({
  activeTab,
  onTabChange,
  onOpenQuickCapture,
  onOpenShutdown,
  onOpenPrintStudio,
  onOpenGitHubExport,
  currentPersona,
  onSelectPersona,
  openLoopsCount,
  todayDoneCount,
}: HeaderNavProps) {
  const personaCfg = PERSONA_CONFIGS[currentPersona];

  return (
    <header className="bg-[#fdfcf9] no-print">
      {/* Variation 1 Main Nav */}
      <nav className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-4 sm:px-8 py-4 sm:py-5 border-b-[1.5px] border-[#1a1a1a]">
        <div className="flex flex-wrap items-baseline gap-3 sm:gap-5">
          <div className="font-serif-cormorant text-2xl sm:text-3xl font-semibold tracking-[-0.02em] text-[#1a1a1a]">
            Bloom &amp; Order
          </div>
          <div className="font-mono-space text-[10px] sm:text-[11px] uppercase tracking-[0.15em] text-[#1a1a1a]/60">
            Edition 2024 / Vol. 01 • <span className="text-[#7b2c3c] font-bold">{personaCfg.shortLabel.toUpperCase()} MODE</span>
          </div>
        </div>

        {/* Action Controls & Persona Selector */}
        <div className="flex items-center flex-wrap gap-2 sm:gap-3">
          <PersonaSwitcher
            currentPersona={currentPersona}
            onSelectPersona={onSelectPersona}
            compact={true}
          />

          <button
            onClick={onOpenQuickCapture}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-[#1a1a1a] bg-transparent hover:bg-[#f2efeb] text-[#1a1a1a] font-mono-space text-xs tracking-wider uppercase transition-colors cursor-pointer"
            title="Capture task or distraction (Cmd+K)"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Capture</span>
            <kbd className="hidden lg:inline-block px-1 text-[9px] bg-[#1a1a1a]/10 text-[#1a1a1a]">
              ⌘K
            </kbd>
          </button>

          <button
            onClick={onOpenShutdown}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-[#1a1a1a] bg-transparent hover:bg-[#f2efeb] text-[#1a1a1a] font-mono-space text-xs tracking-wider uppercase transition-colors cursor-pointer"
            title="Start daily 10-minute evening shutdown"
          >
            <Moon className="w-3.5 h-3.5 text-[#7b2c3c]" />
            <span className="hidden sm:inline">Nightly</span> Shutdown
          </button>

          <button
            onClick={onOpenPrintStudio}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1a1a1a] hover:bg-[#7b2c3c] text-[#fdfcf9] font-mono-space text-xs tracking-wider uppercase transition-colors cursor-pointer font-bold shadow-xs"
            title="Printable stationery studio"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Studio</span>
          </button>

          <button
            onClick={onOpenGitHubExport}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 border border-[#1a1a1a]/30 hover:border-[#1a1a1a] text-[#1a1a1a] font-mono-space text-xs tracking-wider uppercase transition-colors cursor-pointer"
            title="View & download README.md, index.html and GitHub files"
          >
            <GitBranch className="w-3.5 h-3.5 text-[#7b2c3c]" />
            <span className="hidden sm:inline">Repo</span>
          </button>
        </div>
      </nav>

      {/* Navigation Tabs Sub-Bar */}
      <div className="px-4 sm:px-8 border-b border-[#1a1a1a]/10 bg-[#fdfcf9]">
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto scrollbar-none py-1.5">
          {[
            { id: 'weekly', label: 'The Schedule', badge: '7-Day' },
            { id: 'focus', label: 'Daily Focus', badge: 'Pomodoro' },
            { id: 'chores', label: 'Sanctuary Reset', badge: '15m Tidy' },
            { id: 'study', label: 'Study & Recall', badge: 'Spaced' },
            { id: 'inbox', label: 'Master Inbox', badge: openLoopsCount > 0 ? String(openLoopsCount) : undefined },
            { id: 'checklists', label: 'Repeat Rituals', badge: '5 Lists' },
            { id: 'goals', label: 'Priority Matrix', badge: 'OKRs' },
            { id: 'print', label: 'Print Templates', badge: 'A4 & Letter' },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id as ActiveTab)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-mono-space tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer border-b-2 ${
                  isActive
                    ? 'border-[#7b2c3c] text-[#7b2c3c] font-bold bg-[#f2efeb]/60'
                    : 'border-transparent text-[#1a1a1a]/60 hover:text-[#1a1a1a] hover:bg-[#f2efeb]/30'
                }`}
              >
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 font-mono-space font-bold ${
                      isActive
                        ? 'bg-[#7b2c3c] text-[#fdfcf9]'
                        : 'bg-[#1a1a1a]/10 text-[#1a1a1a]'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
