import React, { useState } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Circle, 
  Plus, 
  Trash2, 
  Sparkles, 
  Tag, 
  Flame, 
  Brain,
  RotateCcw,
  Check,
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudySession, DayOfWeek, TimetablePersona } from '../types/planner';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';
import { PersonaSwitcher } from './PersonaSwitcher';
import { PERSONA_CONFIGS } from '../data/personaData';

interface StudySchedulesViewProps {
  sessions: StudySession[];
  currentPersona?: TimetablePersona;
  onSelectPersona?: (persona: TimetablePersona) => void;
  onToggleSession: (sessionId: string) => void;
  onAddSession: (session: Omit<StudySession, 'id'>) => void;
  onDeleteSession: (sessionId: string) => void;
  onAdvanceSpacedRepetition: (sessionId: string) => void;
  onLaunchFocusTimer?: (session: StudySession) => void;
}

const SPACED_STAGES: StudySession['spacedRepetitionStage'][] = [
  'First Learning',
  'Day 1 Review',
  'Day 3 Recall',
  'Day 7 Practice',
  'Day 30 Mastery'
];

export function StudySchedulesView({
  sessions,
  currentPersona = 'student',
  onSelectPersona,
  onToggleSession,
  onAddSession,
  onDeleteSession,
  onAdvanceSpacedRepetition,
  onLaunchFocusTimer,
}: StudySchedulesViewProps) {
  const [selectedDay, setSelectedDay] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [isAddingNew, setIsAddingNew] = useState(false);

  const personaCfg = PERSONA_CONFIGS[currentPersona];

  // Form State
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [dayOfWeek, setDayOfWeek] = useState<DayOfWeek>('mon');
  const [durationMinutes, setDurationMinutes] = useState<number>(50);
  const [priority, setPriority] = useState<StudySession['priority']>('high');
  const [stage, setStage] = useState<StudySession['spacedRepetitionStage']>('First Learning');
  const [targetExamDate, setTargetExamDate] = useState('');
  const [keyConceptsStr, setKeyConceptsStr] = useState('');
  const [notes, setNotes] = useState('');

  // Extract unique subjects
  const subjectsList = Array.from(new Set(sessions.map(s => s.subject)));

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !topic.trim()) return;

    const concepts = keyConceptsStr
      .split(',')
      .map(c => c.trim())
      .filter(Boolean);

    onAddSession({
      subject: subject.trim(),
      topic: topic.trim(),
      dayOfWeek,
      durationMinutes,
      completed: false,
      priority,
      spacedRepetitionStage: stage,
      targetExamDate: targetExamDate || undefined,
      keyConcepts: concepts.length > 0 ? concepts : undefined,
      notes: notes.trim() || undefined,
    });

    setSubject('');
    setTopic('');
    setKeyConceptsStr('');
    setNotes('');
    setIsAddingNew(false);
    playGentleChime('sparkle');
  };

  const filteredSessions = sessions.filter(session => {
    if (selectedDay !== 'all' && session.dayOfWeek !== selectedDay) return false;
    if (selectedSubject !== 'all' && session.subject !== selectedSubject) return false;
    return true;
  });

  const completedCount = filteredSessions.filter(s => s.completed).length;
  const totalStudyMinutes = filteredSessions.reduce((acc, s) => acc + s.durationMinutes, 0);

  return (
    <div className="space-y-6">
      
      {/* Botanical Header Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-[#FAF0F2] via-[#FAF6F0] to-[#EDF2E8] border border-[#EADBCE] p-5 sm:p-6 shadow-xs overflow-hidden">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-24 h-24 text-[#8C3246]/20" />
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C3246] flex items-center gap-1.5">
              <PeonyIcon className="w-4 h-4" />
              {personaCfg.title} Curriculum &amp; Active Recall
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif-cormorant font-bold text-[#2D2326] mt-1">
              Study Schedules &amp; Spaced Mastery
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-[#5C4F51]">
              Plan study blocks into 25–50 minute Pomodoros. Master high-impact topics with spaced repetition intervals (Day 1, 3, 7, 30) and active recall testing before consulting answer keys.
            </p>
          </div>

          {onSelectPersona && (
            <div className="shrink-0">
              <PersonaSwitcher
                currentPersona={currentPersona}
                onSelectPersona={onSelectPersona}
                compact={false}
              />
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 Cols): Study Schedule Timetable & Sessions */}
        <div className="lg:col-span-2 space-y-5">
          
          {/* Controls Bar */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-4 sm:p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-serif-cormorant text-xl font-bold text-[#2D2326]">
                  {personaCfg.shortLabel} Focus Timetable
                </h3>
                <p className="text-xs text-[#786C6E]">
                  {completedCount} of {filteredSessions.length} sessions completed ({Math.round(totalStudyMinutes / 60 * 10) / 10} total hours planned)
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAddingNew(!isAddingNew)}
                  className="px-3.5 py-1.5 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAddingNew ? 'Cancel' : 'Add Study Block'}</span>
                </button>
              </div>
            </div>

            {/* Day of Week Filter */}
            <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto pb-1 scrollbar-none border-t border-[#EADBCE]/60 pt-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#786C6E] mr-1 shrink-0">
                Day:
              </span>
              {[
                { id: 'all', label: 'All Days' },
                { id: 'mon', label: 'Mon' },
                { id: 'tue', label: 'Tue' },
                { id: 'wed', label: 'Wed' },
                { id: 'thu', label: 'Thu' },
                { id: 'fri', label: 'Fri' },
                { id: 'sat', label: 'Sat' },
                { id: 'sun', label: 'Sun' },
              ].map(day => (
                <button
                  key={day.id}
                  onClick={() => setSelectedDay(day.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                    selectedDay === day.id
                      ? 'bg-[#8C3246] text-white font-semibold'
                      : 'bg-[#FAF6F0] text-[#5C4F51] hover:bg-[#F3E1E4]'
                  }`}
                >
                  {day.label}
                </button>
              ))}
            </div>

            {/* Subject Filter */}
            {subjectsList.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none pt-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#786C6E] mr-1 shrink-0">
                  Subject:
                </span>
                <button
                  onClick={() => setSelectedSubject('all')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                    selectedSubject === 'all'
                      ? 'bg-[#616D48] text-white font-semibold'
                      : 'bg-[#EDF2E8] text-[#4B5634] hover:bg-[#DEE7D7]'
                  }`}
                >
                  All Subjects
                </button>
                {subjectsList.map(subj => (
                  <button
                    key={subj}
                    onClick={() => setSelectedSubject(subj)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                      selectedSubject === subj
                        ? 'bg-[#616D48] text-white font-semibold'
                        : 'bg-[#EDF2E8] text-[#4B5634] hover:bg-[#DEE7D7]'
                    }`}
                  >
                    {subj}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Add Study Session Form */}
          {isAddingNew && (
            <form onSubmit={handleAddSubmit} className="bg-[#FAF6F0] rounded-2xl border-2 border-[#DDA5A5] p-5 shadow-xs space-y-4 animate-fade-in">
              <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                Schedule New Study Block &amp; Repetition
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Subject / Discipline
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Cognitive Psychology, Organic Chemistry"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Specific Topic / Chapter
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Reaction mechanisms, Bayes theorem"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Day Scheduled
                  </label>
                  <select
                    value={dayOfWeek}
                    onChange={(e) => setDayOfWeek(e.target.value as DayOfWeek)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  >
                    <option value="mon">Monday</option>
                    <option value="tue">Tuesday</option>
                    <option value="wed">Wednesday</option>
                    <option value="thu">Thursday</option>
                    <option value="fri">Friday</option>
                    <option value="sat">Saturday</option>
                    <option value="sun">Sunday</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Focus Duration
                  </label>
                  <select
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  >
                    <option value="25">25m Single Pomodoro</option>
                    <option value="50">50m Deep Block</option>
                    <option value="90">90m Double Focus Block</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Spaced Stage
                  </label>
                  <select
                    value={stage}
                    onChange={(e) => setStage(e.target.value as StudySession['spacedRepetitionStage'])}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  >
                    {SPACED_STAGES.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Key Concepts (comma-separated tags)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Isoprene Rule, Formula 4, Case Study"
                    value={keyConceptsStr}
                    onChange={(e) => setKeyConceptsStr(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                    Target Exam / Milestone Date
                  </label>
                  <input
                    type="date"
                    value={targetExamDate}
                    onChange={(e) => setTargetExamDate(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#5C4F51] mb-1">
                  Active Recall Practice Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Draw diagram from memory, explain aloud, solve problems 1-5"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingNew(false)}
                  className="px-4 py-2 rounded-xl bg-white border border-[#EADBCE] text-[#5C4F51] text-xs font-medium hover:bg-[#EADBCE]/50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs font-semibold shadow-xs cursor-pointer"
                >
                  Save Study Block
                </button>
              </div>
            </form>
          )}

          {/* Session Cards */}
          <div className="space-y-3">
            {filteredSessions.length === 0 ? (
              <div className="bg-white rounded-2xl border border-[#EADBCE] p-8 text-center">
                <p className="text-sm text-[#786C6E]">No study sessions found for current filters.</p>
              </div>
            ) : (
              filteredSessions.map(session => (
                <div
                  key={session.id}
                  className={`rounded-2xl border p-4 sm:p-5 transition-all duration-150 ${
                    session.completed
                      ? 'bg-[#FAF6F0]/60 border-[#EADBCE] opacity-80'
                      : 'bg-white border-[#EADBCE] hover:border-[#DDA5A5] shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <button
                        onClick={() => {
                          onToggleSession(session.id);
                          if (!session.completed) {
                            playGentleChime('success');
                            confetti({ particleCount: 30, spread: 50 });
                          }
                        }}
                        className="mt-1 text-[#8C3246] hover:text-[#732738] transition-colors cursor-pointer shrink-0"
                      >
                        {session.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-[#616D48]" />
                        ) : (
                          <Circle className="w-5 h-5 text-[#DDA5A5]" />
                        )}
                      </button>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold uppercase tracking-wider text-[#8C3246] bg-[#FAF0F2] px-2.5 py-0.5 rounded-full border border-[#DDA5A5]/40">
                            {session.subject}
                          </span>
                          <span className="text-[11px] font-semibold uppercase px-2 py-0.5 rounded-md bg-[#FAF6F0] text-[#5C4F51] border border-[#EADBCE]">
                            {session.dayOfWeek ? session.dayOfWeek.toUpperCase() : 'FLEX'}
                          </span>
                          <span className="text-xs text-[#786C6E] flex items-center gap-1 font-medium">
                            <Clock className="w-3.5 h-3.5 text-[#C28255]" />
                            {session.durationMinutes}m Pomodoro
                          </span>
                          {session.targetExamDate && (
                            <span className="text-[11px] text-[#616D48] font-medium flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              Exam: {session.targetExamDate}
                            </span>
                          )}
                        </div>

                        <h4 className={`text-base sm:text-lg font-serif-cormorant font-bold mt-1.5 ${
                          session.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'
                        }`}>
                          {session.topic}
                        </h4>

                        {/* Spaced repetition stage badge & progression */}
                        <div className="mt-2 flex items-center gap-2 flex-wrap text-xs">
                          <span className="text-[#786C6E] font-medium">Spaced Interval:</span>
                          <span className="px-2.5 py-0.5 rounded-full bg-[#EDF2E8] text-[#4B5634] font-semibold border border-[#616D48]/30 flex items-center gap-1">
                            <Brain className="w-3 h-3" />
                            {session.spacedRepetitionStage || 'First Learning'}
                          </span>
                          <button
                            onClick={() => onAdvanceSpacedRepetition(session.id)}
                            className="text-[11px] text-[#8C3246] hover:text-[#732738] font-medium flex items-center gap-0.5 underline cursor-pointer"
                            title="Advance to next recall interval"
                          >
                            <span>Next Stage</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Key Concepts Tags */}
                        {session.keyConcepts && session.keyConcepts.length > 0 && (
                          <div className="mt-2.5 flex items-center gap-1.5 flex-wrap">
                            <Tag className="w-3 h-3 text-[#786C6E]" />
                            {session.keyConcepts.map((concept, idx) => (
                              <span
                                key={idx}
                                className="text-[11px] px-2 py-0.5 bg-[#FAF6F0] rounded-md text-[#5C4F51] border border-[#EADBCE]"
                              >
                                {concept}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Active Recall Practice Notes */}
                        {session.notes && (
                          <p className="mt-2 text-xs text-[#5C4F51] bg-[#FAF6F0] p-2.5 rounded-xl border border-[#EADBCE]/80">
                            <strong>Active Recall Target:</strong> {session.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => onDeleteSession(session.id)}
                        className="text-[#DDA5A5] hover:text-[#8C3246] p-1.5 rounded-lg transition-colors cursor-pointer"
                        title="Delete study session"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Spaced Repetition Formula & Active Recall Guidelines */}
        <div className="space-y-5">
          
          {/* Spaced Repetition Protocol Box */}
          <div className="bg-[#FAF6F0] rounded-2xl border-2 border-[#DDA5A5] p-5 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-[#8C3246]" />
              <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                The Botanical Retention Curve
              </h4>
            </div>
            <p className="text-xs text-[#5C4F51]">
              Reviewing immediately before memory decays cements knowledge permanently. Follow this progression:
            </p>

            <div className="space-y-2 text-xs">
              {[
                { stage: 'First Learning', desc: 'Read topic, summarize in 3 bullet points with closed book.' },
                { stage: 'Day 1 Review', desc: '24 hours later: recall key formulas without glancing.' },
                { stage: 'Day 3 Recall', desc: 'Attempt sample problem or flashcard recall.' },
                { stage: 'Day 7 Practice', desc: 'Teach the concept to an empty chair or write 1-page summary.' },
                { stage: 'Day 30 Mastery', desc: 'Final review: complete past exam questions under time pressure.' },
              ].map((item, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-white border border-[#EADBCE]">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#8C3246]">{item.stage}</span>
                    <span className="text-[10px] text-[#786C6E]">Step {i + 1}</span>
                  </div>
                  <p className="text-[11px] text-[#5C4F51] mt-0.5">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Deep Focus Advice */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-5 shadow-xs space-y-3">
            <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
              Study Discipline Rules
            </h4>
            <div className="space-y-2.5 text-xs text-[#5C4F51]">
              <div className="flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-[#8C3246] mt-1 shrink-0" />
                <span>
                  <strong>One Tab Open:</strong> Close social media and messaging. Keep only your study PDF or paper notes open.
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-[#616D48] mt-1 shrink-0" />
                <span>
                  <strong>Active over Passive:</strong> Never passively re-read. Always test yourself, solve problems, or draw diagrams.
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-[#C28255] mt-1 shrink-0" />
                <span>
                  <strong>Park Distractions:</strong> If you think of a chore or errand, write it on the Parking Lot note and immediately return to studying.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
