import React, { useState, useRef, useEffect } from 'react';
import { 
  GraduationCap, 
  Briefcase, 
  HeartHandshake, 
  Flower2, 
  ChevronDown, 
  Check, 
  Sparkles,
  Info,
  Calendar,
  Clock,
  Home,
  BookOpen
} from 'lucide-react';
import { TimetablePersona, PersonaConfig } from '../types/planner';
import { PERSONA_CONFIGS } from '../data/personaData';

interface PersonaSwitcherProps {
  currentPersona: TimetablePersona;
  onSelectPersona: (persona: TimetablePersona) => void;
  compact?: boolean;
}

export function PersonaSwitcher({
  currentPersona,
  onSelectPersona,
  compact = false,
}: PersonaSwitcherProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState<TimetablePersona | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getPersonaIcon = (id: TimetablePersona, className: string = 'w-4 h-4') => {
    switch (id) {
      case 'student':
        return <GraduationCap className={className} />;
      case 'professional':
        return <Briefcase className={className} />;
      case 'working-mother':
        return <HeartHandshake className={className} />;
      case 'balanced':
      default:
        return <Flower2 className={className} />;
    }
  };

  const handleChoose = (persona: TimetablePersona) => {
    setIsOpen(false);
    if (persona === currentPersona) return;
    // Show gentle confirmation dialog
    setShowConfirmModal(persona);
  };

  const handleConfirmSwitch = () => {
    if (showConfirmModal) {
      onSelectPersona(showConfirmModal);
      setShowConfirmModal(null);
    }
  };

  const activeConfig = PERSONA_CONFIGS[currentPersona];
  const allPersonas: TimetablePersona[] = ['student', 'professional', 'working-mother', 'balanced'];

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      {/* Trigger Button */}
      {compact ? (
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#fdfcf9] hover:bg-[#f2efeb] border border-[#1a1a1a] text-[#1a1a1a] text-xs font-mono-space tracking-wider uppercase transition-all cursor-pointer"
          title="Switch Timetable Lifestyle Persona"
        >
          <span className="text-[#7b2c3c]">
            {getPersonaIcon(currentPersona, 'w-3.5 h-3.5')}
          </span>
          <span className="font-bold">{activeConfig.shortLabel}</span>
          <ChevronDown className={`w-3.5 h-3.5 text-[#1a1a1a]/60 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      ) : (
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full sm:w-auto inline-flex items-center justify-between gap-3 px-4 py-2.5 bg-[#fdfcf9] hover:bg-[#f2efeb] border-2 border-[#1a1a1a] text-[#1a1a1a] shadow-xs transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-2.5 text-left">
            <div className="w-8 h-8 bg-[#f2efeb] text-[#1a1a1a] flex items-center justify-center border border-[#1a1a1a]/30 group-hover:scale-105 transition-transform">
              {getPersonaIcon(currentPersona, 'w-4 h-4')}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-mono-space text-[9px] uppercase font-bold tracking-[0.18em] text-[#7b2c3c]">
                  [ TIMETABLE PERSONA ]
                </span>
              </div>
              <p className="font-serif-cormorant text-base font-bold text-[#1a1a1a]">
                {activeConfig.title}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 pl-2 border-l border-[#1a1a1a]/20">
            <span className="font-mono-space text-[10px] uppercase font-bold px-1.5 py-0.5 bg-[#1a1a1a] text-[#fdfcf9] hidden md:inline">
              SWITCH
            </span>
            <ChevronDown className={`w-4 h-4 text-[#1a1a1a] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </div>
        </button>
      )}

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 sm:left-0 sm:right-auto mt-2 w-80 sm:w-96 bg-[#fdfcf9] border-2 border-[#1a1a1a] shadow-2xl p-2 z-50 animate-fade-in no-print">
          <div className="px-3 py-2 border-b border-[#1a1a1a]/15">
            <p className="text-xs font-mono-space font-bold uppercase tracking-wider text-[#7b2c3c] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              [ CONVERT TIMETABLE PERSPECTIVE ]
            </p>
            <p className="text-[11px] text-[#1a1a1a]/70 font-sans mt-0.5">
              Select a lifestyle mode to adapt your weekly schedule, habits, study sessions &amp; sanctuary chores:
            </p>
          </div>

          <div className="py-1.5 space-y-1">
            {allPersonas.map((personaKey) => {
              const cfg = PERSONA_CONFIGS[personaKey];
              const isSelected = personaKey === currentPersona;

              return (
                <button
                  key={personaKey}
                  onClick={() => handleChoose(personaKey)}
                  className={`w-full text-left p-3 transition-all cursor-pointer flex items-start gap-3 ${
                    isSelected
                      ? 'bg-white border border-[#1a1a1a] shadow-xs'
                      : 'hover:bg-[#f2efeb] border border-transparent'
                  }`}
                >
                  <div className={`w-8 h-8 flex items-center justify-center shrink-0 mt-0.5 ${
                    isSelected
                      ? 'bg-[#1a1a1a] text-[#fdfcf9] shadow-xs'
                      : 'bg-[#f2efeb] text-[#1a1a1a] border border-[#1a1a1a]/20'
                  }`}>
                    {getPersonaIcon(personaKey, 'w-4 h-4')}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-serif-cormorant text-base font-bold text-[#1a1a1a]">
                        {cfg.title}
                      </span>
                      {isSelected && (
                        <span className="font-mono-space text-[9px] uppercase font-bold text-[#7b2c3c] flex items-center gap-1 shrink-0">
                          <Check className="w-3 h-3" />
                          CURRENT
                        </span>
                      )}
                    </div>
                    <p className="font-mono-space text-[10px] uppercase tracking-wide text-[#7b2c3c] font-bold">
                      {cfg.tagline}
                    </p>
                    <p className="text-[11px] text-[#1a1a1a]/70 mt-0.5 line-clamp-2 font-sans">
                      {cfg.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-1 pt-2 border-t border-[#1a1a1a]/15 px-3 py-1 font-mono-space text-[10px] text-[#1a1a1a]/60 text-center uppercase tracking-wider">
            All schedules persist offline via localStorage.
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in no-print">
          <div 
            className="w-full max-w-lg bg-[#FAF6F0] rounded-3xl p-6 shadow-2xl border-2 border-[#DDA5A5] space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#FAF0F2] text-[#8C3246] border border-[#DDA5A5] flex items-center justify-center shrink-0">
                {getPersonaIcon(showConfirmModal, 'w-6 h-6')}
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#8C3246]">
                  Confirm Timetable Transformation
                </span>
                <h3 className="text-lg sm:text-xl font-serif-cormorant font-bold text-[#2D2326]">
                  Switch to {PERSONA_CONFIGS[showConfirmModal].title}?
                </h3>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#5C4F51] leading-relaxed">
              This will update your <strong>7-day weekly timetable</strong>, <strong>daily habits</strong>, <strong>study sessions</strong>, <strong>home chores</strong>, and <strong>checklists</strong> to match the {PERSONA_CONFIGS[showConfirmModal].title} perspective.
            </p>

            {/* Persona Highlights Card */}
            <div className="bg-white rounded-2xl p-4 border border-[#EADBCE] text-xs space-y-2">
              <div className="font-semibold text-[#8C3246] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                What's included in this mode:
              </div>
              <ul className="space-y-1.5 text-[#5C4F51]">
                {showConfirmModal === 'student' && (
                  <>
                    <li className="flex items-center gap-2">
                      <GraduationCap className="w-3.5 h-3.5 text-[#616D48]" />
                      <span><strong>Academic Schedule:</strong> Lectures, lab reports, problem sets &amp; active recall</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#616D48]" />
                      <span><strong>Habits:</strong> 25m Anki review, campus hydration, sleep before 11:30 PM</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Home className="w-3.5 h-3.5 text-[#616D48]" />
                      <span><strong>Sanctuary:</strong> Dorm desk wipes, laundry cycles &amp; backpack packing</span>
                    </li>
                  </>
                )}
                {showConfirmModal === 'professional' && (
                  <>
                    <li className="flex items-center gap-2">
                      <Briefcase className="w-3.5 h-3.5 text-[#8C3246]" />
                      <span><strong>Executive Schedule:</strong> Strategic deep work sprints, OKRs, board presentations &amp; 1:1s</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#8C3246]" />
                      <span><strong>Habits:</strong> Top 3 before email, 50m focus blocks, 6:30 PM hard shutdown</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Home className="w-3.5 h-3.5 text-[#8C3246]" />
                      <span><strong>Sanctuary:</strong> Executive desk reset, cable declutter &amp; dry cleaning</span>
                    </li>
                  </>
                )}
                {showConfirmModal === 'working-mother' && (
                  <>
                    <li className="flex items-center gap-2">
                      <HeartHandshake className="w-3.5 h-3.5 text-[#B85B6C]" />
                      <span><strong>Family &amp; Career Schedule:</strong> School lunches, focused work sprints, afternoon pickup &amp; homework</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#B85B6C]" />
                      <span><strong>Habits:</strong> Morning quiet tea, 15m speed-tidy, bedtime story cuddle, 20m mama me-time</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Home className="w-3.5 h-3.5 text-[#B85B6C]" />
                      <span><strong>Sanctuary:</strong> Lunchbox sanitizing, living room toy resets &amp; Sunday family meal prep</span>
                    </li>
                  </>
                )}
                {showConfirmModal === 'balanced' && (
                  <>
                    <li className="flex items-center gap-2">
                      <Flower2 className="w-3.5 h-3.5 text-[#616D48]" />
                      <span><strong>Mindful Schedule:</strong> Creative deep work, thoughtful margins, and balanced routines</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#616D48]" />
                      <span><strong>Habits:</strong> Morning meditation, herbal tea breaks &amp; 10-minute evening shutdown</span>
                    </li>
                  </>
                )}
              </ul>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowConfirmModal(null)}
                className="px-4 py-2 border border-[#1a1a1a] bg-[#fdfcf9] text-[#1a1a1a] text-xs font-mono-space uppercase tracking-wider hover:bg-[#f2efeb] transition-colors cursor-pointer"
              >
                Keep Current
              </button>
              <button
                onClick={handleConfirmSwitch}
                className="px-5 py-2 bg-[#1a1a1a] hover:bg-[#7b2c3c] text-[#fdfcf9] text-xs font-mono-space uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs font-bold"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#7b2c3c]" />
                Apply {PERSONA_CONFIGS[showConfirmModal].shortLabel.toUpperCase()} Schedule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
