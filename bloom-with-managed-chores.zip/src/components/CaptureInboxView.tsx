import React, { useState } from 'react';
import { 
  Inbox, 
  Clock, 
  UserCheck, 
  AlertCircle, 
  Ban, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Zap, 
  Trash2, 
  ArrowRight, 
  Sparkles,
  Search,
  Filter
} from 'lucide-react';
import { TaskItem, TaskCategory, PriorityQuadrant, DayOfWeek } from '../types/planner';
import { suggestNextPhysicalAction } from '../utils/plannerLogic';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, PeonyIcon } from './FloralAccents';

interface CaptureInboxViewProps {
  tasks: TaskItem[];
  onToggleTask: (taskId: string) => void;
  onAddTask: (task: Partial<TaskItem>) => void;
  onDeleteTask: (taskId: string) => void;
  onAssignToDay: (taskId: string, day: DayOfWeek) => void;
}

export function CaptureInboxView({
  tasks,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  onAssignToDay,
}: CaptureInboxViewProps) {
  const [activeCategory, setActiveCategory] = useState<TaskCategory>('inbox');
  const [newTitle, setNewTitle] = useState('');
  const [delegatedTo, setDelegatedTo] = useState('');
  const [definitionOfDone, setDefinitionOfDone] = useState('');
  const [priority, setPriority] = useState<PriorityQuadrant>('important-not-urgent');
  const [suggestedAction, setSuggestedAction] = useState('');

  // Handle title typing and auto-suggest next physical action
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setNewTitle(val);
    setSuggestedAction(suggestNextPhysicalAction(val));
  };

  const handleCaptureSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddTask({
      title: newTitle.trim(),
      category: activeCategory,
      priority,
      nextPhysicalAction: suggestedAction.trim() || undefined,
      definitionOfDone: definitionOfDone.trim() || undefined,
      delegatedTo: activeCategory === 'waiting-for' ? (delegatedTo.trim() || 'Awaiting response') : undefined,
      completed: false,
      dateAdded: new Date().toISOString().split('T')[0],
    });

    setNewTitle('');
    setDelegatedTo('');
    setDefinitionOfDone('');
    setSuggestedAction('');
    playGentleChime('sparkle');
  };

  const categoryTasks = tasks.filter(t => t.category === activeCategory);

  const getCategoryDetails = (cat: TaskCategory) => {
    switch (cat) {
      case 'inbox':
        return {
          title: 'Master Capture Inbox',
          subtitle: 'One inbox for everything. Get tasks out of your head immediately.',
          badgeColor: 'bg-[#8C3246] text-white',
        };
      case 'under-2-min':
        return {
          title: 'Under-2-Minute Quick Wins',
          subtitle: 'The 2-Minute Rule: If it takes under 2 minutes, do it right now instead of scheduling.',
          badgeColor: 'bg-[#616D48] text-white',
        };
      case 'waiting-for':
        return {
          title: 'Waiting-For List',
          subtitle: 'Deliverables and replies other people owe you. Never drop a follow-up loop.',
          badgeColor: 'bg-[#C28255] text-white',
        };
      case 'parking-lot':
        return {
          title: 'Focus Parking Lot',
          subtitle: 'Mid-focus distractions captured in moments so you can stay in flow.',
          badgeColor: 'bg-[#786C6E] text-white',
        };
      case 'not-to-do':
        return {
          title: 'Not-To-Do Guardrails',
          subtitle: 'Boundaries to defend your energy and eliminate chronic time-wasters.',
          badgeColor: 'bg-rose-900 text-white',
        };
      default:
        return {
          title: 'Inbox',
          subtitle: '',
          badgeColor: 'bg-stone-800 text-white',
        };
    }
  };

  const currentCat = getCategoryDetails(activeCategory);

  return (
    <div className="space-y-6">
      
      {/* Category Pills Selector */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'inbox', label: 'One Inbox', icon: Inbox, count: tasks.filter(t => t.category === 'inbox' && !t.completed).length },
          { id: 'under-2-min', label: '< 2-Minute Wins', icon: Clock, count: tasks.filter(t => t.category === 'under-2-min' && !t.completed).length },
          { id: 'waiting-for', label: 'Waiting-For', icon: UserCheck, count: tasks.filter(t => t.category === 'waiting-for' && !t.completed).length },
          { id: 'parking-lot', label: 'Parking Lot', icon: AlertCircle, count: tasks.filter(t => t.category === 'parking-lot' && !t.completed).length },
          { id: 'not-to-do', label: 'Not-To-Do List', icon: Ban, count: tasks.filter(t => t.category === 'not-to-do').length },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeCategory === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id as TaskCategory)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all duration-150 cursor-pointer ${
                isActive
                  ? 'bg-[#8C3246] text-white shadow-xs font-semibold'
                  : 'bg-white text-[#5C4F51] hover:bg-[#FAF0F2] border border-[#EADBCE]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.count > 0 && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  isActive ? 'bg-white/25 text-white' : 'bg-[#EADBCE] text-[#8C3246]'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Main Capture Card Form */}
      <div className="bg-white rounded-3xl border border-[#EADBCE] p-5 sm:p-6 shadow-xs relative">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-20 h-20 text-[#8C3246]/15" />
        
        <div className="mb-4">
          <h3 className="font-serif-cormorant text-2xl font-bold text-[#2D2326]">
            {currentCat.title}
          </h3>
          <p className="text-xs sm:text-sm text-[#786C6E]">
            {currentCat.subtitle}
          </p>
        </div>

        <form onSubmit={handleCaptureSubmit} className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              placeholder={
                activeCategory === 'waiting-for'
                  ? 'e.g., Waiting for Ali to email the invoice...'
                  : activeCategory === 'under-2-min'
                  ? 'e.g., Reply to client text confirmation...'
                  : activeCategory === 'not-to-do'
                  ? 'e.g., No checking social feeds before 11:00 AM...'
                  : 'Capture any task or open loop living in your head...'
              }
              value={newTitle}
              onChange={handleTitleChange}
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs sm:text-sm font-semibold shadow-xs transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Capture Loop</span>
            </button>
          </div>

          {/* Action Recommendation Banner (Crucial user prompt rule: "write each task as a next physical action") */}
          {suggestedAction && (
            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-[#EDF2E8] border border-[#616D48]/30 text-xs text-[#4B5634]">
              <Zap className="w-4 h-4 text-[#8C3246] shrink-0" />
              <span className="font-semibold">Recommended Physical Action:</span>
              <span className="italic flex-1">{suggestedAction}</span>
              <button
                type="button"
                onClick={() => setNewTitle(suggestedAction)}
                className="text-[11px] underline font-bold hover:text-[#2D2326] cursor-pointer"
              >
                Use This
              </button>
            </div>
          )}

          {/* Extra Details Expandable */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-bold text-[#786C6E] uppercase mb-1">
                Definition of Done (Clear finish line)
              </label>
              <input
                type="text"
                placeholder="e.g. Email sent, receipt filed in folder..."
                value={definitionOfDone}
                onChange={(e) => setDefinitionOfDone(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-[#FAF6F0] border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
              />
            </div>

            {activeCategory === 'waiting-for' ? (
              <div>
                <label className="block text-[11px] font-bold text-[#786C6E] uppercase mb-1">
                  Person or Vendor Owed By
                </label>
                <input
                  type="text"
                  placeholder="e.g. Ali (Accountant), Cornerstone Printhouse..."
                  value={delegatedTo}
                  onChange={(e) => setDelegatedTo(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-[#FAF6F0] border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                />
              </div>
            ) : (
              <div>
                <label className="block text-[11px] font-bold text-[#786C6E] uppercase mb-1">
                  Eisenhower Priority
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as PriorityQuadrant)}
                  className="w-full px-3 py-1.5 rounded-lg bg-[#FAF6F0] border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                >
                  <option value="important-not-urgent">Important (Moves Goals • Schedule First)</option>
                  <option value="urgent-important">Urgent &amp; Important (Crises / Deadlines)</option>
                  <option value="urgent-not-important">Urgent, Not Important (Delegate / Batch)</option>
                  <option value="not-urgent-not-important">Neither (Drop / Minimize)</option>
                </select>
              </div>
            )}
          </div>
        </form>
      </div>

      {/* Task List */}
      <div className="bg-white rounded-3xl border border-[#EADBCE] p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-serif-cormorant text-xl font-bold text-[#2D2326]">
            {categoryTasks.length} {currentCat.title} Items
          </h4>
          <span className="text-xs text-[#786C6E]">
            {categoryTasks.filter(t => t.completed).length} closed
          </span>
        </div>

        {categoryTasks.length === 0 ? (
          <div className="py-8 text-center">
            <p className="text-sm text-[#786C6E] italic">
              No tasks in this category. Your mind and loops are clear!
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {categoryTasks.map((task) => (
              <div
                key={task.id}
                className={`p-4 rounded-2xl border transition-all duration-150 ${
                  task.completed
                    ? 'bg-[#F4F7F2] border-[#616D48]/30 opacity-75'
                    : 'bg-[#FAF6F0]/60 border-[#EADBCE] hover:border-[#DDA5A5] shadow-2xs'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <button
                      onClick={() => {
                        onToggleTask(task.id);
                        if (!task.completed) playGentleChime('success');
                      }}
                      className="mt-0.5 text-[#8C3246] hover:scale-110 transition-transform cursor-pointer"
                    >
                      {task.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-[#616D48] fill-[#EDF2E8]" />
                      ) : (
                        <Circle className="w-5 h-5 text-[#DDA5A5]" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <p className={`text-sm font-semibold ${task.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'}`}>
                        {task.title}
                      </p>

                      {task.delegatedTo && (
                        <div className="mt-1 flex items-center gap-1.5 text-xs text-[#C28255] font-medium">
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Waiting on: {task.delegatedTo}</span>
                        </div>
                      )}

                      {task.nextPhysicalAction && (
                        <div className="mt-1.5 text-xs text-[#535E3B] flex items-center gap-1 bg-[#EDF2E8] px-2.5 py-1 rounded-md max-w-fit">
                          <Zap className="w-3 h-3 text-[#616D48]" />
                          <span>Action: {task.nextPhysicalAction}</span>
                        </div>
                      )}

                      {task.definitionOfDone && (
                        <div className="mt-1 text-[11px] text-[#786C6E] italic">
                          Done criteria: {task.definitionOfDone}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions: Schedule to day, or delete */}
                  <div className="flex items-center gap-2">
                    <div className="hidden sm:flex items-center gap-1">
                      <span className="text-[11px] text-[#786C6E] mr-1">Assign to:</span>
                      {(['mon', 'tue', 'wed', 'thu', 'fri'] as DayOfWeek[]).map((day) => (
                        <button
                          key={day}
                          onClick={() => {
                            onAssignToDay(task.id, day);
                            playGentleChime('sparkle');
                          }}
                          className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-white hover:bg-[#FAF0F2] text-[#8C3246] border border-[#EADBCE] cursor-pointer"
                        >
                          {day}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={() => onDeleteTask(task.id)}
                      className="p-1.5 rounded-lg text-[#9B8F91] hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
