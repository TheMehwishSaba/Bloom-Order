import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  MapPin, 
  Award, 
  Bell, 
  Clock, 
  Layers, 
  X,
  ChevronDown,
  Sparkles,
  Store
} from 'lucide-react';
import { LoyaltyProfile, EmailNotification } from '../types/store';

interface NavbarProps {
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  loyaltyProfile: LoyaltyProfile;
  onOpenLoyalty: () => void;
  onOpenOrders: () => void;
  onOpenStoreOps: () => void;
  isStoreOpsActive: boolean;
  notifications: EmailNotification[];
  onOpenNotifications: () => void;
  currentAddress: string;
  onChangeAddress: (newAddr: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  cartTotal,
  onOpenCart,
  searchQuery,
  onSearchChange,
  loyaltyProfile,
  onOpenLoyalty,
  onOpenOrders,
  onOpenStoreOps,
  isStoreOpsActive,
  notifications,
  onOpenNotifications,
  currentAddress,
  onChangeAddress,
}) => {
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [tempAddress, setTempAddress] = useState(currentAddress);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <>
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-900 text-white text-xs font-medium py-2 px-4 shadow-sm border-b border-emerald-800/40">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-1.5 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-emerald-950 uppercase tracking-wide">
              Same-Day Fresh
            </span>
            <span>Free Express Delivery on orders over $45 • Use code <strong>SAVE10</strong> for 10% off</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-emerald-200">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-300" /> Open Today: 7:00 AM – 11:00 PM
            </span>
            <span className="hidden md:inline text-emerald-400">•</span>
            <span className="hidden md:flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" /> 100% Quality & Cold-Chain Guarantee
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            
            <div className="flex items-center justify-between gap-2">
              {/* Logo & Store Identity */}
              <div className="flex items-center gap-2.5">
                <button 
                  onClick={() => {
                    if (isStoreOpsActive) onOpenStoreOps();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="flex items-center gap-2 text-left group focus:outline-none"
                >
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white shadow-md shadow-emerald-900/10 group-hover:scale-105 transition-transform">
                    <Store className="w-5 h-5 text-emerald-100" />
                  </div>
                  <div>
                    <div className="font-extrabold text-base sm:text-xl tracking-tight text-slate-900 flex items-center gap-1.5">
                      Cornerstone
                      <span className="text-emerald-700 font-semibold text-[10px] sm:text-xs uppercase tracking-wider px-1.5 py-0.5 bg-emerald-50 rounded border border-emerald-200 hidden sm:inline-block">
                        Market
                      </span>
                    </div>
                    <p className="text-[10px] sm:text-[11px] text-slate-500 hidden sm:block font-medium">
                      Fresh Supermarket &amp; Daily General Store
                    </p>
                  </div>
                </button>

                {/* Delivery Address Pill */}
                <button
                  onClick={() => setShowAddressModal(true)}
                  className="hidden lg:flex items-center gap-2 px-3 py-1.5 text-left bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs transition"
                  title="Change delivery location"
                >
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div className="truncate max-w-[170px]">
                    <div className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Deliver to</div>
                    <div className="font-semibold text-slate-800 truncate">{currentAddress}</div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                </button>
              </div>

              {/* Action Buttons: Ops, Loyalty, Notifications, Orders, Cart */}
              <div className="flex items-center gap-1 sm:gap-2">
                
                {/* Store Operations */}
                <button
                  onClick={onOpenStoreOps}
                  className={`p-1.5 sm:px-3 sm:py-2 text-xs font-semibold rounded-lg border transition ${
                    isStoreOpsActive
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                  title="Store Operations, Real-Time Inventory & Customer Database"
                >
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span className="hidden xl:inline ml-1.5">Store Ops</span>
                </button>

                {/* Loyalty Badge */}
                <button
                  onClick={onOpenLoyalty}
                  className="flex items-center gap-1 px-2 sm:px-3 py-1.5 sm:py-2 bg-amber-50 hover:bg-amber-100/80 border border-amber-200 text-amber-900 rounded-lg text-xs font-semibold transition"
                  title="View Loyalty Rewards & Perks"
                >
                  <Award className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span className="hidden sm:inline font-bold">{loyaltyProfile.points.toLocaleString()} pts</span>
                  <span className="text-[10px] bg-amber-200/80 text-amber-900 px-1 py-0.5 rounded uppercase font-extrabold">
                    {loyaltyProfile.tier}
                  </span>
                </button>

                {/* Email Notifications Center */}
                <button
                  onClick={onOpenNotifications}
                  className="relative p-1.5 sm:p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition"
                  title="Delivery & Order Status Email Inbox"
                >
                  <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-rose-500 text-white font-bold text-[9px] sm:text-[10px] rounded-full flex items-center justify-center ring-2 ring-white animate-pulse">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* User Order History */}
                <button
                  onClick={onOpenOrders}
                  className="hidden md:flex items-center gap-1.5 px-3 py-2 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-semibold border border-transparent hover:border-slate-200 transition"
                >
                  <span>Orders</span>
                </button>

                {/* Cart Drawer Trigger */}
                <button
                  onClick={onOpenCart}
                  className="flex items-center gap-1 sm:gap-2 p-1.5 sm:px-3.5 sm:py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm shadow-emerald-700/20 active:scale-95 transition"
                  aria-label="View shopping cart"
                >
                  <div className="relative">
                    <ShoppingBag className="w-4 h-4" />
                    {cartCount > 0 && (
                      <span className="absolute -top-2 -right-2 bg-amber-400 text-emerald-950 text-[9px] sm:text-[10px] font-extrabold rounded-full w-3.5 h-3.5 sm:w-4 sm:h-4 flex items-center justify-center">
                        {cartCount}
                      </span>
                    )}
                  </div>
                  <span className="font-bold text-[11px] sm:text-xs hidden min-[420px]:inline">
                    ${cartTotal.toFixed(2)}
                  </span>
                </button>

              </div>
            </div>

            {/* Live Search Bar */}
            <div className="w-full md:flex-1 md:max-w-md md:mx-auto">
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search groceries (apples, bread, milk...)"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full pl-10 pr-9 py-2 bg-slate-100 hover:bg-slate-50 focus:bg-white text-xs sm:text-sm text-slate-800 rounded-full border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition outline-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => onSearchChange('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* Address Switcher Modal */}
      {showAddressModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Select Delivery Destination</h3>
              </div>
              <button onClick={() => setShowAddressModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Enter your address to verify real-time inventory from your closest Cornerstone regional fulfillment hub.
            </p>
            <input
              type="text"
              value={tempAddress}
              onChange={(e) => setTempAddress(e.target.value)}
              placeholder="e.g. 742 Evergreen Terrace, Springfield"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm mb-4 focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowAddressModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onChangeAddress(tempAddress);
                  setShowAddressModal(false);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm"
              >
                Update Location
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
