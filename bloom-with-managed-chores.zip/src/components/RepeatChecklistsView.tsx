import React, { useState } from 'react';
import { 
  CheckSquare, 
  RotateCcw, 
  Plus, 
  Printer, 
  ShoppingBag, 
  Moon, 
  Compass, 
  Sparkles, 
  Flower2, 
  CheckCircle2, 
  Circle, 
  Trash2 
} from 'lucide-react';
import { RepeatChecklist } from '../types/planner';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';
import confetti from 'canvas-confetti';

interface RepeatChecklistsViewProps {
  checklists: RepeatChecklist[];
  onToggleItem: (checklistId: string, itemId: string) => void;
  onResetChecklist: (checklistId: string) => void;
  onAddItem: (checklistId: string, text: string) => void;
  onDeleteItem: (checklistId: string, itemId: string) => void;
  onOpenPrintStudio: () => void;
}

export function RepeatChecklistsView({
  checklists,
  onToggleItem,
  onResetChecklist,
  onAddItem,
  onDeleteItem,
  onOpenPrintStudio,
}: RepeatChecklistsViewProps) {
  const [selectedListId, setSelectedListId] = useState<string>(checklists[0]?.id || '');
  const [newItemText, setNewItemText] = useState('');

  const activeList = checklists.find(c => c.id === selectedListId) || checklists[0];

  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemText.trim() || !activeList) return;

    onAddItem(activeList.id, newItemText.trim());
    setNewItemText('');
    playGentleChime('sparkle');
  };

  const getListIcon = (category: string) => {
    switch (category) {
      case 'shutdown':
        return <Moon className="w-5 h-5 text-[#8C3246]" />;
      case 'sunday-reset':
        return <Compass className="w-5 h-5 text-[#616D48]" />;
      case 'weekly-shop':
        return <ShoppingBag className="w-5 h-5 text-[#C28255]" />;
      case 'monthly-declutter':
        return <Sparkles className="w-5 h-5 text-[#786C6E]" />;
      default:
        return <Flower2 className="w-5 h-5 text-[#8C3246]" />;
    }
  };

  const completedCount = activeList?.items.filter(i => i.completed).length || 0;
  const totalCount = activeList?.items.length || 0;
  const isAllDone = totalCount > 0 && completedCount === totalCount;

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-[#FAF0F2] via-[#FAF6F0] to-[#EDF2E8] border border-[#EADBCE] p-5 sm:p-6 shadow-xs overflow-hidden">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-24 h-24 text-[#8C3246]/20" />
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C3246] flex items-center gap-1.5">
              <PeonyIcon className="w-4 h-4" />
              Repeat Routine Engine
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif-cormorant font-bold text-[#2D2326] mt-1">
              Checklists for Repeat Excellence
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-[#5C4F51] max-w-2xl">
              "Make checklists for repeat tasks (travel, bills, weekly shop), so you never rebuild them from memory." Reset every week with a single click.
            </p>
          </div>

          <button
            onClick={onOpenPrintStudio}
            className="px-4 py-2.5 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs sm:text-sm font-medium shadow-sm transition-all duration-150 flex items-center gap-2 cursor-pointer self-start sm:self-auto"
          >
            <Printer className="w-4 h-4" />
            <span>Print Checklists</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left Selector / Right Checklist Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Checklist Selector */}
        <div className="space-y-2.5">
          <h3 className="font-serif-cormorant text-lg font-bold text-[#2D2326] px-1">
            Master Routine Cards
          </h3>
          {checklists.map((list) => {
            const isSelected = list.id === activeList?.id;
            const done = list.items.filter(i => i.completed).length;
            const total = list.items.length;

            return (
              <button
                key={list.id}
                onClick={() => setSelectedListId(list.id)}
                className={`w-full p-4 rounded-2xl border text-left transition-all duration-150 cursor-pointer ${
                  isSelected
                    ? 'bg-[#FAF0F2] border-[#8C3246] shadow-xs ring-1 ring-[#8C3246]/20'
                    : 'bg-white hover:bg-[#FAF6F0] border-[#EADBCE] text-[#5C4F51]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-white border border-[#EADBCE] shrink-0">
                    {getListIcon(list.category)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className={`text-sm font-bold truncate ${isSelected ? 'text-[#8C3246]' : 'text-[#2D2326]'}`}>
                      {list.title}
                    </h4>
                    <p className="text-[11px] text-[#786C6E] truncate">
                      {list.subtitle}
                    </p>
                    <div className="mt-2 flex items-center justify-between text-[11px]">
                      <span className="text-[#8C3246] font-semibold">
                        {done} / {total} Completed
                      </span>
                      {done === total && total > 0 && (
                        <span className="text-[#616D48] font-bold">✓ Ready</span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Col: Active Checklist Details */}
        {activeList && (
          <div className="lg:col-span-2 space-y-5">
            <div className="bg-white rounded-3xl border border-[#EADBCE] p-6 shadow-xs relative">
              <FloralCorner position="top-right" className="absolute top-2 right-2 w-20 h-20 text-[#8C3246]/15" />
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#EADBCE]/80">
                <div>
                  <div className="flex items-center gap-2">
                    {getListIcon(activeList.category)}
                    <h3 className="font-serif-cormorant text-2xl font-bold text-[#2D2326]">
                      {activeList.title}
                    </h3>
                  </div>
                  <p className="text-xs text-[#786C6E] mt-1">
                    {activeList.subtitle}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onResetChecklist(activeList.id);
                      playGentleChime('sparkle');
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#FAF6F0] hover:bg-[#EADBCE] text-xs font-semibold text-[#5C4F51] border border-[#EADBCE] transition-colors cursor-pointer"
                    title="Uncheck all items to start fresh"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset All</span>
                  </button>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="my-4">
                <div className="flex items-center justify-between text-xs text-[#5C4F51] mb-1.5">
                  <span className="font-semibold">{completedCount} of {totalCount} items completed</span>
                  <span className="font-bold text-[#8C3246]">{totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-[#FAF6F0] border border-[#EADBCE] overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#8C3246] to-[#616D48] transition-all duration-300"
                    style={{ width: `${totalCount > 0 ? (completedCount / totalCount) * 100 : 0}%` }}
                  />
                </div>
              </div>

              {/* Add New Checklist Item Form */}
              <form onSubmit={handleAddNewItem} className="flex gap-2 my-4">
                <input
                  type="text"
                  placeholder="Add custom item to this routine..."
                  value={newItemText}
                  onChange={(e) => setNewItemText(e.target.value)}
                  className="flex-1 px-4 py-2 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#616D48] hover:bg-[#4E5839] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  Add Item
                </button>
              </form>

              {/* Checklist Items */}
              <div className="space-y-2.5 pt-2">
                {activeList.items.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-2xl border transition-all duration-150 flex items-center justify-between gap-3 ${
                      item.completed
                        ? 'bg-[#F4F7F2] border-[#616D48]/30 opacity-80'
                        : 'bg-[#FAF6F0]/50 border-[#EADBCE] hover:border-[#DDA5A5]'
                    }`}
                  >
                    <div 
                      onClick={() => {
                        onToggleItem(activeList.id, item.id);
                        if (!item.completed) {
                          playGentleChime('success');
                          if (completedCount + 1 === totalCount) {
                            confetti({ particleCount: 50, spread: 70 });
                          }
                        }
                      }}
                      className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                    >
                      {item.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-[#616D48] fill-[#EDF2E8] shrink-0" />
                      ) : (
                        <Circle className="w-5 h-5 text-[#DDA5A5] shrink-0" />
                      )}
                      <div>
                        <span className={`text-xs sm:text-sm font-medium ${item.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'}`}>
                          {item.text}
                        </span>
                        {item.note && (
                          <p className="text-[11px] text-[#C28255] italic">
                            {item.note}
                          </p>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => onDeleteItem(activeList.id, item.id)}
                      className="text-[#9B8F91] hover:text-rose-600 transition-colors p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
