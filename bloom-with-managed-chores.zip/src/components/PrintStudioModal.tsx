import React, { useState } from 'react';
import { 
  Printer, 
  X, 
  Check, 
  Download, 
  Sliders, 
  Sparkles, 
  Palette, 
  FileText, 
  Maximize2,
  Calendar,
  Layers
} from 'lucide-react';
import { TaskItem, HabitItem, RepeatChecklist, Goal90Day, PrintSettings, DayOfWeek, HomeChore, StudySession } from '../types/planner';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';
import { FLORAL_QUOTES } from '../data/plannerData';

interface PrintStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: TaskItem[];
  habits: HabitItem[];
  checklists: RepeatChecklist[];
  goals: Goal90Day[];
  chores?: HomeChore[];
  studySessions?: StudySession[];
}

export function PrintStudioModal({
  isOpen,
  onClose,
  tasks,
  habits,
  checklists,
  goals,
  chores = [],
  studySessions = [],
}: PrintStudioModalProps) {
  const [settings, setSettings] = useState<PrintSettings>({
    template: 'weekly-spread',
    theme: 'rose-sage',
    pageSize: 'letter',
    showFloralBorders: true,
    showInspirationalQuote: true,
    notesLinesCount: 6,
  });

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const DAYS: { id: DayOfWeek; name: string; dateLabel: string }[] = [
    { id: 'mon', name: 'Monday', dateLabel: 'Oct 19' },
    { id: 'tue', name: 'Tuesday', dateLabel: 'Oct 20' },
    { id: 'wed', name: 'Wednesday', dateLabel: 'Oct 21' },
    { id: 'thu', name: 'Thursday', dateLabel: 'Oct 22' },
    { id: 'fri', name: 'Friday', dateLabel: 'Oct 23' },
    { id: 'sat', name: 'Saturday', dateLabel: 'Oct 24' },
    { id: 'sun', name: 'Sunday', dateLabel: 'Oct 25' },
  ];

  // Theme styling helpers
  const themeClasses = {
    'rose-sage': {
      bg: 'bg-[#FFFDFB]',
      border: 'border-[#8C3246]',
      textPrimary: 'text-[#2D2326]',
      accentBg: 'bg-[#FAF0F2]',
      accentBorder: 'border-[#DDA5A5]',
      accentText: 'text-[#8C3246]',
      leafColor: 'text-[#616D48]',
      highlight: '#8C3246',
    },
    'monochrome-ink': {
      bg: 'bg-white',
      border: 'border-black',
      textPrimary: 'text-black',
      accentBg: 'bg-stone-100',
      accentBorder: 'border-stone-400',
      accentText: 'text-black',
      leafColor: 'text-stone-700',
      highlight: '#000000',
    },
    'vintage-wheat': {
      bg: 'bg-[#FAF5EF]',
      border: 'border-[#C28255]',
      textPrimary: 'text-[#3E2F23]',
      accentBg: 'bg-[#F2E9DE]',
      accentBorder: 'border-[#D8C3A5]',
      accentText: 'text-[#A05C2E]',
      leafColor: 'text-[#7D885C]',
      highlight: '#A05C2E',
    },
  }[settings.theme];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      
      {/* Container Card (Hidden on actual window.print thanks to CSS print targets) */}
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[96vh] flex flex-col shadow-2xl border border-[#EADBCE] overflow-hidden no-print">
        
        {/* Header Bar */}
        <div className="px-6 py-4 bg-[#FAF6F0] border-b border-[#EADBCE] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#8C3246] text-white flex items-center justify-center">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-serif-cormorant font-bold text-[#2D2326]">
                Print Studio &amp; Stationery Generator
              </h2>
              <p className="text-xs text-[#786C6E]">
                High-resolution printable planners styled with artwork botanicals
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="px-5 py-2.5 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs sm:text-sm font-semibold shadow-sm transition-all duration-150 flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>Print Now / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-[#786C6E] hover:bg-[#EADBCE]/50 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Studio Body: Left Settings Sidebar / Right Live Printable Paper Preview */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-4 p-4 sm:p-6 gap-6">
          
          {/* Settings Panel */}
          <div className="space-y-5 bg-[#FAF6F0] p-5 rounded-2xl border border-[#EADBCE]">
            <div>
              <h3 className="font-serif-cormorant text-base font-bold text-[#2D2326] mb-2 flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#8C3246]" />
                Template Format
              </h3>
              <div className="space-y-2">
                {[
                  { id: 'weekly-spread', label: '7-Day Botanical Spread' },
                  { id: 'daily-focus', label: 'Daily Focus & Hourly Blocks' },
                  { id: 'home-chores', label: 'Home Chores & Space Reset' },
                  { id: 'study-schedule', label: 'Study Timetable & Recall' },
                  { id: 'master-checklist', label: 'Repeat Checklists & Reset' },
                  { id: 'matrix-goals', label: 'Eisenhower Matrix & Goals' },
                  { id: 'shutdown-sheet', label: '10-Min Evening Shutdown Card' },
                ].map(tmpl => (
                  <button
                    key={tmpl.id}
                    onClick={() => setSettings(prev => ({ ...prev, template: tmpl.id as PrintSettings['template'] }))}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                      settings.template === tmpl.id
                        ? 'bg-[#8C3246] text-white font-semibold shadow-xs'
                        : 'bg-white text-[#5C4F51] hover:bg-[#FAF0F2] border border-[#EADBCE]'
                    }`}
                  >
                    {tmpl.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Aesthetic Theme */}
            <div>
              <h3 className="font-serif-cormorant text-base font-bold text-[#2D2326] mb-2 flex items-center gap-2">
                <Palette className="w-4 h-4 text-[#8C3246]" />
                Color Theme
              </h3>
              <div className="space-y-2">
                {[
                  { id: 'rose-sage', label: 'Rose & Sage (Artwork Palette)', color: '#8C3246' },
                  { id: 'monochrome-ink', label: 'Monochrome Ink-Saver (B&W)', color: '#000000' },
                  { id: 'vintage-wheat', label: 'Vintage Wheat & Linen', color: '#C28255' },
                ].map(thm => (
                  <button
                    key={thm.id}
                    onClick={() => setSettings(prev => ({ ...prev, theme: thm.id as PrintSettings['theme'] }))}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                      settings.theme === thm.id
                        ? 'bg-white border-2 border-[#8C3246] text-[#2D2326] font-bold shadow-xs'
                        : 'bg-white/60 text-[#5C4F51] border border-[#EADBCE]'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: thm.color }} />
                      <span>{thm.label}</span>
                    </div>
                    {settings.theme === thm.id && <Check className="w-3.5 h-3.5 text-[#8C3246]" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Paper Size */}
            <div>
              <h3 className="font-serif-cormorant text-base font-bold text-[#2D2326] mb-2">
                Paper Size
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'letter', label: 'US Letter (8.5×11")' },
                  { id: 'a4', label: 'A4 Standard' },
                ].map(size => (
                  <button
                    key={size.id}
                    onClick={() => setSettings(prev => ({ ...prev, pageSize: size.id as PrintSettings['pageSize'] }))}
                    className={`px-3 py-2 rounded-xl text-xs font-medium text-center transition-all cursor-pointer ${
                      settings.pageSize === size.id
                        ? 'bg-[#616D48] text-white font-semibold'
                        : 'bg-white text-[#5C4F51] border border-[#EADBCE]'
                    }`}
                  >
                    {size.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Ornaments & Details */}
            <div className="space-y-2 pt-2 border-t border-[#EADBCE]">
              <label className="flex items-center gap-2 text-xs text-[#2D2326] font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showFloralBorders}
                  onChange={(e) => setSettings(prev => ({ ...prev, showFloralBorders: e.target.checked }))}
                  className="rounded text-[#8C3246] focus:ring-[#8C3246]"
                />
                <span>Include Floral Corner Flourishes</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-[#2D2326] font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showInspirationalQuote}
                  onChange={(e) => setSettings(prev => ({ ...prev, showInspirationalQuote: e.target.checked }))}
                  className="rounded text-[#8C3246] focus:ring-[#8C3246]"
                />
                <span>Include Mindful Living Quote</span>
              </label>
            </div>
          </div>

          {/* Right Live Paper Preview */}
          <div className="lg:col-span-3 bg-stone-200/70 p-4 sm:p-6 rounded-2xl flex items-center justify-center overflow-auto">
            
            {/* The Actual Sheet Paper */}
            <div 
              id="printable-sheet"
              className={`w-full max-w-4xl p-8 rounded-2xl shadow-xl transition-all duration-200 relative border ${themeClasses.bg} ${themeClasses.border} ${themeClasses.textPrimary}`}
              style={{ minHeight: '680px' }}
            >
              {settings.showFloralBorders && (
                <>
                  <FloralCorner position="top-left" className={`absolute top-3 left-3 w-16 h-16 ${themeClasses.accentText}`} />
                  <FloralCorner position="top-right" className={`absolute top-3 right-3 w-16 h-16 ${themeClasses.accentText}`} />
                  <FloralCorner position="bottom-left" className={`absolute bottom-3 left-3 w-16 h-16 ${themeClasses.accentText}`} />
                  <FloralCorner position="bottom-right" className={`absolute bottom-3 right-3 w-16 h-16 ${themeClasses.accentText}`} />
                </>
              )}

              {/* Template 1: Botanical 7-Day Weekly Spread */}
              {settings.template === 'weekly-spread' && (
                <div className="space-y-6">
                  {/* Header Title */}
                  <div className="text-center pb-4 border-b border-current/20">
                    <span className="text-[11px] uppercase tracking-widest font-semibold opacity-75">
                      Mindful Weekly Architecture • 60-70% Capacity Margin
                    </span>
                    <h1 className="font-serif-cormorant text-3xl sm:text-4xl font-bold tracking-tight mt-1">
                      Weekly Focus &amp; Natural Order
                    </h1>
                    <p className="text-xs italic opacity-80 mt-1">
                      Week of: ____________________________________ • Priority Focus: ____________________________________
                    </p>
                  </div>

                  {/* 7 Days Columns Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-xs">
                    {DAYS.map(day => {
                      const dayTasks = tasks.filter(t => t.dayOfWeek === day.id);
                      const top3 = dayTasks.filter(t => t.category === 'top3').slice(0, 3);
                      const secondary = dayTasks.filter(t => t.category !== 'top3').slice(0, 3);

                      return (
                        <div key={day.id} className={`p-3 rounded-xl border ${themeClasses.accentBorder} flex flex-col justify-between`} style={{ minHeight: '260px' }}>
                          <div>
                            <div className="text-center pb-1.5 border-b border-current/15 mb-2">
                              <span className="font-bold uppercase tracking-wider block text-[11px]">
                                {day.name}
                              </span>
                              <span className="text-[10px] opacity-70">
                                {day.dateLabel}
                              </span>
                            </div>

                            {/* Top 3 Box */}
                            <div className="mb-2">
                              <span className="text-[9px] font-bold uppercase tracking-wider block opacity-75 mb-1">
                                Top 3 Focus
                              </span>
                              {[0, 1, 2].map(idx => (
                                <div key={idx} className="flex items-center gap-1.5 py-0.5 border-b border-dashed border-current/15">
                                  <span className="w-3 h-3 rounded-full border border-current/40 inline-block shrink-0" />
                                  <span className="text-[10px] truncate">
                                    {top3[idx]?.title || '___________________'}
                                  </span>
                                </div>
                              ))}
                            </div>

                            {/* Secondary tasks */}
                            <div>
                              <span className="text-[9px] font-bold uppercase tracking-wider block opacity-75 mb-1">
                                Flow &amp; Tasks
                              </span>
                              {[0, 1, 2].map(idx => (
                                <div key={idx} className="flex items-center gap-1.5 py-0.5 border-b border-dashed border-current/10">
                                  <span className="w-2.5 h-2.5 rounded-sm border border-current/40 inline-block shrink-0" />
                                  <span className="text-[10px] truncate opacity-85">
                                    {secondary[idx]?.title || '___________________'}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Evening Habit checkmark */}
                          <div className="pt-2 border-t border-current/10 flex items-center justify-between text-[9px] opacity-75">
                            <span>10m Shutdown:</span>
                            <span className="w-2.5 h-2.5 border border-current rounded-xs" />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Habit Tracker Row */}
                  <div className={`p-3 rounded-xl border ${themeClasses.accentBorder} ${themeClasses.accentBg}`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-serif-cormorant font-bold uppercase tracking-wider">
                        Weekly Habit Discipline Grid
                      </span>
                      <span className="text-[10px] italic opacity-80">
                        "Start tiny. Attach new habits to old routines."
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                      {habits.slice(0, 4).map(habit => (
                        <div key={habit.id} className="p-2 rounded-lg bg-white/70 border border-current/10 flex items-center justify-between">
                          <span className="truncate text-[11px] font-medium">{habit.name}</span>
                          <div className="flex gap-1">
                            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((letter, i) => (
                              <span key={i} className="w-3.5 h-3.5 rounded-xs border border-current/30 text-[8px] flex items-center justify-center font-bold">
                                {letter}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Quote footer */}
                  {settings.showInspirationalQuote && (
                    <div className="text-center pt-2 text-xs italic opacity-85 font-serif-cormorant">
                      "{FLORAL_QUOTES[0].quote}" — {FLORAL_QUOTES[0].author}
                    </div>
                  )}
                </div>
              )}

              {/* Template 2: Daily Focus & Hourly Blocks Sheet */}
              {settings.template === 'daily-focus' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b border-current/20">
                    <span className="text-[11px] uppercase tracking-widest font-semibold opacity-75">
                      Single-Task Focus &amp; Hourly Architecture
                    </span>
                    <h1 className="font-serif-cormorant text-3xl sm:text-4xl font-bold tracking-tight mt-1">
                      Daily Focus &amp; Energy Blueprint
                    </h1>
                    <p className="text-xs italic opacity-80 mt-1">
                      Date: ________________________ • Most Important Priority: ____________________________________
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Hourly Blocks Schedule */}
                    <div className="space-y-2">
                      <h3 className="font-serif-cormorant text-base font-bold uppercase tracking-wider pb-1 border-b border-current/20">
                        The Sample Day Hourly Blocks
                      </h3>
                      {[
                        { time: '08:30 - 10:00', label: 'Morning Deep Block 1 (Phone in another room)' },
                        { time: '10:00 - 10:15', label: '15-Min Break & Tea Ritual' },
                        { time: '10:15 - 11:30', label: 'Mid-Morning Focus Block 2' },
                        { time: '11:30 - 12:30', label: 'Midday Admin, Emails & 2-Min Triage Batch' },
                        { time: '12:30 - 13:30', label: 'Lunch & Fresh Air Rest' },
                        { time: '13:30 - 15:30', label: 'Afternoon Creative Block 3' },
                        { time: '15:30 - 16:45', label: 'Flexible Buffer Margin (30% Breathing Room)' },
                        { time: '16:45 - 17:00', label: 'Evening 10-Minute Shutdown Ritual' },
                      ].map((slot, idx) => (
                        <div key={idx} className="p-2 rounded-lg border border-dashed border-current/20 flex items-center justify-between text-xs">
                          <span className="font-mono font-bold text-[11px] opacity-80">{slot.time}</span>
                          <span className="text-[11px] font-medium">{slot.label}</span>
                        </div>
                      ))}
                    </div>

                    {/* Pre-Block Defense & Parking Lot */}
                    <div className="space-y-4">
                      <div className={`p-4 rounded-xl border ${themeClasses.accentBorder} ${themeClasses.accentBg}`}>
                        <h4 className="font-serif-cormorant text-sm font-bold uppercase tracking-wider mb-2">
                          Start Ritual Defense Checklist
                        </h4>
                        <div className="space-y-1.5 text-xs">
                          {[
                            'Water glass or hot tea placed on desk',
                            'Physical desk cleared of all random paper',
                            'Phone silenced and moved to another room',
                            'Single browser tab open for this exact task',
                            'Timer set to 25 or 50 minutes (no multitasking)',
                          ].map((item, idx) => (
                            <div key={idx} className="flex items-center gap-2">
                              <span className="w-3.5 h-3.5 border border-current rounded-xs inline-block" />
                              <span className="text-[11px]">{item}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Parking Lot Area */}
                      <div className="p-4 rounded-xl border border-current/20">
                        <h4 className="font-serif-cormorant text-sm font-bold uppercase tracking-wider mb-1">
                          Mid-Focus "Parking Lot" Lines
                        </h4>
                        <p className="text-[10px] opacity-75 mb-3 italic">
                          Write stray thoughts here instantly so your mind lets go.
                        </p>
                        {[1, 2, 3, 4, 5].map(line => (
                          <div key={line} className="h-6 border-b border-dashed border-current/20" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Template 3: Master Repeat Checklists */}
              {settings.template === 'master-checklist' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b border-current/20">
                    <span className="text-[11px] uppercase tracking-widest font-semibold opacity-75">
                      Never Rebuild From Memory
                    </span>
                    <h1 className="font-serif-cormorant text-3xl sm:text-4xl font-bold tracking-tight mt-1">
                      Master Repeat Routine Checklists
                    </h1>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {checklists.slice(0, 4).map(list => (
                      <div key={list.id} className={`p-4 rounded-xl border ${themeClasses.accentBorder} text-xs`}>
                        <h4 className="font-serif-cormorant text-base font-bold pb-1 border-b border-current/15 mb-2">
                          {list.title}
                        </h4>
                        <div className="space-y-1.5">
                          {list.items.map(item => (
                            <div key={item.id} className="flex items-start gap-2">
                              <span className="w-3.5 h-3.5 border border-current rounded-xs mt-0.5 shrink-0" />
                              <span className="text-[11px] leading-tight">{item.text}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Template 4: Eisenhower Matrix & 90-Day Goals */}
              {settings.template === 'matrix-goals' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b border-current/20">
                    <span className="text-[11px] uppercase tracking-widest font-semibold opacity-75">
                      Eisenhower Prioritization &amp; Quarterly Horizons
                    </span>
                    <h1 className="font-serif-cormorant text-3xl sm:text-4xl font-bold tracking-tight mt-1">
                      Urgent vs. Important Goal Matrix
                    </h1>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs" style={{ minHeight: '340px' }}>
                    <div className="p-4 rounded-xl border-2 border-current/30">
                      <span className="font-serif-cormorant text-sm font-bold block uppercase tracking-wider mb-2">
                        1. Urgent &amp; Important (Do First)
                      </span>
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className="h-7 border-b border-dashed border-current/20" />
                      ))}
                    </div>

                    <div className={`p-4 rounded-xl border-2 ${themeClasses.accentBorder} ${themeClasses.accentBg}`}>
                      <span className="font-serif-cormorant text-sm font-bold block uppercase tracking-wider mb-2">
                        ★ 2. Important, Not Urgent (Moves Goals)
                      </span>
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className="h-7 border-b border-dashed border-current/20" />
                      ))}
                    </div>

                    <div className="p-4 rounded-xl border border-current/30">
                      <span className="font-serif-cormorant text-sm font-bold block uppercase tracking-wider mb-2">
                        3. Urgent, Not Important (Delegate / Batch)
                      </span>
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className="h-7 border-b border-dashed border-current/20" />
                      ))}
                    </div>

                    <div className="p-4 rounded-xl border border-current/30">
                      <span className="font-serif-cormorant text-sm font-bold block uppercase tracking-wider mb-2">
                        4. Not Urgent &amp; Not Important (Eliminate)
                      </span>
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className="h-7 border-b border-dashed border-current/20" />
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Template 5: Evening Shutdown Card */}
              {settings.template === 'shutdown-sheet' && (
                <div className="space-y-6 max-w-xl mx-auto">
                  <div className="text-center pb-4 border-b border-current/20">
                    <span className="text-[11px] uppercase tracking-widest font-semibold opacity-75">
                      10-Minute Evening Habit
                    </span>
                    <h1 className="font-serif-cormorant text-3xl sm:text-4xl font-bold tracking-tight mt-1">
                      Nightly Shutdown &amp; Tomorrow's Top 3
                    </h1>
                  </div>

                  <div className={`p-5 rounded-2xl border ${themeClasses.accentBorder} ${themeClasses.accentBg} space-y-3 text-xs`}>
                    <h3 className="font-serif-cormorant text-base font-bold uppercase tracking-wider">
                      The 5 Shutdown Steps
                    </h3>
                    {[
                      '1. Celebrate Today\'s Done List (Review what moved forward)',
                      '2. Close or Roll Over Unfinished Loops to upcoming days',
                      '3. Choose Tomorrow\'s Top 3 Priorities (1 High Impact + 2 Supporting)',
                      '4. 15-Minute Space Reset: Tidy desk, stow pens, wipe surface',
                      '5. Verbal Closure: "Day complete. Tomorrow is planned and protected."',
                    ].map((step, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <span className="w-4 h-4 border border-current rounded-xs inline-block shrink-0" />
                        <span className="font-medium">{step}</span>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 rounded-2xl border border-current/30 space-y-2">
                    <span className="font-serif-cormorant text-sm font-bold uppercase tracking-wider block">
                      Tomorrow's Top 3 Priority Lines
                    </span>
                    {[1, 2, 3].map(i => (
                      <div key={i} className="flex items-center gap-2 py-1 border-b border-dashed border-current/20 text-xs">
                        <span className="font-bold opacity-80">#{i}</span>
                        <div className="flex-1 h-5" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Template 6: Home Chores & Space Reset */}
              {settings.template === 'home-chores' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b border-current/20">
                    <span className="text-[11px] uppercase tracking-widest font-semibold opacity-75">
                      Sanctuary Architecture &amp; 15-Minute Resets
                    </span>
                    <h1 className="font-serif-cormorant text-3xl sm:text-4xl font-bold tracking-tight mt-1">
                      Home Chores &amp; Space Order Matrix
                    </h1>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Daily Resets */}
                    <div className={`p-4 rounded-xl border ${themeClasses.accentBorder} ${themeClasses.accentBg} text-xs`}>
                      <h4 className="font-serif-cormorant text-base font-bold pb-1 border-b border-current/20 mb-2 flex items-center justify-between">
                        <span>Daily Evening Space Resets</span>
                        <span className="text-[10px] font-mono">15m Max</span>
                      </h4>
                      <div className="space-y-2">
                        {chores.filter(c => c.frequency === 'daily').slice(0, 6).map(c => (
                          <div key={c.id} className="flex items-start gap-2">
                            <span className="w-3.5 h-3.5 border border-current rounded-xs mt-0.5 shrink-0" />
                            <div className="min-w-0">
                              <span className="text-[11px] font-medium block leading-tight">{c.title}</span>
                              <span className="text-[10px] opacity-75">{c.roomZone} • {c.estimatedMinutes}m</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Weekly & Monthly Cleans */}
                    <div className={`p-4 rounded-xl border ${themeClasses.accentBorder} text-xs`}>
                      <h4 className="font-serif-cormorant text-base font-bold pb-1 border-b border-current/20 mb-2 flex items-center justify-between">
                        <span>Weekly Rhythm &amp; Monthly Declutter</span>
                        <span className="text-[10px] font-mono">Zone Cadence</span>
                      </h4>
                      <div className="space-y-2">
                        {chores.filter(c => c.frequency === 'weekly' || c.frequency === 'monthly').slice(0, 6).map(c => (
                          <div key={c.id} className="flex items-start gap-2">
                            <span className="w-3.5 h-3.5 border border-current rounded-xs mt-0.5 shrink-0" />
                            <div className="min-w-0">
                              <span className="text-[11px] font-medium block leading-tight">{c.title}</span>
                              <span className="text-[10px] opacity-75">{c.roomZone} • {c.frequency}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Empty Fill-in lines */}
                  <div className="p-4 rounded-xl border border-current/30 text-xs">
                    <span className="font-serif-cormorant text-sm font-bold uppercase tracking-wider block mb-2">
                      Weekly Zone Reset Notes &amp; Donated Items Log
                    </span>
                    {[1, 2, 3].map(i => (
                      <div key={i} className="h-6 border-b border-dashed border-current/20" />
                    ))}
                  </div>
                </div>
              )}

              {/* Template 7: Study Schedules & Recall */}
              {settings.template === 'study-schedule' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b border-current/20">
                    <span className="text-[11px] uppercase tracking-widest font-semibold opacity-75">
                      Curriculum &amp; Spaced Repetition Protocol
                    </span>
                    <h1 className="font-serif-cormorant text-3xl sm:text-4xl font-bold tracking-tight mt-1">
                      Academic Study Timetable &amp; Recall
                    </h1>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {studySessions.slice(0, 6).map(s => (
                      <div key={s.id} className={`p-4 rounded-xl border ${themeClasses.accentBorder} text-xs`}>
                        <div className="flex items-center justify-between border-b border-current/20 pb-1 mb-2">
                          <span className="font-bold text-[10px] uppercase tracking-wider">{s.subject}</span>
                          <span className="text-[10px] font-mono">{s.durationMinutes}m Pomodoro</span>
                        </div>
                        <h4 className="font-serif-cormorant text-sm font-bold mb-1">
                          {s.topic}
                        </h4>
                        <div className="flex items-center gap-2 text-[10px] opacity-80 mb-2">
                          <span>Stage: {s.spacedRepetitionStage || 'First Learning'}</span>
                          {s.targetExamDate && <span>• Exam: {s.targetExamDate}</span>}
                        </div>
                        <div className="flex items-center gap-2 pt-1 border-t border-dashed border-current/20">
                          <span className="w-3.5 h-3.5 border border-current rounded-xs shrink-0" />
                          <span className="text-[10px] italic">Active recall test passed without notes</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Blank Study Blocks */}
                  <div className={`p-4 rounded-xl border-2 ${themeClasses.accentBorder} ${themeClasses.accentBg} text-xs`}>
                    <span className="font-serif-cormorant text-sm font-bold uppercase tracking-wider block mb-2">
                      Upcoming Active Recall Self-Quizzes
                    </span>
                    {[1, 2, 3].map(i => (
                      <div key={i} className="flex items-center gap-2 py-1.5 border-b border-dashed border-current/20">
                        <span className="w-3.5 h-3.5 border border-current rounded-xs shrink-0" />
                        <div className="flex-1 h-4" />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
