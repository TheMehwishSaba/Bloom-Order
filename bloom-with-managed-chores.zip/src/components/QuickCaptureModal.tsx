import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Sparkles, 
  Zap, 
  Calendar, 
  Tag, 
  Clock, 
  UserCheck 
} from 'lucide-react';
import { TaskItem, TaskCategory, PriorityQuadrant, DayOfWeek } from '../types/planner';
import { suggestNextPhysicalAction } from '../utils/plannerLogic';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, PeonyIcon } from './FloralAccents';

interface QuickCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTask: (task: Partial<TaskItem>) => void;
}

export function QuickCaptureModal({
  isOpen,
  onClose,
  onAddTask,
}: QuickCaptureModalProps) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<TaskCategory>('top3');
  const [dayOfWeek, setDayOfWeek] = useState<DayOfWeek>('mon');
  const [priority, setPriority] = useState<PriorityQuadrant>('important-not-urgent');
  const [delegatedTo, setDelegatedTo] = useState('');
  const [suggestedAction, setSuggestedAction] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        // Toggle modal
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setTitle(val);
    setSuggestedAction(suggestNextPhysicalAction(val));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddTask({
      title: title.trim(),
      category,
      dayOfWeek,
      priority,
      nextPhysicalAction: suggestedAction.trim() || undefined,
      delegatedTo: category === 'waiting-for' ? delegatedTo.trim() : undefined,
      estimatedMinutes: category === 'under-2-min' ? 2 : 45,
      completed: false,
      dateAdded: new Date().toISOString().split('T')[0],
    });

    setTitle('');
    setSuggestedAction('');
    setDelegatedTo('');
    playGentleChime('sparkle');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 no-print">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-[#EADBCE] relative overflow-hidden">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-16 h-16 text-[#8C3246]/15" />

        <div className="flex items-center justify-between pb-3 border-b border-[#EADBCE]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#FAF0F2] text-[#8C3246] flex items-center justify-center">
              <PeonyIcon className="w-4 h-4" />
            </div>
            <h3 className="font-serif-cormorant text-xl font-bold text-[#2D2326]">
              Instant Capture • Rule #1
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#786C6E] hover:bg-[#FAF0F2]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[#786C6E] mt-2 mb-4">
          "If a task lives only in your head, you will forget it. Capture everything in one place."
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#2D2326] mb-1">
              Task or Open Loop
            </label>
            <input
              type="text"
              autoFocus
              placeholder="e.g. Call dentist to reschedule appointment..."
              value={title}
              onChange={handleTitleChange}
              className="w-full px-4 py-2.5 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
            />
          </div>

          {/* Next Physical Action Suggestion */}
          {suggestedAction && (
            <div className="p-2.5 rounded-xl bg-[#EDF2E8] border border-[#616D48]/30 text-xs text-[#4B5634] flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 truncate">
                <Zap className="w-3.5 h-3.5 text-[#8C3246] shrink-0" />
                <span className="font-semibold">Next physical action:</span>
                <span className="italic truncate">{suggestedAction}</span>
              </div>
              <button
                type="button"
                onClick={() => setTitle(suggestedAction)}
                className="text-[10px] uppercase font-bold text-[#8C3246] underline hover:text-[#2D2326] shrink-0 cursor-pointer"
              >
                Apply
              </button>
            </div>
          )}

          {/* Category Selector */}
          <div>
            <label className="block text-[11px] font-bold text-[#786C6E] uppercase mb-1">
              List Category
            </label>
            <div className="grid grid-cols-3 gap-1.5 text-xs">
              {[
                { id: 'top3', label: '★ Top 3 Daily' },
                { id: 'inbox', label: 'Master Inbox' },
                { id: 'under-2-min', label: '< 2-Min Win' },
                { id: 'waiting-for', label: 'Waiting For' },
                { id: 'parking-lot', label: 'Parking Lot' },
                { id: 'not-to-do', label: 'Not-To-Do' },
              ].map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id as TaskCategory)}
                  className={`p-2 rounded-xl text-center font-medium transition-all cursor-pointer ${
                    category === cat.id
                      ? 'bg-[#8C3246] text-white font-bold'
                      : 'bg-[#FAF6F0] text-[#5C4F51] hover:bg-[#FAF0F2] border border-[#EADBCE]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Day & Priority Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-[#786C6E] uppercase mb-1">
                Day of Week
              </label>
              <select
                value={dayOfWeek}
                onChange={(e) => setDayOfWeek(e.target.value as DayOfWeek)}
                className="w-full px-3 py-2 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
              >
                <option value="mon">Monday</option>
                <option value="tue">Tuesday</option>
                <option value="wed">Wednesday</option>
                <option value="thu">Thursday</option>
                <option value="fri">Friday</option>
                <option value="sat">Saturday</option>
                <option value="sun">Sunday</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-[#786C6E] uppercase mb-1">
                Eisenhower Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as PriorityQuadrant)}
                className="w-full px-3 py-2 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
              >
                <option value="important-not-urgent">Important (Moves Goals)</option>
                <option value="urgent-important">Urgent &amp; Important</option>
                <option value="urgent-not-important">Urgent, Not Important</option>
                <option value="not-urgent-not-important">Not-To-Do / Eliminate</option>
              </select>
            </div>
          </div>

          {category === 'waiting-for' && (
            <div>
              <label className="block text-[11px] font-bold text-[#786C6E] uppercase mb-1">
                Waiting on Person / Vendor
              </label>
              <input
                type="text"
                placeholder="e.g. Ali (Accountant), Dr. Smith..."
                value={delegatedTo}
                onChange={(e) => setDelegatedTo(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
              />
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-[#EADBCE]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-[#786C6E] hover:text-[#2D2326]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs font-semibold shadow-xs transition-all cursor-pointer"
            >
              Save &amp; Close Loop
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
