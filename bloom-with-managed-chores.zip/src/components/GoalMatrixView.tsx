import React, { useState } from 'react';
import { 
  Target, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Circle, 
  Scissors, 
  Calendar, 
  Award, 
  Plus, 
  Flame,
  ArrowRight,
  TrendingUp,
  ShieldCheck
} from 'lucide-react';
import { TaskItem, Goal90Day, HabitItem, PriorityQuadrant } from '../types/planner';
import { groupTasksByEisenhower } from '../utils/plannerLogic';
import { playGentleChime } from '../utils/audioChime';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';

interface GoalMatrixViewProps {
  tasks: TaskItem[];
  goals: Goal90Day[];
  habits: HabitItem[];
  onToggleTask: (taskId: string) => void;
  onToggleGoalMilestone: (goalId: string, milestoneId: string) => void;
  onAddGoal: (goal: Partial<Goal90Day>) => void;
  onOpenPrintStudio: () => void;
}

export function GoalMatrixView({
  tasks,
  goals,
  habits,
  onToggleTask,
  onToggleGoalMilestone,
  onAddGoal,
  onOpenPrintStudio,
}: GoalMatrixViewProps) {
  const [activeTab, setActiveTab] = useState<'matrix' | 'goals' | 'habits'>('matrix');
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newCutCommitment, setNewCutCommitment] = useState('');

  const matrixGroups = groupTasksByEisenhower(tasks);

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalTitle.trim()) return;

    onAddGoal({
      title: newGoalTitle.trim(),
      targetQuarter: 'Q4 2026',
      whyItMatters: 'Intentional life architecture and deep focus impact.',
      cutCommitment: newCutCommitment.trim() || 'Cut low-impact evening internet browsing.',
      keyResults: [
        { id: `kr-${Date.now()}-1`, text: 'Define 3 milestone stages', completed: false },
        { id: `kr-${Date.now()}-2`, text: 'Schedule weekly 90-minute milestone review', completed: false },
      ],
    });

    setNewGoalTitle('');
    setNewCutCommitment('');
    playGentleChime('sparkle');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-[#FAF0F2] via-[#FAF6F0] to-[#EDF2E8] border border-[#EADBCE] p-5 sm:p-6 shadow-xs overflow-hidden">
        <FloralCorner position="top-right" className="absolute top-2 right-2 w-24 h-24 text-[#8C3246]/20" />
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C3246] flex items-center gap-1.5">
              <PeonyIcon className="w-4 h-4" />
              Strategic Alignment System
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif-cormorant font-bold text-[#2D2326] mt-1">
              Prioritize &amp; 90-Day Horizons
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-[#5C4F51] max-w-2xl">
              "Sort tasks by urgent versus important. Most progress comes from important but not urgent work, so schedule it first." Break 1-3 big goals into 90-day targets and cut what no longer serves them.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {[
              { id: 'matrix', label: 'Eisenhower 4-Box' },
              { id: 'goals', label: '90-Day Goals' },
              { id: 'habits', label: 'Habit Ladders' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-[#8C3246] text-white shadow-xs font-semibold'
                    : 'bg-white text-[#5C4F51] hover:bg-[#FAF0F2] border border-[#EADBCE]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tab 1: Eisenhower 4-Box Matrix */}
      {activeTab === 'matrix' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Box 1: Urgent & Important (Crises, Deadlines - Do First) */}
            <div className="bg-white rounded-3xl border-2 border-[#8C3246]/30 p-5 shadow-xs relative">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#8C3246]" />
                  <h3 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                    1. Urgent &amp; Important (Do First)
                  </h3>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#8C3246]/10 text-[#8C3246]">
                  {matrixGroups['urgent-important'].length} Items
                </span>
              </div>
              <p className="text-xs text-[#786C6E] mb-3">
                Pressing deadlines, urgent commitments. Complete these in your morning focus blocks.
              </p>

              <div className="space-y-2">
                {matrixGroups['urgent-important'].map(task => (
                  <div key={task.id} className="p-2.5 rounded-xl bg-[#FAF0F2]/60 border border-[#DDA5A5] flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <button onClick={() => onToggleTask(task.id)} className="cursor-pointer">
                        {task.completed ? <CheckCircle2 className="w-4 h-4 text-[#616D48]" /> : <Circle className="w-4 h-4 text-[#8C3246]" />}
                      </button>
                      <span className={`truncate font-medium ${task.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'}`}>
                        {task.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Box 2: Important, Not Urgent (The Gold Zone - Deep Work & Goals) */}
            <div className="bg-white rounded-3xl border-2 border-[#616D48]/40 p-5 shadow-xs relative ring-2 ring-[#616D48]/20">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#616D48]" />
                  <h3 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                    2. Important, Not Urgent (Moves Goals!)
                  </h3>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#EDF2E8] text-[#4B5634]">
                  {matrixGroups['important-not-urgent'].length} Items
                </span>
              </div>
              <p className="text-xs text-[#535E3B] font-medium mb-3">
                ★ Core Rule: Most life progress comes from this quadrant. Schedule it first!
              </p>

              <div className="space-y-2">
                {matrixGroups['important-not-urgent'].map(task => (
                  <div key={task.id} className="p-2.5 rounded-xl bg-[#EDF2E8]/60 border border-[#616D48]/30 flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <button onClick={() => onToggleTask(task.id)} className="cursor-pointer">
                        {task.completed ? <CheckCircle2 className="w-4 h-4 text-[#616D48]" /> : <Circle className="w-4 h-4 text-[#616D48]" />}
                      </button>
                      <span className={`truncate font-medium ${task.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'}`}>
                        {task.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Box 3: Urgent, Not Important (Delegate / Batch) */}
            <div className="bg-white rounded-3xl border border-[#EADBCE] p-5 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#C28255]" />
                  <h3 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                    3. Urgent, Not Important (Delegate / Batch)
                  </h3>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#C28255]/15 text-[#8F5529]">
                  {matrixGroups['urgent-not-important'].length} Items
                </span>
              </div>
              <p className="text-xs text-[#786C6E] mb-3">
                Interruptions, some messages, routine admin. Batch into midday 12:00 window.
              </p>

              <div className="space-y-2">
                {matrixGroups['urgent-not-important'].map(task => (
                  <div key={task.id} className="p-2.5 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <button onClick={() => onToggleTask(task.id)} className="cursor-pointer">
                        {task.completed ? <CheckCircle2 className="w-4 h-4 text-[#616D48]" /> : <Circle className="w-4 h-4 text-[#C28255]" />}
                      </button>
                      <span className={`truncate ${task.completed ? 'line-through text-[#786C6E]' : 'text-[#5C4F51]'}`}>
                        {task.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Box 4: Not Urgent, Not Important (Drop / Eliminate) */}
            <div className="bg-white rounded-3xl border border-[#EADBCE] p-5 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-stone-400" />
                  <h3 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                    4. Not Urgent &amp; Not Important (Eliminate)
                  </h3>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-200 text-stone-700">
                  {matrixGroups['not-urgent-not-important'].length} Items
                </span>
              </div>
              <p className="text-xs text-[#786C6E] mb-3">
                Ask: "Does this move a goal? What happens if I simply skip it?"
              </p>

              <div className="space-y-2">
                {matrixGroups['not-urgent-not-important'].map(task => (
                  <div key={task.id} className="p-2.5 rounded-xl bg-stone-50 border border-stone-200 flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <button onClick={() => onToggleTask(task.id)} className="cursor-pointer">
                        {task.completed ? <CheckCircle2 className="w-4 h-4 text-stone-500" /> : <Circle className="w-4 h-4 text-stone-400" />}
                      </button>
                      <span className={`truncate ${task.completed ? 'line-through text-stone-400' : 'text-stone-600'}`}>
                        {task.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: 90-Day Goals & The Cut Commitment */}
      {activeTab === 'goals' && (
        <div className="space-y-5">
          {/* New Goal Form */}
          <div className="bg-white rounded-3xl border border-[#EADBCE] p-5 sm:p-6 shadow-xs">
            <h3 className="font-serif-cormorant text-xl font-bold text-[#2D2326] mb-3">
              Define 1-3 Big Goals (90-Day Horizon)
            </h3>
            <form onSubmit={handleCreateGoal} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                placeholder="Big 90-Day Target (e.g. Launch floral stationery shop)..."
                value={newGoalTitle}
                onChange={(e) => setNewGoalTitle(e.target.value)}
                className="sm:col-span-2 px-4 py-2.5 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
              />
              <input
                type="text"
                placeholder="What commitment will you CUT to protect it?..."
                value={newCutCommitment}
                onChange={(e) => setNewCutCommitment(e.target.value)}
                className="px-4 py-2.5 rounded-xl bg-[#FAF6F0] border border-[#EADBCE] text-xs sm:text-sm text-[#2D2326] focus:outline-none focus:border-[#8C3246]"
              />
              <div className="sm:col-span-3 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#8C3246] hover:bg-[#732738] text-white text-xs sm:text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  Save 90-Day Goal
                </button>
              </div>
            </form>
          </div>

          {/* Goal Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {goals.map(goal => (
              <div key={goal.id} className="bg-white rounded-3xl border border-[#EADBCE] p-6 shadow-xs relative">
                <FloralCorner position="top-right" className="absolute top-2 right-2 w-16 h-16 text-[#8C3246]/15" />
                
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#FAF0F2] text-[#8C3246] border border-[#DDA5A5]">
                    {goal.targetQuarter} Target
                  </span>
                </div>

                <h4 className="font-serif-cormorant text-xl font-bold text-[#2D2326]">
                  {goal.title}
                </h4>

                <p className="text-xs text-[#5C4F51] mt-1 leading-relaxed">
                  {goal.whyItMatters}
                </p>

                {/* The "Cut Commitment" Callout */}
                <div className="mt-4 p-3 rounded-2xl bg-[#FAF0F2] border border-[#DDA5A5]/60 flex items-start gap-2.5 text-xs">
                  <Scissors className="w-4 h-4 text-[#8C3246] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#8C3246]">Cut Commitment: </span>
                    <span className="text-[#5C4F51]">{goal.cutCommitment}</span>
                  </div>
                </div>

                {/* Key Results / Milestones */}
                <div className="mt-4 space-y-2 pt-3 border-t border-[#EADBCE]/80">
                  <span className="text-[11px] font-bold text-[#786C6E] uppercase">
                    Key Milestones
                  </span>
                  {goal.keyResults.map(kr => (
                    <div
                      key={kr.id}
                      onClick={() => onToggleGoalMilestone(goal.id, kr.id)}
                      className="flex items-center gap-2.5 p-2 rounded-xl bg-[#FAF6F0] hover:bg-[#EDF2E8] transition-colors cursor-pointer text-xs"
                    >
                      {kr.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-[#616D48]" />
                      ) : (
                        <Circle className="w-4 h-4 text-[#DDA5A5]" />
                      )}
                      <span className={kr.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326] font-medium'}>
                        {kr.text}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Habit Ladders & Streaks */}
      {activeTab === 'habits' && (
        <div className="bg-white rounded-3xl border border-[#EADBCE] p-6 shadow-xs">
          <div className="max-w-2xl mb-6">
            <h3 className="font-serif-cormorant text-2xl font-bold text-[#2D2326]">
              Habit Stacking &amp; Streak Ladders
            </h3>
            <p className="text-xs sm:text-sm text-[#786C6E] mt-1">
              "Start tiny. Attach new habits to old ones, such as planning right after your evening tea. If you miss a day, restart at the next block. Don't wait for Monday."
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {habits.map(habit => (
              <div key={habit.id} className="p-5 rounded-2xl bg-[#FAF6F0] border border-[#EADBCE] relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#8C3246]">
                    {habit.category} Routine
                  </span>
                  <div className="flex items-center gap-1 text-xs font-bold text-[#616D48]">
                    <Flame className="w-4 h-4 fill-current" />
                    <span>{habit.currentStreak} Day Streak</span>
                  </div>
                </div>

                <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                  {habit.name}
                </h4>

                <p className="text-xs text-[#5C4F51] mt-1">
                  {habit.description}
                </p>

                <div className="mt-4 pt-3 border-t border-[#EADBCE] flex items-center justify-between text-xs text-[#786C6E]">
                  <span>Best record: {habit.bestStreak} days</span>
                  <span className="text-[#8C3246] font-semibold">Active</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
