import React, { useState } from 'react';
import { 
  Package, 
  Truck, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  RotateCcw, 
  FileText, 
  Mail, 
  ChevronRight, 
  AlertCircle,
  X,
  Phone,
  Printer,
  Sparkles
} from 'lucide-react';
import { Order, OrderStatus, Product } from '../types/store';

interface OrderHistoryViewProps {
  orders: Order[];
  onReorder: (items: { product: Product; quantity: number }[]) => void;
  onViewEmail: (orderId: string) => void;
  onClose?: () => void;
}

export const OrderHistoryView: React.FC<OrderHistoryViewProps> = ({
  orders,
  onReorder,
  onViewEmail,
  onClose,
}) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(orders[0] || null);
  const [showInvoiceModal, setShowInvoiceModal] = useState<Order | null>(null);

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'order_confirmed':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 flex items-center gap-1">
            <Clock className="w-3 h-3" /> Confirmed
          </span>
        );
      case 'picked_packed':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 flex items-center gap-1">
            <Package className="w-3 h-3" /> Picked &amp; Packed
          </span>
        );
      case 'out_for_delivery':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 flex items-center gap-1 animate-pulse">
            <Truck className="w-3 h-3" /> Out for Delivery
          </span>
        );
      case 'delivered':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Delivered
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 flex items-center gap-1">
            <AlertCircle className="w-3 h-3" /> Cancelled
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fadeIn">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900">Your Order History &amp; Deliveries</h1>
            {onClose && (
              <button
                onClick={onClose}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-200/80 hover:bg-slate-300 text-slate-700 font-semibold"
              >
                Back to Store
              </button>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track real-time delivery status, view stage emails, and download receipts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800">
            {orders.length} Total Store Orders
          </div>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
          <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">No Orders Placed Yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
            Items you purchase with secure checkout will appear here with live tracking.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Orders Sidebar List */}
          <div className="lg:col-span-5 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Recent Grocery Orders
            </div>

            {orders.map((order) => {
              const isSelected = selectedOrder?.id === order.id;

              return (
                <div
                  key={order.id}
                  onClick={() => setSelectedOrder(order)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-white border-emerald-500 shadow-md ring-2 ring-emerald-100'
                      : 'bg-white/80 hover:bg-white border-slate-200/80 hover:border-slate-300'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-extrabold text-sm text-slate-900">
                        Order #{order.orderNumber}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {new Date(order.createdAt).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </div>
                    </div>
                    {getStatusBadge(order.status)}
                  </div>

                  <div className="text-xs text-slate-600 line-clamp-1 mb-2 font-medium">
                    {order.items.map((i) => `${i.quantity}x ${i.product.name}`).join(', ')}
                  </div>

                  <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-100">
                    <span className="font-extrabold text-slate-900">
                      ${order.total.toFixed(2)}
                    </span>
                    <span className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-500" /> +{order.pointsEarned} pts
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Order Details & Live Timeline Panel */}
          {selectedOrder && (
            <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
              
              {/* Order Header Card */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Order #{selectedOrder.orderNumber}
                    </h2>
                    {getStatusBadge(selectedOrder.status)}
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Placed on {new Date(selectedOrder.createdAt).toLocaleString()} · Paid via {selectedOrder.paymentMethod.brand}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onViewEmail(selectedOrder.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition"
                    title="View HTML email sent for this order"
                  >
                    <Mail className="w-3.5 h-3.5 text-emerald-600" />
                    <span>View Email</span>
                  </button>

                  <button
                    onClick={() => setShowInvoiceModal(selectedOrder)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition"
                    title="Print formal tax receipt"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Invoice</span>
                  </button>

                  <button
                    onClick={() => onReorder(selectedOrder.items)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition"
                    title="Add all items from this order to current cart"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reorder All</span>
                  </button>
                </div>
              </div>

              {/* Live Delivery Progress Tracker Pipeline */}
              <div className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200/80">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4 flex items-center justify-between">
                  <span>Delivery Stage Progress</span>
                  {selectedOrder.status === 'out_for_delivery' && (
                    <span className="text-amber-700 font-bold animate-pulse flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5" /> Driver Arriving in ~{selectedOrder.driver?.etaMinutes || 15} mins
                    </span>
                  )}
                </div>

                <div className="space-y-4">
                  {selectedOrder.timeline.map((event, idx) => (
                    <div key={idx} className="flex gap-3 relative">
                      {/* Timeline Connector Line */}
                      {idx < selectedOrder.timeline.length - 1 && (
                        <div 
                          className={`absolute left-3.5 top-7 bottom-0 w-0.5 ${
                            selectedOrder.timeline[idx + 1].completed ? 'bg-emerald-500' : 'bg-slate-200'
                          }`} 
                        />
                      )}

                      {/* Icon Circle */}
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 z-10 ${
                        event.completed 
                          ? 'bg-emerald-600 text-white shadow-sm' 
                          : 'bg-slate-200 text-slate-400'
                      }`}>
                        {event.completed ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : (
                          <span className="text-xs font-bold">{idx + 1}</span>
                        )}
                      </div>

                      {/* Event Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-baseline">
                          <h4 className={`text-xs font-bold ${event.completed ? 'text-slate-900' : 'text-slate-400'}`}>
                            {event.title}
                          </h4>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {event.timestamp}
                          </span>
                        </div>
                        <p className={`text-xs mt-0.5 ${event.completed ? 'text-slate-600' : 'text-slate-400'}`}>
                          {event.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Driver Courier Card if Out for Delivery */}
              {selectedOrder.driver && selectedOrder.status === 'out_for_delivery' && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={selectedOrder.driver.avatar}
                      alt={selectedOrder.driver.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm"
                    />
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider text-amber-800">
                        Assigned Courier
                      </div>
                      <h4 className="font-extrabold text-sm text-slate-900">
                        {selectedOrder.driver.name} (⭐ {selectedOrder.driver.rating})
                      </h4>
                      <p className="text-xs text-amber-900/80">
                        {selectedOrder.driver.vehicle} · {selectedOrder.driver.currentLocation}
                      </p>
                    </div>
                  </div>

                  <a
                    href={`tel:${selectedOrder.driver.phone}`}
                    className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-amber-100 text-amber-900 rounded-xl text-xs font-bold border border-amber-300 shadow-sm transition"
                  >
                    <Phone className="w-3.5 h-3.5 text-amber-700" />
                    <span>Call Courier</span>
                  </a>
                </div>
              )}

              {/* Proof of Delivery Photo if Delivered */}
              {selectedOrder.deliveryProofPhoto && selectedOrder.status === 'delivered' && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Proof of Doorstep Delivery
                    </span>
                    <span className="text-[11px] text-emerald-700 font-medium">Contactless Drop Verified</span>
                  </div>
                  <img
                    src={selectedOrder.deliveryProofPhoto}
                    alt="Delivery proof"
                    className="w-full h-40 object-cover rounded-xl border border-emerald-200"
                  />
                </div>
              )}

              {/* Order Items Breakdown */}
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Items in Basket ({selectedOrder.items.length})
                </div>

                <div className="divide-y divide-slate-100">
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="py-2.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                        />
                        <div className="truncate">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            {item.quantity}x {item.product.name}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {item.product.unit} · SKU: {item.product.sku}
                          </div>
                        </div>
                      </div>

                      <div className="text-xs font-bold text-slate-900 shrink-0">
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Totals */}
              <div className="bg-slate-50 p-4 rounded-2xl space-y-1.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-slate-900">${selectedOrder.subtotal.toFixed(2)}</span>
                </div>
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount / Loyalty Redemption</span>
                    <span>-${selectedOrder.discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Delivery ({selectedOrder.deliveryType})</span>
                  <span>{selectedOrder.deliveryFee === 0 ? 'FREE' : `$${selectedOrder.deliveryFee.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Tax</span>
                  <span>${selectedOrder.tax.toFixed(2)}</span>
                </div>
                {selectedOrder.tip > 0 && (
                  <div className="flex justify-between">
                    <span>Driver Tip</span>
                    <span>${selectedOrder.tip.toFixed(2)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm text-slate-900">
                  <span>Total Billed</span>
                  <span className="text-emerald-950 font-black text-base">${selectedOrder.total.toFixed(2)}</span>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* Formal Tax Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-700" />
                <h3 className="font-extrabold text-slate-900 text-base">Tax Receipt &amp; Invoice</h3>
              </div>
              <button
                onClick={() => setShowInvoiceModal(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="flex justify-between">
                <div>
                  <h4 className="font-extrabold text-emerald-900 text-sm">Cornerstone Provisions &amp; Market</h4>
                  <p className="text-slate-500">742 Evergreen Terrace, Springfield</p>
                  <p className="text-slate-400 font-mono">Tax ID: US-98-4421092</p>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-slate-800">Invoice #{showInvoiceModal.orderNumber}</div>
                  <div className="text-slate-400">{new Date(showInvoiceModal.createdAt).toLocaleDateString()}</div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl">
                <div className="font-bold text-slate-700 mb-1">Billed &amp; Delivered To:</div>
                <div className="text-slate-600">{showInvoiceModal.customerName}</div>
                <div className="text-slate-500">
                  {showInvoiceModal.deliveryAddress.street}, {showInvoiceModal.deliveryAddress.apt}
                </div>
                <div className="text-slate-500">
                  {showInvoiceModal.deliveryAddress.city}, {showInvoiceModal.deliveryAddress.zip}
                </div>
              </div>

              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-[11px] uppercase">
                    <th className="py-2">Item</th>
                    <th className="py-2 text-center">Qty</th>
                    <th className="py-2 text-right">Price</th>
                    <th className="py-2 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {showInvoiceModal.items.map((it, idx) => (
                    <tr key={idx}>
                      <td className="py-2 font-medium text-slate-800">{it.product.name}</td>
                      <td className="py-2 text-center">{it.quantity}</td>
                      <td className="py-2 text-right">${it.product.price.toFixed(2)}</td>
                      <td className="py-2 text-right font-bold">${(it.product.price * it.quantity).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="pt-2 border-t border-slate-200 space-y-1 text-right">
                <div>Subtotal: <strong>${showInvoiceModal.subtotal.toFixed(2)}</strong></div>
                {showInvoiceModal.discount > 0 && (
                  <div className="text-emerald-700">Discount: -${showInvoiceModal.discount.toFixed(2)}</div>
                )}
                <div>Delivery Fee: ${showInvoiceModal.deliveryFee.toFixed(2)}</div>
                <div>Sales Tax (7.5%): ${showInvoiceModal.tax.toFixed(2)}</div>
                {showInvoiceModal.tip > 0 && <div>Tip: ${showInvoiceModal.tip.toFixed(2)}</div>}
                <div className="text-base font-black text-slate-900 pt-1">
                  Total Paid: ${showInvoiceModal.total.toFixed(2)}
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm hover:bg-slate-800"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Invoice</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
