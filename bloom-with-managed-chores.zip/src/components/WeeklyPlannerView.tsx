import React, { useState } from 'react';
import { 
  Plus, 
  CheckCircle2, 
  Circle, 
  Clock, 
  Sparkles, 
  ArrowRight, 
  Printer, 
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  RotateCcw,
  Zap,
  Trash2,
  Tag,
  Check
} from 'lucide-react';
import { TaskItem, HabitItem, DayOfWeek, PriorityQuadrant, TimetablePersona } from '../types/planner';
import { calculateScheduleLoad } from '../utils/plannerLogic';
import { FloralCorner, FloralDivider, PeonyIcon } from './FloralAccents';
import { playGentleChime } from '../utils/audioChime';
import { PersonaSwitcher } from './PersonaSwitcher';
import { PERSONA_CONFIGS } from '../data/personaData';

interface WeeklyPlannerViewProps {
  tasks: TaskItem[];
  habits: HabitItem[];
  currentPersona: TimetablePersona;
  onSelectPersona: (persona: TimetablePersona) => void;
  onToggleTask: (taskId: string) => void;
  onAddTask: (task: Partial<TaskItem>) => void;
  onDeleteTask: (taskId: string) => void;
  onRolloverTask: (taskId: string, targetDay: DayOfWeek) => void;
  onToggleHabitDate: (habitId: string, dateStr: string) => void;
  onOpenPrintStudio: () => void;
}

const DAYS_META: { id: DayOfWeek; name: string; short: string; focusTheme: string }[] = [
  { id: 'mon', name: 'Monday', short: 'Mon', focusTheme: 'Clarify Priorities & Deep Focus Block 1' },
  { id: 'tue', name: 'Tuesday', short: 'Tue', focusTheme: 'Sprint & Execution Flow' },
  { id: 'wed', name: 'Wednesday', short: 'Wed', focusTheme: 'Mid-Week Deep Creative Block' },
  { id: 'thu', name: 'Thursday', short: 'Thu', focusTheme: 'System Maintenance & Admin Batch' },
  { id: 'fri', name: 'Friday', short: 'Fri', focusTheme: 'Close Open Loops & Weekly Wrap' },
  { id: 'sat', name: 'Saturday', short: 'Sat', focusTheme: 'Space Reset, Market & Rest' },
  { id: 'sun', name: 'Sunday', short: 'Sun', focusTheme: '30-Min Weekly Plan & Reset' },
];

export function WeeklyPlannerView({
  tasks,
  habits,
  currentPersona,
  onSelectPersona,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  onRolloverTask,
  onToggleHabitDate,
  onOpenPrintStudio,
}: WeeklyPlannerViewProps) {
  const [selectedDay, setSelectedDay] = useState<DayOfWeek>('mon');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [isTop3, setIsTop3] = useState(false);
  const [priority, setPriority] = useState<PriorityQuadrant>('important-not-urgent');
  const [timeBlock, setTimeBlock] = useState<'morning' | 'mid-morning' | 'midday' | 'afternoon' | 'evening'>('morning');

  const personaCfg = PERSONA_CONFIGS[currentPersona];

  // Filter tasks by day
  const getTasksForDay = (day: DayOfWeek) => tasks.filter(t => t.dayOfWeek === day);

  const currentDayTasks = getTasksForDay(selectedDay);
  const currentScheduleLoad = calculateScheduleLoad(currentDayTasks);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    onAddTask({
      title: newTaskTitle.trim(),
      dayOfWeek: selectedDay,
      category: isTop3 ? 'top3' : 'inbox',
      priority,
      timeBlock,
      estimatedMinutes: timeBlock === 'morning' || timeBlock === 'mid-morning' ? 50 : 30,
      completed: false,
      dateAdded: new Date().toISOString().split('T')[0],
    });

    setNewTaskTitle('');
    setIsTop3(false);
    playGentleChime('sparkle');
  };

  const getPriorityBadge = (p: PriorityQuadrant) => {
    switch (p) {
      case 'urgent-important':
        return <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#8C3246]/10 text-[#8C3246] border border-[#8C3246]/20">Urgent &amp; Important</span>;
      case 'important-not-urgent':
        return <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#616D48]/15 text-[#4B5634] border border-[#616D48]/30">Important (Moves Goals)</span>;
      case 'urgent-not-important':
        return <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#C28255]/15 text-[#8F5529] border border-[#C28255]/30">Delegate / Batch</span>;
      case 'not-urgent-not-important':
        return <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-stone-200 text-stone-600">Drop / Trivial</span>;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Editorial Grid Layout - Variation 1 Tactile Broadside */}
      <div className="bg-[#fdfcf9] border-2 border-[#1a1a1a] shadow-xs p-5 sm:p-7 no-print">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          
          {/* Column 1: Rituals */}
          <div className="flex flex-col justify-between">
            <div>
              <span className="font-mono-space text-[10px] uppercase tracking-[0.18em] text-[#7b2c3c] block font-bold mb-1">
                [ SECTION 01 ]
              </span>
              <h2 className="font-serif-cormorant italic text-2xl sm:text-3xl text-[#1a1a1a] border-b border-[#1a1a1a]/15 pb-2 mb-4">
                Ritual Checklist
              </h2>
              <div className="space-y-3">
                {currentDayTasks.slice(0, 5).map((task) => (
                  <div 
                    key={task.id} 
                    onClick={() => onToggleTask(task.id)}
                    className="flex items-start gap-3 text-xs sm:text-sm text-[#1a1a1a] cursor-pointer group select-none"
                  >
                    <div className={`w-2.5 h-2.5 rounded-full border border-[#1a1a1a] shrink-0 mt-1 transition-colors ${
                      task.completed ? 'bg-[#7b2c3c] border-[#7b2c3c]' : 'bg-transparent group-hover:border-[#7b2c3c]'
                    }`} />
                    <span className={`line-clamp-2 leading-snug ${task.completed ? 'line-through text-[#1a1a1a]/40' : 'text-[#1a1a1a]'}`}>
                      {task.title}
                    </span>
                  </div>
                ))}
                {currentDayTasks.length < 5 && (
                  <>
                    <div className="flex items-start gap-3 text-xs text-[#1a1a1a]/40 font-mono-space">
                      <div className="w-2.5 h-2.5 rounded-full border border-[#1a1a1a]/40 shrink-0 mt-1" />
                      <span>90min Deep focus block</span>
                    </div>
                    <div className="flex items-start gap-3 text-xs text-[#1a1a1a]/40 font-mono-space">
                      <div className="w-2.5 h-2.5 rounded-full border border-[#1a1a1a]/40 shrink-0 mt-1" />
                      <span>8PM digital sunset ritual</span>
                    </div>
                    <div className="flex items-start gap-3 text-xs text-[#1a1a1a]/20 font-mono-space">
                      <div className="w-2.5 h-2.5 rounded-full border border-[#1a1a1a]/20 shrink-0 mt-1" />
                      <span>.........................</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-[#1a1a1a]/10 flex items-center justify-between text-[11px] font-mono-space text-[#1a1a1a]/70">
              <span>{DAYS_META.find(d => d.id === selectedDay)?.short.toUpperCase()} LOAD:</span>
              <span className="font-bold text-[#7b2c3c]">{currentScheduleLoad.loadPercentage}% CAPACITY</span>
            </div>
          </div>

          {/* Column 2: The Flow */}
          <div className="flex flex-col justify-between">
            <div>
              <span className="font-mono-space text-[10px] uppercase tracking-[0.18em] text-[#7b2c3c] block font-bold mb-1">
                [ SECTION 02 ]
              </span>
              <h2 className="font-serif-cormorant italic text-2xl sm:text-3xl text-[#1a1a1a] border-b border-[#1a1a1a]/15 pb-2 mb-4">
                The Schedule
              </h2>
              
              <div className="space-y-4">
                <div>
                  <span className="font-mono-space text-[10px] uppercase tracking-wider text-[#7b2c3c] block font-bold">
                    Mon / Tue
                  </span>
                  <h3 className="font-mono-space text-xs font-bold text-[#1a1a1a] uppercase mt-0.5">
                    Foundations &amp; Sprints
                  </h3>
                  <p className="text-xs text-[#1a1a1a]/70 mt-1 leading-relaxed">
                    Establishing structure. High-priority focus blocks, course lectures, and administrative rituals.
                  </p>
                </div>

                <div>
                  <span className="font-mono-space text-[10px] uppercase tracking-wider text-[#7b2c3c] block font-bold">
                    Wed / Thu
                  </span>
                  <h3 className="font-mono-space text-xs font-bold text-[#1a1a1a] uppercase mt-0.5">
                    Deep Flow &amp; Recall
                  </h3>
                  <p className="text-xs text-[#1a1a1a]/70 mt-1 leading-relaxed">
                    Artisan execution. Spaced repetition testing, core deliverables, and creative problem solving.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#1a1a1a]/10">
              <span className="text-[10px] font-mono-space text-[#1a1a1a]/60 italic">
                Active: {personaCfg.shortLabel.toUpperCase()} TIMETABLE
              </span>
            </div>
          </div>

          {/* Column 3: Maintenance & Habit Streaks */}
          <div className="flex flex-col justify-between">
            <div>
              <span className="font-mono-space text-[10px] uppercase tracking-[0.18em] text-[#7b2c3c] block font-bold mb-1">
                [ SECTION 03 ]
              </span>
              <h2 className="font-serif-cormorant italic text-2xl sm:text-3xl text-[#1a1a1a] border-b border-[#1a1a1a]/15 pb-2 mb-4">
                Habit Streaks
              </h2>

              <div className="divide-y divide-[#1a1a1a]/10">
                {habits.slice(0, 3).map((h) => (
                  <div key={h.id} className="py-2.5 flex items-baseline justify-between">
                    <div>
                      <span className="font-mono-space text-[10px] uppercase tracking-wider text-[#7b2c3c] block font-bold">
                        {h.name.split(' ')[1] || 'Habit'}
                      </span>
                      <p className="text-xs text-[#1a1a1a]/80 line-clamp-1">{h.name}</p>
                    </div>
                    <span className="font-serif-cormorant text-4xl sm:text-5xl font-light text-[#1a1a1a] ml-2">
                      {String(h.currentStreak).padStart(2, '0')}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-[#1a1a1a]/10">
              <p className="italic font-serif-cormorant text-xs text-[#1a1a1a]/60">
                Botanical wine &amp; parchment aesthetics for mindful living.
              </p>
            </div>
          </div>

          {/* Column 4: Meta & CTA Sidebar */}
          <aside className="bg-[#f2efeb] p-5 sm:p-6 flex flex-col justify-between border border-[#1a1a1a]/10">
            <div>
              <span className="font-mono-space text-[10px] uppercase tracking-[0.18em] text-[#7b2c3c] block font-bold mb-1">
                [ THE PHILOSOPHY ]
              </span>
              <p className="text-xs text-[#1a1a1a]/80 leading-relaxed mt-2 font-sans">
                Artisan productivity: turning intentional cognitive rules into gorgeous sustainable habits.
              </p>
              
              <div className="w-full h-px bg-[#1a1a1a]/15 my-4" />
              
              <div className="space-y-1">
                <span className="font-mono-space text-[10px] uppercase tracking-wider text-[#7b2c3c] block font-bold">
                  Fri / Sat / Sun
                </span>
                <h3 className="font-mono-space text-xs font-bold text-[#1a1a1a] uppercase">
                  Restoration
                </h3>
                <p className="text-xs text-[#1a1a1a]/70 leading-relaxed">
                  Reflection on weekly growth. Pure disconnection for the next botanical cycle.
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#1a1a1a]/10 space-y-3">
              <PersonaSwitcher
                currentPersona={currentPersona}
                onSelectPersona={onSelectPersona}
                compact={false}
              />

              <button
                onClick={onOpenPrintStudio}
                className="w-full py-3 bg-[#1a1a1a] hover:bg-[#7b2c3c] text-[#fdfcf9] font-mono-space font-bold text-xs tracking-widest uppercase transition-colors cursor-pointer text-center block"
              >
                PRINT YOUR PLANNER
              </button>
            </div>
          </aside>

        </div>
      </div>

      {/* 7-Day Selector Tabs - Space Mono Styled */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {DAYS_META.map((day) => {
          const isSelected = selectedDay === day.id;
          const dayTasks = getTasksForDay(day.id);
          const top3Count = dayTasks.filter(t => t.category === 'top3').length;
          const completedCount = dayTasks.filter(t => t.completed).length;

          return (
            <button
              key={day.id}
              onClick={() => setSelectedDay(day.id)}
              className={`p-3 border text-left transition-all duration-150 cursor-pointer ${
                isSelected
                  ? 'bg-[#1a1a1a] text-[#fdfcf9] border-[#1a1a1a] shadow-xs'
                  : 'bg-[#fdfcf9] hover:bg-[#f2efeb] border-[#1a1a1a]/20 text-[#1a1a1a]'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] font-mono-space font-bold uppercase tracking-wider ${
                  isSelected ? 'text-[#7b2c3c]' : 'text-[#1a1a1a]/60'
                }`}>
                  [{day.short.toUpperCase()}]
                </span>
                {top3Count > 0 && (
                  <span className={`text-[9px] font-mono-space font-bold px-1.5 py-0.2 ${
                    isSelected ? 'bg-white/20 text-[#fdfcf9]' : 'bg-[#1a1a1a]/10 text-[#1a1a1a]'
                  }`}>
                    {top3Count} TOP
                  </span>
                )}
              </div>
              <p className={`font-serif-cormorant text-lg font-bold truncate ${
                isSelected ? 'text-[#fdfcf9]' : 'text-[#1a1a1a]'
              }`}>
                {day.name}
              </p>
              <div className={`mt-2 flex items-center justify-between text-[10px] font-mono-space ${
                isSelected ? 'text-[#fdfcf9]/70' : 'text-[#1a1a1a]/60'
              }`}>
                <span>{dayTasks.length} ITEMS</span>
                <span>{completedCount}/{dayTasks.length} DONE</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Day Column & Schedule Container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Day's Tasks & Structured Schedule */}
        <div className="lg:col-span-2 space-y-5">
          
          {/* Day Focus Header */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl sm:text-2xl font-serif-cormorant font-bold text-[#2D2326]">
                  {DAYS_META.find(d => d.id === selectedDay)?.name} Schedule
                </h3>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#FAF0F2] text-[#8C3246] font-medium border border-[#DDA5A5]/30">
                  {DAYS_META.find(d => d.id === selectedDay)?.focusTheme}
                </span>
              </div>
              <p className="text-xs text-[#786C6E] mt-1">
                Execute Top 3 in early blocks. Keep phone out of sight during Focus Block 1.
              </p>
            </div>

            {/* Quick Add Form Trigger */}
            <form onSubmit={handleCreateTask} className="w-full sm:w-auto flex-1 max-w-md">
              <div className="flex items-center gap-2 bg-[#FAF6F0] rounded-xl border border-[#EADBCE] px-3 py-1.5 focus-within:border-[#8C3246] transition-all">
                <Plus className="w-4 h-4 text-[#8C3246] shrink-0" />
                <input
                  type="text"
                  placeholder={`Add task for ${DAYS_META.find(d => d.id === selectedDay)?.name}...`}
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  className="w-full bg-transparent text-xs sm:text-sm text-[#2D2326] focus:outline-none placeholder:text-[#9B8F91]"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1 rounded-lg bg-[#8C3246] text-white text-xs font-medium hover:bg-[#732738] transition-colors cursor-pointer"
                >
                  Add
                </button>
              </div>
            </form>
          </div>

          {/* Section 1: Top 3 Daily Priorities (The Non-Negotiables) */}
          <div className="bg-[#FFFDFB] rounded-2xl border-2 border-[#DDA5A5]/60 p-4 sm:p-5 shadow-xs relative">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-[#FAF0F2] flex items-center justify-center text-[#8C3246]">
                  <PeonyIcon className="w-4 h-4" />
                </div>
                <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326]">
                  Top 3 Daily Focus (Chosen Night Before)
                </h4>
              </div>
              <span className="text-xs text-[#8C3246] font-semibold">
                {currentDayTasks.filter(t => t.category === 'top3' && t.completed).length} / {Math.min(3, currentDayTasks.filter(t => t.category === 'top3').length)} Finished
              </span>
            </div>

            {currentDayTasks.filter(t => t.category === 'top3').length === 0 ? (
              <div className="p-4 rounded-xl bg-[#FAF6F0] border border-dashed border-[#DDA5A5] text-center text-xs text-[#786C6E]">
                No Top 3 tasks selected for this day yet. Star or move high-impact tasks here from your master inbox.
              </div>
            ) : (
              <div className="space-y-3">
                {currentDayTasks
                  .filter(t => t.category === 'top3')
                  .map((task, index) => (
                    <div
                      key={task.id}
                      className={`p-3.5 rounded-xl border transition-all duration-150 ${
                        task.completed
                          ? 'bg-[#F4F7F2] border-[#616D48]/30 opacity-75'
                          : 'bg-white border-[#EADBCE] hover:border-[#DDA5A5] shadow-xs'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <button
                          onClick={() => {
                            onToggleTask(task.id);
                            if (!task.completed) playGentleChime('success');
                          }}
                          className="mt-1 shrink-0 cursor-pointer"
                          title="Toggle completion"
                        >
                          <div className={`w-3.5 h-3.5 rounded-full border border-[#1a1a1a] transition-all flex items-center justify-center ${
                            task.completed ? 'bg-[#7b2c3c] border-[#7b2c3c]' : 'bg-transparent hover:border-[#7b2c3c]'
                          }`}>
                            {task.completed && <Check className="w-2 h-2 text-[#fdfcf9]" />}
                          </div>
                        </button>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-[#8C3246]">
                              #{index + 1}
                            </span>
                            <span className={`text-sm font-medium ${task.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'}`}>
                              {task.title}
                            </span>
                          </div>

                          {/* Next Physical Action callout */}
                          {task.nextPhysicalAction && (
                            <div className="mt-1.5 flex items-center gap-1.5 text-xs text-[#535E3B] bg-[#EDF2E8]/60 px-2.5 py-1 rounded-lg">
                              <Zap className="w-3.5 h-3.5 text-[#616D48] shrink-0" />
                              <span className="font-medium">Next physical action:</span>
                              <span className="italic">{task.nextPhysicalAction}</span>
                            </div>
                          )}

                          {/* Implementation intention (If-then) */}
                          {task.ifThenIntention && (
                            <div className="mt-1 text-[11px] text-[#786C6E] flex items-center gap-1">
                              <span className="font-semibold text-[#8C3246]">If</span> {task.ifThenIntention.condition}, <span className="font-semibold text-[#8C3246]">then</span> {task.ifThenIntention.action}
                            </div>
                          )}

                          <div className="mt-2 flex items-center gap-2 flex-wrap text-[11px] text-[#786C6E]">
                            {getPriorityBadge(task.priority)}
                            {task.timeBlock && (
                              <span className="capitalize px-2 py-0.5 rounded-md bg-[#FAF6F0] text-[#5C4F51] border border-[#EADBCE]">
                                {task.timeBlock} Block
                              </span>
                            )}
                            {task.estimatedMinutes && (
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {task.estimatedMinutes} min
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions: Rollover or delete */}
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              const dayOrder: DayOfWeek[] = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
                              const nextIdx = (dayOrder.indexOf(selectedDay) + 1) % dayOrder.length;
                              onRolloverTask(task.id, dayOrder[nextIdx]);
                            }}
                            className="p-1 rounded-md text-[#786C6E] hover:text-[#8C3246] hover:bg-[#FAF0F2] transition-colors cursor-pointer"
                            title="Move to next day"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteTask(task.id)}
                            className="p-1 rounded-md text-[#786C6E] hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Delete task"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>

          {/* Section 2: Other Tasks & Time Blocks for the Day */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-4 sm:p-5 shadow-xs">
            <h4 className="font-serif-cormorant text-lg font-bold text-[#2D2326] mb-3">
              Secondary Flow &amp; Batched Tasks
            </h4>

            {currentDayTasks.filter(t => t.category !== 'top3').length === 0 ? (
              <p className="text-xs text-[#786C6E] italic py-2">
                No secondary tasks. You have plenty of margin for deep work and unexpected interruptions.
              </p>
            ) : (
              <div className="divide-y divide-[#EADBCE]/50">
                {currentDayTasks
                  .filter(t => t.category !== 'top3')
                  .map((task) => (
                    <div key={task.id} className="py-2.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <button
                          onClick={() => {
                            onToggleTask(task.id);
                            if (!task.completed) playGentleChime('success');
                          }}
                          className="shrink-0 cursor-pointer"
                          title="Toggle completion"
                        >
                          <div className={`w-3.5 h-3.5 rounded-full border border-[#1a1a1a] transition-all flex items-center justify-center ${
                            task.completed ? 'bg-[#7b2c3c] border-[#7b2c3c]' : 'bg-transparent hover:border-[#7b2c3c]'
                          }`}>
                            {task.completed && <Check className="w-2 h-2 text-[#fdfcf9]" />}
                          </div>
                        </button>
                        <span className={`text-xs sm:text-sm ${task.completed ? 'line-through text-[#786C6E]' : 'text-[#2D2326]'}`}>
                          {task.title}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {getPriorityBadge(task.priority)}
                        <button
                          onClick={() => onDeleteTask(task.id)}
                          className="text-[#9B8F91] hover:text-rose-600 transition-colors p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Sample Day Guide & Habit Progress */}
        <div className="space-y-5">
          
          {/* Sample Day Blueprint Box (Directly from User Prompt!) */}
          <div className="bg-[#FAF6F0] rounded-2xl border border-[#EADBCE] p-4 sm:p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-2 h-2 rounded-full bg-[#8C3246]" />
              <h4 className="font-serif-cormorant text-base font-bold text-[#2D2326]">
                The Simple Sample Day Formula
              </h4>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-2.5 rounded-xl bg-white border border-[#EADBCE]">
                <div className="font-bold text-[#8C3246] flex items-center gap-1.5">
                  <span>08:30 – 10:00</span>
                  <span>•</span>
                  <span>Morning Focus Block 1</span>
                </div>
                <p className="text-[#5C4F51] mt-0.5">
                  Look at Top 3 priorities. Complete Task #1 with phone out of sight.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-white border border-[#EADBCE]">
                <div className="font-bold text-[#616D48] flex items-center gap-1.5">
                  <span>10:30 – 11:30</span>
                  <span>•</span>
                  <span>Mid-Morning Block 2</span>
                </div>
                <p className="text-[#5C4F51] mt-0.5">
                  Deep focus block 2, followed by a 10-minute tea or walk break.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-white border border-[#EADBCE]">
                <div className="font-bold text-[#C28255] flex items-center gap-1.5">
                  <span>12:00 – 13:00</span>
                  <span>•</span>
                  <span>Midday Batching</span>
                </div>
                <p className="text-[#5C4F51] mt-0.5">
                  Batch messages, calls, errands, and under-2-minute quick wins.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-white border border-[#EADBCE]">
                <div className="font-bold text-[#786C6E] flex items-center gap-1.5">
                  <span>14:00 – 16:30</span>
                  <span>•</span>
                  <span>Afternoon Flow Block</span>
                </div>
                <p className="text-[#5C4F51] mt-0.5">
                  Focus block 3, then flexible buffer time for whatever came up.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-[#FAF0F2] border border-[#DDA5A5]">
                <div className="font-bold text-[#8C3246] flex items-center gap-1.5">
                  <span>17:00 – 17:15</span>
                  <span>•</span>
                  <span>Evening 10-Min Shutdown</span>
                </div>
                <p className="text-[#5C4F51] mt-0.5">
                  Review done list, plan tomorrow's Top 3, clear and tidy desk.
                </p>
              </div>
            </div>
          </div>

          {/* Daily Habit Check for Selected Day */}
          <div className="bg-white rounded-2xl border border-[#EADBCE] p-4 sm:p-5 shadow-xs">
            <h4 className="font-serif-cormorant text-base font-bold text-[#2D2326] mb-3">
              Habits Tracked for {DAYS_META.find(d => d.id === selectedDay)?.short}
            </h4>
            <div className="space-y-2.5">
              {habits.map((habit) => {
                const todayKey = new Date().toISOString().split('T')[0];
                const isCompleted = habit.completedDates[todayKey] || false;

                return (
                  <div
                    key={habit.id}
                    onClick={() => {
                      onToggleHabitDate(habit.id, todayKey);
                      if (!isCompleted) playGentleChime('sparkle');
                    }}
                    className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isCompleted ? 'bg-[#EDF2E8] border-[#616D48]/30' : 'bg-[#FAF6F0] border-[#EADBCE] hover:border-[#DDA5A5]'
                    }`}
                  >
                    <div>
                      <p className={`text-xs font-semibold ${isCompleted ? 'text-[#4B5634]' : 'text-[#2D2326]'}`}>
                        {habit.name}
                      </p>
                      <p className="text-[11px] text-[#786C6E] truncate max-w-[200px]">
                        {habit.description}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-white text-[#8C3246] border border-[#EADBCE]">
                        🔥 {habit.currentStreak}d
                      </span>
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-[#616D48]" />
                      ) : (
                        <Circle className="w-5 h-5 text-[#DDA5A5]" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
