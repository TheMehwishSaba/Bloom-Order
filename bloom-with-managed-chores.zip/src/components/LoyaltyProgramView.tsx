import React, { useState } from 'react';
import { 
  Award, 
  Sparkles, 
  Gift, 
  Calendar, 
  Share2, 
  Copy, 
  Check, 
  TrendingUp, 
  ChevronRight,
  ShieldCheck,
  Zap,
  ArrowRight
} from 'lucide-react';
import { LoyaltyProfile, LoyaltyVoucher } from '../types/store';
import { getTierMultiplier } from '../utils/storeLogic';

interface LoyaltyProgramViewProps {
  loyaltyProfile: LoyaltyProfile;
  onClaimDailyStreak: () => void;
  onRedeemVoucher: (voucher: LoyaltyVoucher) => void;
  onApplyVoucherToCart?: (code: string) => void;
  onClose?: () => void;
}

export const LoyaltyProgramView: React.FC<LoyaltyProgramViewProps> = ({
  loyaltyProfile,
  onClaimDailyStreak,
  onRedeemVoucher,
  onApplyVoucherToCart,
  onClose,
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [referralCopied, setReferralCopied] = useState(false);

  const multiplier = getTierMultiplier(loyaltyProfile.tier);
  const dollarEquivalent = (loyaltyProfile.points / 100).toFixed(2);

  // Calculate tier roadmap
  const tiers = [
    { name: 'Bronze', points: 0, perk: '10 pts per $1 spent' },
    { name: 'Silver', points: 500, perk: '12 pts per $1 spent + Birthday Treat' },
    { name: 'Gold', points: 1500, perk: '15 pts per $1 spent + Free Priority Packing' },
    { name: 'Platinum', points: 3000, perk: '20 pts per $1 spent + VIP Free Express Always' },
  ];

  const nextTier = tiers.find((t) => t.points > loyaltyProfile.lifetimePoints) || tiers[tiers.length - 1];
  const pointsToNext = Math.max(0, nextTier.points - loyaltyProfile.lifetimePoints);

  const handleCopy = (code: string) => {
    navigator.clipboard?.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleCopyReferral = () => {
    navigator.clipboard?.writeText('https://cornerstoneprovisions.market/invite?code=URUSH2026');
    setReferralCopied(true);
    setTimeout(() => setReferralCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">Cornerstone Perks &amp; Loyalty</h1>
            {onClose && (
              <button
                onClick={onClose}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-200/80 hover:bg-slate-300 text-slate-700 font-semibold"
              >
                Back to Store
              </button>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Earn points on every fresh provision, unlock discount vouchers, and elevate your member tier.
          </p>
        </div>

        {/* Daily Streak Card */}
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-white p-3.5 rounded-2xl shadow-md flex items-center gap-3">
          <div className="p-2 bg-white/20 rounded-xl">
            <Calendar className="w-5 h-5 text-amber-100" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-amber-100 uppercase tracking-wider">
              {loyaltyProfile.streakDays}-Day Grocery Streak
            </div>
            <div className="text-xs font-semibold">
              Claim daily bonus points!
            </div>
          </div>
          <button
            onClick={onClaimDailyStreak}
            className="px-3 py-1.5 bg-white text-amber-900 rounded-xl text-xs font-extrabold hover:bg-amber-50 active:scale-95 transition shadow-sm ml-2"
          >
            Claim +25 pts
          </button>
        </div>
      </div>

      {/* Main Loyalty Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        
        {/* Card 1: Balance & Dollar Value */}
        <div className="bg-gradient-to-br from-emerald-900 to-teal-950 text-white p-6 rounded-3xl shadow-xl relative overflow-hidden flex flex-col justify-between">
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl" />
          
          <div>
            <div className="flex justify-between items-center mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" /> Available Balance
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-amber-400 text-slate-900 uppercase">
                {loyaltyProfile.tier} Member
              </span>
            </div>

            <div className="text-4xl font-black text-white tracking-tight mb-1">
              {loyaltyProfile.points.toLocaleString()} <span className="text-lg font-semibold text-emerald-300">pts</span>
            </div>
            <div className="text-xs text-emerald-200">
              Equivalent to <strong>${dollarEquivalent}</strong> in instant grocery credits
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-emerald-800/80 flex items-center justify-between text-xs">
            <span className="text-emerald-300">Earning Rate:</span>
            <span className="font-extrabold text-white flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" /> {multiplier}x points per $1.00
            </span>
          </div>
        </div>

        {/* Card 2: Tier Roadmap */}
        <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Tier Progression
              </span>
              <span className="text-xs font-bold text-slate-700">
                {loyaltyProfile.lifetimePoints} / {nextTier.points} Lifetime Pts
              </span>
            </div>

            <h3 className="text-base font-extrabold text-slate-900 mb-1">
              Target: {nextTier.name} Tier
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              {pointsToNext > 0 
                ? `Earn ${pointsToNext} more lifetime points to unlock ${nextTier.perk}!`
                : 'You have attained our highest VIP Platinum status!'}
            </p>

            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden mb-4">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-600 h-2.5 rounded-full"
                style={{
                  width: `${Math.min(100, (loyaltyProfile.lifetimePoints / nextTier.points) * 100)}%`,
                }}
              />
            </div>
          </div>

          <div className="grid grid-cols-4 text-center text-[10px] text-slate-400 font-bold uppercase pt-2 border-t border-slate-100">
            <div className={loyaltyProfile.tier === 'Bronze' ? 'text-emerald-700 font-black' : ''}>Bronze</div>
            <div className={loyaltyProfile.tier === 'Silver' ? 'text-emerald-700 font-black' : ''}>Silver</div>
            <div className={loyaltyProfile.tier === 'Gold' ? 'text-emerald-700 font-black' : ''}>Gold ★</div>
            <div className={loyaltyProfile.tier === 'Platinum' ? 'text-emerald-700 font-black' : ''}>Platinum</div>
          </div>
        </div>

        {/* Card 3: Referral Bonus */}
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/80 p-6 rounded-3xl shadow-sm flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center gap-1.5 mb-2">
              <Share2 className="w-4 h-4 text-amber-600" /> Refer a Neighbor
            </div>
            <h3 className="text-base font-extrabold text-amber-950 mb-1">
              Give $10, Get $10 in Groceries
            </h3>
            <p className="text-xs text-amber-900/80 mb-4 leading-relaxed">
              Share your invite link with friends and neighbors. When they place their first order, both get 1,000 points ($10 value).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex-1 bg-white px-3 py-2 rounded-xl border border-amber-200 font-mono text-xs font-bold text-amber-950 truncate">
              URUSH-2026
            </div>
            <button
              onClick={handleCopyReferral}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold shadow-sm transition shrink-0 flex items-center gap-1"
            >
              {referralCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{referralCopied ? 'Copied' : 'Share'}</span>
            </button>
          </div>
        </div>

      </div>

      {/* Rewards Voucher Catalog */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900">Redeem Available Perks &amp; Vouchers</h2>
            <p className="text-xs text-slate-500">
              Exchange your points for immediate checkout promo vouchers.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {loyaltyProfile.vouchers.map((voucher) => {
            const canAfford = loyaltyProfile.points >= voucher.pointsCost;

            return (
              <div
                key={voucher.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between hover:border-emerald-300 hover:shadow-md transition"
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                      <Gift className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-extrabold text-emerald-800 font-mono">
                      {voucher.pointsCost} pts
                    </span>
                  </div>

                  <h4 className="font-extrabold text-sm text-slate-900 mb-1">
                    {voucher.title}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mb-4">
                    {voucher.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg">
                      {voucher.code}
                    </span>

                    <button
                      onClick={() => {
                        handleCopy(voucher.code);
                        if (onApplyVoucherToCart) {
                          onApplyVoucherToCart(voucher.code);
                        }
                      }}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1"
                    >
                      {copiedCode === voucher.code ? (
                        <>
                          <Check className="w-3 h-3" />
                          <span>Applied</span>
                        </>
                      ) : (
                        <span>Use Code</span>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Points History Log */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
        <h3 className="text-base font-extrabold text-slate-900 mb-4">
          Recent Points Activity Log
        </h3>

        <div className="divide-y divide-slate-100">
          {loyaltyProfile.history.map((item) => (
            <div key={item.id} className="py-3 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${item.pointsChange > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                  {item.pointsChange > 0 ? <TrendingUp className="w-4 h-4" /> : <Gift className="w-4 h-4" />}
                </div>
                <div>
                  <div className="font-bold text-slate-900">{item.description}</div>
                  <div className="text-[11px] text-slate-400">{item.date}</div>
                </div>
              </div>

              <div className={`font-mono font-extrabold ${item.pointsChange > 0 ? 'text-emerald-700' : 'text-slate-600'}`}>
                {item.pointsChange > 0 ? `+${item.pointsChange}` : item.pointsChange} pts
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
