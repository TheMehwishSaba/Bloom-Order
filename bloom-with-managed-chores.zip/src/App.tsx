/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HeaderNav, ActiveTab } from './components/HeaderNav';
import { WeeklyPlannerView } from './components/WeeklyPlannerView';
import { DailyFocusView } from './components/DailyFocusView';
import { HomeChoresView } from './components/HomeChoresView';
import { StudySchedulesView } from './components/StudySchedulesView';
import { CaptureInboxView } from './components/CaptureInboxView';
import { RepeatChecklistsView } from './components/RepeatChecklistsView';
import { GoalMatrixView } from './components/GoalMatrixView';
import { PrintStudioModal } from './components/PrintStudioModal';
import { EveningShutdownModal } from './components/EveningShutdownModal';
import { QuickCaptureModal } from './components/QuickCaptureModal';
import { GitHubExportModal } from './components/GitHubExportModal';
import { FloralCorner, FloralDivider, PeonyIcon } from './components/FloralAccents';
import { 
  INITIAL_TASKS, 
  INITIAL_HABITS, 
  INITIAL_REPEAT_CHECKLISTS, 
  INITIAL_90_DAY_GOALS, 
  INITIAL_HOME_CHORES, 
  INITIAL_STUDY_SESSIONS, 
  FLORAL_QUOTES 
} from './data/plannerData';
import { getPersonaData, PERSONA_CONFIGS } from './data/personaData';
import { calculatePlannerStats } from './utils/plannerLogic';
import { TaskItem, HabitItem, RepeatChecklist, Goal90Day, DayOfWeek, HomeChore, StudySession, TimetablePersona } from './types/planner';
import { Sparkles, Printer, RotateCcw, Heart, Calendar, CheckCircle2, GitBranch } from 'lucide-react';
import { playGentleChime } from './utils/audioChime';

export default function App() {
  // Lifestyle Persona State (Student, Professional, Working Mother, Balanced)
  const [currentPersona, setCurrentPersona] = useState<TimetablePersona>(() => {
    try {
      const saved = localStorage.getItem('bloom_persona_v1');
      return (saved as TimetablePersona) || 'student';
    } catch {
      return 'student';
    }
  });

  // Local storage state with initial fallbacks
  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    try {
      const saved = localStorage.getItem('bloom_tasks_v1');
      if (saved) return JSON.parse(saved);
      const personaInit = getPersonaData('student');
      return personaInit.tasks;
    } catch {
      return INITIAL_TASKS;
    }
  });

  const [habits, setHabits] = useState<HabitItem[]>(() => {
    try {
      const saved = localStorage.getItem('bloom_habits_v1');
      return saved ? JSON.parse(saved) : INITIAL_HABITS;
    } catch {
      return INITIAL_HABITS;
    }
  });

  const [checklists, setChecklists] = useState<RepeatChecklist[]>(() => {
    try {
      const saved = localStorage.getItem('bloom_checklists_v1');
      return saved ? JSON.parse(saved) : INITIAL_REPEAT_CHECKLISTS;
    } catch {
      return INITIAL_REPEAT_CHECKLISTS;
    }
  });

  const [goals, setGoals] = useState<Goal90Day[]>(() => {
    try {
      const saved = localStorage.getItem('bloom_goals_v1');
      return saved ? JSON.parse(saved) : INITIAL_90_DAY_GOALS;
    } catch {
      return INITIAL_90_DAY_GOALS;
    }
  });

  const [chores, setChores] = useState<HomeChore[]>(() => {
    try {
      const saved = localStorage.getItem('bloom_chores_v1');
      return saved ? JSON.parse(saved) : INITIAL_HOME_CHORES;
    } catch {
      return INITIAL_HOME_CHORES;
    }
  });

  const [studySessions, setStudySessions] = useState<StudySession[]>(() => {
    try {
      const saved = localStorage.getItem('bloom_study_v1');
      return saved ? JSON.parse(saved) : INITIAL_STUDY_SESSIONS;
    } catch {
      return INITIAL_STUDY_SESSIONS;
    }
  });

  // UI Navigation & Modals
  const [activeTab, setActiveTab] = useState<ActiveTab>('weekly');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isShutdownModalOpen, setIsShutdownModalOpen] = useState(false);
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);
  const [isGitHubModalOpen, setIsGitHubModalOpen] = useState(false);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem('bloom_tasks_v1', JSON.stringify(tasks));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [tasks]);

  useEffect(() => {
    try {
      localStorage.setItem('bloom_habits_v1', JSON.stringify(habits));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [habits]);

  useEffect(() => {
    try {
      localStorage.setItem('bloom_checklists_v1', JSON.stringify(checklists));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [checklists]);

  useEffect(() => {
    try {
      localStorage.setItem('bloom_goals_v1', JSON.stringify(goals));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [goals]);

  useEffect(() => {
    try {
      localStorage.setItem('bloom_chores_v1', JSON.stringify(chores));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [chores]);

  useEffect(() => {
    try {
      localStorage.setItem('bloom_study_v1', JSON.stringify(studySessions));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [studySessions]);

  // Global hotkey: Cmd/Ctrl + K for quick capture
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsQuickCaptureOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Stats calculation
  const stats = calculatePlannerStats(tasks, habits);

  // Task actions
  const handleToggleTask = (taskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        const nextCompleted = !t.completed;
        return {
          ...t,
          completed: nextCompleted,
          completedAt: nextCompleted ? new Date().toISOString() : undefined,
        };
      }
      return t;
    }));
  };

  const handleAddTask = (taskData: Partial<TaskItem>) => {
    const newTask: TaskItem = {
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      title: taskData.title || 'Untitled task',
      category: taskData.category || 'inbox',
      dayOfWeek: taskData.dayOfWeek || 'mon',
      timeBlock: taskData.timeBlock || 'morning',
      completed: false,
      priority: taskData.priority || 'important-not-urgent',
      nextPhysicalAction: taskData.nextPhysicalAction,
      definitionOfDone: taskData.definitionOfDone,
      ifThenIntention: taskData.ifThenIntention,
      estimatedMinutes: taskData.estimatedMinutes || 45,
      delegatedTo: taskData.delegatedTo,
      dateAdded: new Date().toISOString().split('T')[0],
    };

    setTasks(prev => [newTask, ...prev]);
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const handleRolloverTask = (taskId: string, targetDay: DayOfWeek) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return { ...t, dayOfWeek: targetDay };
      }
      return t;
    }));
    playGentleChime('sparkle');
  };

  const handleAssignToDay = (taskId: string, day: DayOfWeek) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return { ...t, dayOfWeek: day, category: 'top3' };
      }
      return t;
    }));
  };

  // Habit actions
  const handleToggleHabitDate = (habitId: string, dateStr: string) => {
    setHabits(prev => prev.map(h => {
      if (h.id === habitId) {
        const currentDone = h.completedDates[dateStr] || false;
        const newDates = { ...h.completedDates, [dateStr]: !currentDone };
        const newStreak = !currentDone ? (h.currentStreak || 0) + 1 : Math.max(0, (h.currentStreak || 0) - 1);
        return {
          ...h,
          completedDates: newDates,
          currentStreak: newStreak,
          bestStreak: Math.max(h.bestStreak || 0, newStreak),
        };
      }
      return h;
    }));
  };

  // Checklist actions
  const handleToggleChecklistItem = (checklistId: string, itemId: string) => {
    setChecklists(prev => prev.map(c => {
      if (c.id === checklistId) {
        return {
          ...c,
          items: c.items.map(item => item.id === itemId ? { ...item, completed: !item.completed } : item),
        };
      }
      return c;
    }));
  };

  const handleResetChecklist = (checklistId: string) => {
    setChecklists(prev => prev.map(c => {
      if (c.id === checklistId) {
        return {
          ...c,
          items: c.items.map(item => ({ ...item, completed: false })),
        };
      }
      return c;
    }));
  };

  const handleAddChecklistItem = (checklistId: string, text: string) => {
    setChecklists(prev => prev.map(c => {
      if (c.id === checklistId) {
        return {
          ...c,
          items: [
            ...c.items,
            { id: `item-${Date.now()}`, text, completed: false }
          ],
        };
      }
      return c;
    }));
  };

  const handleDeleteChecklistItem = (checklistId: string, itemId: string) => {
    setChecklists(prev => prev.map(c => {
      if (c.id === checklistId) {
        return {
          ...c,
          items: c.items.filter(item => item.id !== itemId),
        };
      }
      return c;
    }));
  };

  // Goal actions
  const handleToggleGoalMilestone = (goalId: string, milestoneId: string) => {
    setGoals(prev => prev.map(g => {
      if (g.id === goalId) {
        return {
          ...g,
          keyResults: g.keyResults.map(kr => kr.id === milestoneId ? { ...kr, completed: !kr.completed } : kr),
        };
      }
      return g;
    }));
    playGentleChime('success');
  };

  const handleAddGoal = (goalData: Partial<Goal90Day>) => {
    const newGoal: Goal90Day = {
      id: `goal-${Date.now()}`,
      title: goalData.title || 'Untitled 90-Day Goal',
      targetQuarter: goalData.targetQuarter || 'Q4 2026',
      whyItMatters: goalData.whyItMatters || 'Personal life alignment',
      cutCommitment: goalData.cutCommitment || 'Eliminated non-essential distraction',
      keyResults: goalData.keyResults || [],
    };
    setGoals(prev => [newGoal, ...prev]);
  };

  // Chore actions
  const handleToggleChore = (choreId: string) => {
    setChores(prev => prev.map(c => {
      if (c.id === choreId) {
        const nextDone = !c.completed;
        return {
          ...c,
          completed: nextDone,
          lastCompletedDate: nextDone ? new Date().toISOString().split('T')[0] : c.lastCompletedDate,
        };
      }
      return c;
    }));
  };

  const handleAddChore = (choreData: Omit<HomeChore, 'id'>) => {
    const newChore: HomeChore = {
      ...choreData,
      id: `chore-${Date.now()}`,
    };
    setChores(prev => [newChore, ...prev]);
  };

  const handleDeleteChore = (choreId: string) => {
    setChores(prev => prev.filter(c => c.id !== choreId));
  };

  const handleResetDailyChores = () => {
    setChores(prev => prev.map(c => c.frequency === 'daily' ? { ...c, completed: false } : c));
    playGentleChime('sparkle');
  };

  // Study actions
  const handleToggleSession = (sessionId: string) => {
    setStudySessions(prev => prev.map(s => {
      if (s.id === sessionId) {
        return { ...s, completed: !s.completed };
      }
      return s;
    }));
  };

  const handleAddSession = (sessionData: Omit<StudySession, 'id'>) => {
    const newSession: StudySession = {
      ...sessionData,
      id: `study-${Date.now()}`,
    };
    setStudySessions(prev => [newSession, ...prev]);
  };

  const handleDeleteSession = (sessionId: string) => {
    setStudySessions(prev => prev.filter(s => s.id !== sessionId));
  };

  const handleAdvanceSpacedRepetition = (sessionId: string) => {
    const stages: StudySession['spacedRepetitionStage'][] = [
      'First Learning',
      'Day 1 Review',
      'Day 3 Recall',
      'Day 7 Practice',
      'Day 30 Mastery'
    ];
    setStudySessions(prev => prev.map(s => {
      if (s.id === sessionId) {
        const currentIdx = stages.indexOf(s.spacedRepetitionStage || 'First Learning');
        const nextIdx = Math.min(stages.length - 1, currentIdx + 1);
        return { ...s, spacedRepetitionStage: stages[nextIdx] };
      }
      return s;
    }));
    playGentleChime('sparkle');
  };

  // Evening shutdown completion
  const handleSelectTomorrowTop3 = (selectedIds: string[]) => {
    setTasks(prev => prev.map(t => {
      if (selectedIds.includes(t.id)) {
        return { ...t, category: 'top3', dayOfWeek: 'tue' };
      }
      return t;
    }));
  };

  const handleSelectPersona = (newPersona: TimetablePersona) => {
    setCurrentPersona(newPersona);
    try {
      localStorage.setItem('bloom_persona_v1', newPersona);
    } catch (e) {
      console.warn('Storage error', e);
    }

    const personaDataset = getPersonaData(newPersona);
    setTasks(personaDataset.tasks);
    setHabits(personaDataset.habits);
    setStudySessions(personaDataset.studySessions);
    setChores(personaDataset.chores);
    setChecklists(personaDataset.checklists);
    setGoals(personaDataset.goals);
    playGentleChime('sparkle');
  };

  const handleCompleteShutdown = () => {
    const todayStr = new Date().toISOString().split('T')[0];
    handleToggleHabitDate('h-1', todayStr);
  };

  const handleResetAllData = () => {
    if (window.confirm('Reset planner to default botanical schedules and sample habits?')) {
      const defaultData = getPersonaData(currentPersona);
      setTasks(defaultData.tasks);
      setHabits(defaultData.habits);
      setChecklists(defaultData.checklists);
      setGoals(defaultData.goals);
      setChores(defaultData.chores);
      setStudySessions(defaultData.studySessions);
      localStorage.clear();
      playGentleChime('sparkle');
    }
  };

  const personaCfg = PERSONA_CONFIGS[currentPersona];
  const primaryHabit = habits[0] || INITIAL_HABITS[0];
  const topTasksPreview = tasks.filter(t => t.category === 'top3').slice(0, 3);
  const displayTasksPreview = topTasksPreview.length > 0 ? topTasksPreview : tasks.slice(0, 3);

  // Generate 7-day keys for habit tracker preview (Mon-Sun)
  const previewDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className="min-h-screen bg-[#fdfcf9] text-[#1a1a1a] flex flex-col font-sans selection:bg-[#7b2c3c] selection:text-[#fdfcf9]">
      
      {/* Navigation Header */}
      <HeaderNav
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (tab === 'print') {
            setIsPrintModalOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
        onOpenShutdown={() => setIsShutdownModalOpen(true)}
        onOpenPrintStudio={() => setIsPrintModalOpen(true)}
        onOpenGitHubExport={() => setIsGitHubModalOpen(true)}
        currentPersona={currentPersona}
        onSelectPersona={handleSelectPersona}
        openLoopsCount={stats.openLoops}
        todayDoneCount={stats.completedTasks}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
        
        {/* Variation 1: Split Hero & Live Preview Pane */}
        <div className="bg-[#fdfcf9] border-2 border-[#1a1a1a] shadow-xs relative no-print overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
            
            {/* Left Hero Section */}
            <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between border-b lg:border-b-0 lg:border-r-[1.5px] border-[#1a1a1a]">
              <div>
                <span className="font-mono-space text-[11px] font-bold uppercase tracking-[0.2em] text-[#7b2c3c] block mb-3">
                  [ PRINTABLE RITUALS // {personaCfg.shortLabel.toUpperCase()} ]
                </span>
                
                <h1 className="font-serif-cormorant text-4xl sm:text-6xl lg:text-7xl font-light leading-[0.92] tracking-[-0.04em] text-[#1a1a1a] mb-5">
                  The Art of <em className="italic font-normal">Mindful</em> Productivity
                </h1>
                
                <p className="max-w-xl text-sm sm:text-base text-[#1a1a1a]/70 leading-relaxed font-sans mb-6">
                  A quiet, physical approach to daily focus. Designed to be printed, folded, and marked by hand—balancing deep work sprints, household rhythm, and evening restoration.
                </p>

                <div className="flex flex-wrap items-center gap-4 mb-6">
                  <button
                    onClick={() => setIsPrintModalOpen(true)}
                    className="bg-[#1a1a1a] hover:bg-[#7b2c3c] text-[#fdfcf9] px-7 py-3 font-mono-space text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer shadow-xs"
                  >
                    Print Weekly Sheet
                  </button>
                  <button
                    onClick={() => setIsPrintModalOpen(true)}
                    className="font-mono-space text-xs uppercase tracking-wider text-[#1a1a1a]/70 hover:text-[#7b2c3c] transition-colors cursor-pointer flex items-center gap-1 font-bold"
                  >
                    PDF / A4 &amp; LETTER / 300 DPI
                  </button>
                </div>
              </div>

              {/* Botanical Artwork Accent Bar (Zero People - Pure Peonies & Stationery) */}
              <div className="pt-4 border-t border-[#1a1a1a]/15 flex items-center gap-3">
                <div className="w-16 h-12 bg-[#f2efeb] border border-[#1a1a1a]/20 overflow-hidden shrink-0">
                  <img
                    src="/assets/botanical_still_life.jpg"
                    alt="Botanical Study, Peonies &amp; Vintage Stationery"
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                <div className="text-[11px] font-mono-space text-[#1a1a1a]/70 leading-snug">
                  <span className="text-[#7b2c3c] font-bold">ARTISAN PALETTE:</span> Wine &amp; Warm Parchment • Zero Distraction Cognitive Sanctuary
                </div>
              </div>
            </div>

            {/* Right Preview Pane (Warm Sand #f2efeb Background) */}
            <div className="lg:col-span-5 bg-[#f2efeb] p-5 sm:p-7 flex flex-col justify-between gap-4">
              
              {/* Card 1: Weekly Focus Ritual */}
              <div className="bg-[#fdfcf9] border border-[#1a1a1a]/15 p-4 sm:p-5 relative shadow-xs">
                <div className="flex justify-between items-baseline mb-3 border-b border-[#1a1a1a]/10 pb-2">
                  <h3 className="font-serif-cormorant text-lg font-semibold text-[#1a1a1a]">
                    Weekly Focus Ritual
                  </h3>
                  <span className="font-mono-space text-[10px] text-[#1a1a1a]/50 uppercase tracking-wider">
                    01 / 03
                  </span>
                </div>
                <div className="space-y-2.5">
                  {displayTasksPreview.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(task.id)}
                      className="flex items-center gap-3 text-xs sm:text-sm text-[#1a1a1a] cursor-pointer group select-none"
                    >
                      <div
                        className={`w-2.5 h-2.5 rounded-full border border-[#1a1a1a] shrink-0 transition-colors ${
                          task.completed ? 'bg-[#7b2c3c] border-[#7b2c3c]' : 'bg-transparent group-hover:border-[#7b2c3c]'
                        }`}
                      />
                      <span className={`line-clamp-1 leading-snug ${task.completed ? 'line-through text-[#1a1a1a]/40' : 'text-[#1a1a1a]'}`}>
                        {task.title}
                      </span>
                    </div>
                  ))}
                  {displayTasksPreview.length === 0 && (
                    <p className="text-xs text-[#1a1a1a]/50 italic">No tasks queued. Click capture above.</p>
                  )}
                </div>
              </div>

              {/* Card 2: Botanical Habit Tracker */}
              <div className="bg-[#fdfcf9] border border-[#1a1a1a]/15 p-4 sm:p-5 relative shadow-xs">
                <div className="flex justify-between items-baseline mb-2 border-b border-[#1a1a1a]/10 pb-2">
                  <h3 className="font-serif-cormorant text-lg font-semibold text-[#1a1a1a]">
                    Botanical Habit Tracker
                  </h3>
                  <span className="font-mono-space text-[10px] text-[#1a1a1a]/50 uppercase tracking-wider">
                    02 / 03
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs font-mono-space text-[#1a1a1a]/70 mb-2">
                  <span className="truncate">{primaryHabit?.name || 'Deep Work Morning Sprint'}</span>
                  <span className="text-[#7b2c3c] font-bold shrink-0">{primaryHabit?.currentStreak || 0}D STREAK</span>
                </div>
                <div className="grid grid-cols-7 gap-1.5">
                  {previewDays.map((dayLabel, idx) => {
                    // Check if current day or sample day is filled
                    const sampleFilled = idx < 4;
                    return (
                      <div
                        key={dayLabel}
                        className={`aspect-square border flex flex-col items-center justify-center text-[10px] font-mono-space transition-colors ${
                          sampleFilled
                            ? 'bg-[#7b2c3c] text-white border-[#7b2c3c]'
                            : 'bg-white/60 text-[#1a1a1a]/70 border-[#1a1a1a]/15'
                        }`}
                        title={`${dayLabel} habit block`}
                      >
                        <span className="text-[9px] uppercase">{dayLabel[0]}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Card 3: Journal Reflection with Dot-Grid Pattern */}
              <div className="bg-[#fdfcf9] border border-[#1a1a1a]/15 p-4 sm:p-5 relative shadow-xs">
                <div className="flex justify-between items-baseline mb-2 border-b border-[#1a1a1a]/10 pb-2">
                  <h3 className="font-serif-cormorant text-lg font-semibold text-[#1a1a1a]">
                    Journal Reflection
                  </h3>
                  <span className="font-mono-space text-[10px] text-[#1a1a1a]/50 uppercase tracking-wider">
                    03 / 03
                  </span>
                </div>
                <p className="text-xs text-[#1a1a1a]/75 italic font-serif-cormorant mb-2">
                  “What quiet win anchored your day today?”
                </p>
                <div className="dot-grid h-16 w-full rounded-sm border border-[#1a1a1a]/10 flex items-center justify-center p-2">
                  <span className="font-mono-space text-[10px] text-[#1a1a1a]/40 tracking-wider uppercase">
                    Tactile Ink &amp; Paper Space
                  </span>
                </div>
              </div>

            </div>
          </div>
        </div>

        {/* Tab View Switching */}
        {activeTab === 'weekly' && (
          <WeeklyPlannerView
            tasks={tasks}
            habits={habits}
            currentPersona={currentPersona}
            onSelectPersona={handleSelectPersona}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
            onDeleteTask={handleDeleteTask}
            onRolloverTask={handleRolloverTask}
            onToggleHabitDate={handleToggleHabitDate}
            onOpenPrintStudio={() => setIsPrintModalOpen(true)}
          />
        )}

        {activeTab === 'focus' && (
          <DailyFocusView
            tasks={tasks}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
          />
        )}

        {activeTab === 'chores' && (
          <HomeChoresView
            chores={chores}
            onToggleChore={handleToggleChore}
            onAddChore={handleAddChore}
            onDeleteChore={handleDeleteChore}
            onResetDailyChores={handleResetDailyChores}
          />
        )}

        {activeTab === 'study' && (
          <StudySchedulesView
            sessions={studySessions}
            currentPersona={currentPersona}
            onSelectPersona={handleSelectPersona}
            onToggleSession={handleToggleSession}
            onAddSession={handleAddSession}
            onDeleteSession={handleDeleteSession}
            onAdvanceSpacedRepetition={handleAdvanceSpacedRepetition}
          />
        )}

        {activeTab === 'inbox' && (
          <CaptureInboxView
            tasks={tasks}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
            onDeleteTask={handleDeleteTask}
            onAssignToDay={handleAssignToDay}
          />
        )}

        {activeTab === 'checklists' && (
          <RepeatChecklistsView
            checklists={checklists}
            onToggleItem={handleToggleChecklistItem}
            onResetChecklist={handleResetChecklist}
            onAddItem={handleAddChecklistItem}
            onDeleteItem={handleDeleteChecklistItem}
            onOpenPrintStudio={() => setIsPrintModalOpen(true)}
          />
        )}

        {activeTab === 'goals' && (
          <GoalMatrixView
            tasks={tasks}
            goals={goals}
            habits={habits}
            onToggleTask={handleToggleTask}
            onToggleGoalMilestone={handleToggleGoalMilestone}
            onAddGoal={handleAddGoal}
            onOpenPrintStudio={() => setIsPrintModalOpen(true)}
          />
        )}
      </main>

      {/* Variation 1 Footer: Coordinates & Clean Monospace Links */}
      <footer className="mt-12 bg-[#fdfcf9] border-t-[1.5px] border-[#1a1a1a] px-4 sm:px-8 py-5 text-xs text-[#1a1a1a]/70 no-print">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 font-mono-space text-[11px]">
          <div className="flex items-center gap-3">
            <span className="tracking-[0.15em] text-[#1a1a1a] font-bold">LAT 34.0522 / LONG -118.2437</span>
            <span className="text-[#7b2c3c]">/</span>
            <span className="text-[#1a1a1a]/60 hidden sm:inline">DESIGNED FOR INTENTIONAL LIVING &amp; TACTILE CLARITY</span>
          </div>

          <div className="flex items-center gap-4 flex-wrap justify-center">
            <button
              onClick={handleResetAllData}
              className="text-[#1a1a1a]/60 hover:text-[#7b2c3c] transition-colors cursor-pointer uppercase tracking-wider"
            >
              Reset Sample
            </button>
            <span className="text-[#1a1a1a]/30">/</span>
            <button
              onClick={() => setIsPrintModalOpen(true)}
              className="text-[#1a1a1a] font-bold hover:text-[#7b2c3c] transition-colors cursor-pointer uppercase tracking-wider"
            >
              Print Studio
            </button>
            <span className="text-[#1a1a1a]/30">/</span>
            <button
              onClick={() => setIsGitHubModalOpen(true)}
              className="text-[#1a1a1a] font-bold hover:text-[#7b2c3c] transition-colors cursor-pointer uppercase tracking-wider"
            >
              GitHub Repo
            </button>
            <span className="text-[#1a1a1a]/30">/</span>
            <span className="text-[#1a1a1a]/50">© 2024 BLOOM &amp; ORDER • EDITION 01</span>
          </div>
        </div>
      </footer>

      {/* Interactive Modals */}
      <PrintStudioModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        tasks={tasks}
        habits={habits}
        checklists={checklists}
        goals={goals}
        chores={chores}
        studySessions={studySessions}
      />

      <EveningShutdownModal
        isOpen={isShutdownModalOpen}
        onClose={() => setIsShutdownModalOpen(false)}
        tasks={tasks}
        onToggleTask={handleToggleTask}
        onRolloverTask={handleRolloverTask}
        onSelectTomorrowTop3={handleSelectTomorrowTop3}
        onCompleteShutdown={handleCompleteShutdown}
      />

      <QuickCaptureModal
        isOpen={isQuickCaptureOpen}
        onClose={() => setIsQuickCaptureOpen(false)}
        onAddTask={handleAddTask}
      />

      <GitHubExportModal
        isOpen={isGitHubModalOpen}
        onClose={() => setIsGitHubModalOpen(false)}
      />
    </div>
  );
}
