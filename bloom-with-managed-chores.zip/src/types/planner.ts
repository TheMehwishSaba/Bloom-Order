export type PriorityQuadrant = 
  | 'urgent-important'       // Do first: Crises, pressing deadlines
  | 'important-not-urgent'   // Schedule: Deep work, strategy, exercise, relationships (moves goals!)
  | 'urgent-not-important'   // Delegate/Automate: Interruptions, some calls/messages
  | 'not-urgent-not-important'; // Drop/Eliminate: Time-wasters, trivia

export type DayOfWeek = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';

export type DayTimeBlock = 'morning' | 'mid-morning' | 'midday' | 'afternoon' | 'evening';

export type TaskCategory = 
  | 'top3'
  | 'inbox'
  | 'parking-lot'
  | 'waiting-for'
  | 'not-to-do'
  | 'under-2-min';

export interface TaskItem {
  id: string;
  title: string;
  category: TaskCategory;
  dayOfWeek?: DayOfWeek;
  timeBlock?: DayTimeBlock;
  completed: boolean;
  priority: PriorityQuadrant;
  nextPhysicalAction?: string;
  definitionOfDone?: string;
  ifThenIntention?: {
    condition: string;
    action: string;
  };
  estimatedMinutes?: number;
  delegatedTo?: string; // for waiting-for list
  dateAdded: string;
  completedAt?: string;
}

export interface HabitItem {
  id: string;
  name: string;
  description: string;
  category: 'daily' | 'weekly' | 'hourly';
  currentStreak: number;
  bestStreak: number;
  // Map of date string YYYY-MM-DD -> completed
  completedDates: Record<string, boolean>;
  color?: string;
}

export interface RepeatChecklistItem {
  id: string;
  text: string;
  completed: boolean;
  note?: string;
}

export interface RepeatChecklist {
  id: string;
  title: string;
  subtitle: string;
  category: 'weekly-shop' | 'sunday-reset' | 'shutdown' | 'monthly-declutter' | 'travel' | 'custom';
  icon: string;
  items: RepeatChecklistItem[];
}

export interface Goal90Day {
  id: string;
  title: string;
  targetQuarter: string;
  whyItMatters: string;
  cutCommitment: string; // What was cut to protect this
  keyResults: {
    id: string;
    text: string;
    completed: boolean;
  }[];
}

export interface HomeChore {
  id: string;
  title: string;
  roomZone: 'kitchen' | 'living' | 'bedroom' | 'bathroom' | 'study-office' | 'entryway' | 'general';
  frequency: 'daily' | 'weekly' | 'monthly' | 'speed-tidy';
  estimatedMinutes: number;
  completed: boolean;
  lastCompletedDate?: string;
  notes?: string;
}

export interface StudySession {
  id: string;
  subject: string;
  topic: string;
  dayOfWeek?: DayOfWeek;
  durationMinutes: number; // e.g. 25, 50, 90
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
  spacedRepetitionStage?: 'First Learning' | 'Day 1 Review' | 'Day 3 Recall' | 'Day 7 Practice' | 'Day 30 Mastery';
  targetExamDate?: string;
  keyConcepts?: string[];
  notes?: string;
}

export interface PrintSettings {
  template: 'weekly-spread' | 'daily-focus' | 'master-checklist' | 'matrix-goals' | 'shutdown-sheet' | 'home-chores' | 'study-schedule';
  theme: 'rose-sage' | 'monochrome-ink' | 'vintage-wheat';
  pageSize: 'letter' | 'a4';
  showFloralBorders: boolean;
  showInspirationalQuote: boolean;
  notesLinesCount: number;
}

export type TimetablePersona = 'student' | 'professional' | 'working-mother' | 'balanced';

export interface PersonaConfig {
  id: TimetablePersona;
  title: string;
  shortLabel: string;
  badge: string;
  iconName: string;
  tagline: string;
  description: string;
  bannerQuote: string;
  focusAccent: string; // Tailwind color class or hex
}
