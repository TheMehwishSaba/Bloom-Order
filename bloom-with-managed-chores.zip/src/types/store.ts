export type ProductCategory =
  | 'All'
  | 'Produce'
  | 'Dairy & Eggs'
  | 'Bakery'
  | 'Pantry & Staples'
  | 'Snacks & Drinks'
  | 'Household & Care';

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: ProductCategory;
  description: string;
  price: number;
  originalPrice?: number;
  unit: string; // e.g. "per lb", "12 oz", "each", "bunch"
  stock: number;
  lowStockThreshold: number;
  image: string;
  rating: number;
  reviewCount: number;
  aisle: string;
  shelf: string;
  barcode: string;
  tags: string[];
  nutrition?: {
    calories: number;
    organic: boolean;
    vegan: boolean;
    glutenFree: boolean;
  };
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type LoyaltyTier = 'Bronze' | 'Silver' | 'Gold' | 'Platinum';

export interface LoyaltyVoucher {
  id: string;
  title: string;
  description: string;
  code: string;
  discountType: 'flat' | 'percentage' | 'free_shipping';
  discountValue: number;
  pointsCost: number;
  minSpend?: number;
  unlocked: boolean;
}

export interface LoyaltyProfile {
  userId: string;
  name: string;
  email: string;
  points: number;
  lifetimePoints: number;
  tier: LoyaltyTier;
  streakDays: number;
  lastCheckInDate?: string;
  memberSince: string;
  vouchers: LoyaltyVoucher[];
  history: {
    id: string;
    description: string;
    pointsChange: number;
    type: 'earn' | 'redeem' | 'bonus';
    date: string;
  }[];
}

export type OrderStatus =
  | 'order_confirmed'
  | 'picked_packed'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export interface OrderTimelineEvent {
  status: OrderStatus;
  title: string;
  description: string;
  timestamp: string;
  completed: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  status: OrderStatus;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  deliveryFee: number;
  discount: number;
  tip: number;
  total: number;
  pointsEarned: number;
  pointsRedeemed: number;
  deliveryType: 'standard' | 'express' | 'pickup';
  deliveryAddress: {
    street: string;
    apt?: string;
    city: string;
    zip: string;
    notes?: string;
  };
  paymentMethod: {
    type: 'credit_card' | 'apple_pay' | 'google_pay' | 'cash_on_delivery';
    brand?: string;
    last4?: string;
    transactionId: string;
  };
  timeline: OrderTimelineEvent[];
  driver?: {
    name: string;
    phone: string;
    vehicle: string;
    rating: number;
    etaMinutes: number;
    avatar: string;
    currentLocation: string;
  };
  deliveryProofPhoto?: string;
}

export interface EmailNotification {
  id: string;
  orderId: string;
  orderNumber: string;
  recipientEmail: string;
  stage: OrderStatus;
  subject: string;
  previewText: string;
  sentAt: string;
  read: boolean;
  htmlContent: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  totalOrders: number;
  totalSpent: number;
  loyaltyTier: LoyaltyTier;
  loyaltyPoints: number;
  joinedDate: string;
  lastOrderDate: string;
  notes: string;
}
